### report-validation: 0.14s, exit 0

Mode `sequential`, workers 1, SHA `80d5b9180a6377e5efbfc6fba6a612e52e03a33f`, Python 3.12.15, SQLite 3.45.1.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
