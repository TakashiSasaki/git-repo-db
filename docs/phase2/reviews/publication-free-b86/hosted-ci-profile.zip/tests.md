### tests: 97.60s, exit 1

Mode `xdist`, workers 4, SHA `80d5b9180a6377e5efbfc6fba6a612e52e03a33f`, Python 3.12.15, SQLite 3.45.1.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/test_current_followup_adversarial.py | 42.26 | 75 | 75 |
| tests/integration/test_catalog3_rest_boundaries.py | 18.86 | 62 | 62 |
| tests/integration/test_catalog3_github_runtime.py | 16.57 | 69 | 60 |
| tests/integration/test_current_nested_presence.py | 14.23 | 72 | 20 |
| tests/integration/test_current_author_presence.py | 13.50 | 70 | 20 |
| tests/integration/test_catalog3_coverage.py | 12.57 | 166 | 165 |
| tests/integration/test_phase1_retirement.py | 11.93 | 40 | 40 |
| tests/integration/test_current_resources.py | 11.58 | 17 | 17 |
| tests/integration/test_current_boundaries_independent.py | 11.22 | 29 | 21 |
| tests/integration/test_ci_execution.py | 9.74 | 60 | 0 |
