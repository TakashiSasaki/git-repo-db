## Validation plan

Effective SHA `80d5b9180a6377e5efbfc6fba6a612e52e03a33f`; full acceptance selected: True.
Acceptance input hash: `86b784f43dd9d7b474fb8d83ca6c6e5e7c7ca0b3c4a20c8d9e1ad0e14d011198`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | selected | 99 |
| packaging | selected | 1 |
| smoke | selected | 0 |

Unexecuted acceptance files: 0. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.163s.

Dynamic test dependency requires full selection: tests/integration/test_catalog3_exchange.py
Unknown dependency path: docs/phase2/publication-free-schema-map.json
Unknown dependency path: docs/phase2/publication-free-test-disposition.json
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/full-diff-cafa8a8b143fe095b79f282690a6edf98e6f660e.patch.gz
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/git-authorization-scale-cafa8a8b143fe095b79f282690a6edf98e6f660e.json
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/git_authorization_scale.py
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/manifest.json
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/metadata-final-initial-cafa8a8b143fe095b79f282690a6edf98e6f660e.json
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-code-list.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-conflicts.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-crash.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-fakeoid.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-final.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-fixture-v2.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-invalidheaders.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-invalidnames.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8-late.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/pytest-cafa8a8.txt
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/schema-map-actual-cafa8a8b143fe095b79f282690a6edf98e6f660e.json
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/selected-pending-scale-cafa8a8b143fe095b79f282690a6edf98e6f660e.json
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/selected_pending_scale.py
Unknown dependency path: docs/phase2/reviews/publication-free-domain-initial/test_independent_domain_qa.cafa8a8b143fe095b79f282690a6edf98e6f660e.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/acquisition/frozen-probes-v1/test_independent_acquisition.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/acquisition/frozen-probes-v1/test_independent_invariants.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/acquisition/initial-frozen-results.txt
Unknown dependency path: docs/phase2/reviews/publication-free-initial/acquisition/initial-frozen-results.xml
Unknown dependency path: docs/phase2/reviews/publication-free-initial/acquisition/repro_scope_replica.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/acquisition/scope-replica-result.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/artifact-sha256.txt
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/audit-runtime.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/counterexamples-results.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/counterexamples.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/native-schema-dependencies.json.gz
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/positive-results.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/positive_probes.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/source-sql-call-inventory.json.gz
Unknown dependency path: docs/phase2/reviews/publication-free-initial/architecture/unmapped-retired-functions.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/git-exchange-cas/intrinsic_tree_spoof.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/git-exchange-cas/intrinsic_tree_spoof.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/git-exchange-cas/selected_coverage_scale.json
Unknown dependency path: docs/phase2/reviews/publication-free-initial/git-exchange-cas/selected_coverage_scale.py
Unknown dependency path: docs/phase2/reviews/publication-free-initial/manifest.json
Shared/executable input: scripts/audit_publication_free.py
Shared/executable input: scripts/audit_publication_free_test_dispositions.py
Shared/executable input: scripts/ci_dependencies.json
Shared/executable input: scripts/verify_builtin_parser.py
Shared/executable input: src/repo_catalog/adapters/filesystem/cache.py
Shared/executable input: src/repo_catalog/adapters/git/importer.py
Shared/executable input: src/repo_catalog/adapters/git/parsing.py
Shared/executable input: src/repo_catalog/adapters/github/collector.py
Shared/executable input: src/repo_catalog/adapters/github/current_parser.py
Shared/executable input: src/repo_catalog/adapters/github/persistence.py
Shared/executable input: src/repo_catalog/adapters/sqlite/cas_integrity.py
Shared/executable input: src/repo_catalog/adapters/sqlite/coverage.py
Shared/executable input: src/repo_catalog/adapters/sqlite/current_api.py
Shared/executable input: src/repo_catalog/adapters/sqlite/current_collections.py
Shared/executable input: src/repo_catalog/adapters/sqlite/current_resources.py
Shared/executable input: src/repo_catalog/adapters/sqlite/exchange.py
Shared/executable input: src/repo_catalog/adapters/sqlite/git_intrinsic.py
Shared/executable input: src/repo_catalog/adapters/sqlite/identity_relations.py
Shared/executable input: src/repo_catalog/adapters/sqlite/index.py
Shared/executable input: src/repo_catalog/adapters/sqlite/json_contracts.py
Shared/executable input: src/repo_catalog/adapters/sqlite/parser_model.py
Shared/executable input: src/repo_catalog/adapters/sqlite/payloads.py
Shared/executable input: src/repo_catalog/adapters/sqlite/schema.py
Shared/executable input: src/repo_catalog/adapters/sqlite/store.py
Shared/executable input: src/repo_catalog/adapters/sqlite/target.py
Shared/executable input: src/repo_catalog/adapters/sqlite/transactions.py
Shared/executable input: src/repo_catalog/application/catalog_validation.py
Shared/executable input: src/repo_catalog/application/collection_service.py
Shared/executable input: src/repo_catalog/application/exchange_service.py
Shared/executable input: src/repo_catalog/application/git_query_context.py
Shared/executable input: src/repo_catalog/application/issue_queries.py
Shared/executable input: src/repo_catalog/application/maintenance_service.py
Shared/executable input: src/repo_catalog/application/parser_service.py
Shared/executable input: src/repo_catalog/application/parsing_service.py
Shared/executable input: src/repo_catalog/application/pr_queries.py
Shared/executable input: src/repo_catalog/application/query_service.py
Shared/executable input: src/repo_catalog/application/repository_identity.py
Shared/executable input: src/repo_catalog/application/source_service.py
Shared/executable input: src/repo_catalog/application/target_queries.py
Shared/executable input: src/repo_catalog/cli/main.py
Shared/executable input: src/repo_catalog/domain/git_intrinsic.py
Shared/executable input: src/repo_catalog/domain/payload.py
Shared/executable input: src/repo_catalog/resources/builtin_parser_verification.json
Shared/executable input: src/repo_catalog/resources/catalog3.sql
Shared/executable input: src/repo_catalog/resources/current_api.sql
Shared/executable input: src/repo_catalog/resources/current_collections.sql
Shared/executable input: src/repo_catalog/resources/current_resources.sql
Shared/executable input: src/repo_catalog/resources/exchange.sql
Shared/executable input: src/repo_catalog/resources/git_domain.sql
Shared/executable input: src/repo_catalog/resources/git_facts.sql
Shared/executable input: src/repo_catalog/resources/identity_relations.sql
Shared/executable input: src/repo_catalog/resources/json_contracts.sql
Shared/executable input: src/repo_catalog/resources/pr_threads.graphql
Shared/executable input: src/repo_catalog/resources/schemas/cli-v1.schema.json
Shared/executable input: tests/conftest.py
Unknown dependency path: tests/integration/test_catalog3_adversarial_model.py
Unknown dependency path: tests/integration/test_catalog3_parser_model.py
Unknown dependency path: tests/integration/test_catalog3_profile_queries.py
Unknown dependency path: tests/integration/test_phase2_publication_scaling.py
Shared/executable input: tests/support/domain_facts.py
Shared/executable input: tests/support/git_publication_free_node_replacements.json
Shared/executable input: tests/support/github_fixture.py
Shared/executable input: tests/support/network_guard/sitecustomize.py
Shared/executable input: tests/support/parser_bootstrap.py
Shared/executable input: tests/support/parser_facts.py
Shared/executable input: tests/support/publication_free_baseline_nodes.txt
Shared/executable input: tests/support/publication_free_node_dispositions.json
Shared/executable input: tests/support/schema20_contract_replacements.json
Shared/executable input: tests/support/sqlite_contracts.py
