import hashlib,json,sqlite3,sys
from pathlib import Path
from repo_catalog.adapters.sqlite import p1_schema
import repo_catalog
origin=Path(repo_catalog.__file__).resolve()
assert origin.is_relative_to(Path(sys.prefix).resolve()), origin
p1_schema.verify_declared()
db=sqlite3.connect(':memory:')
p1_schema.register_functions(db); p1_schema.configure(db)
actual=db.execute('SELECT sqlite_version(),sqlite_source_id()').fetchone()
assert actual[0]==sys.argv[2],actual
db.executescript(p1_schema.compose('context'))
root=origin.parent
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.suffix in ('.py','.sql','.json')}
result={'sqlite':actual,'python':sys.version,'origin':str(origin),'compile_options':db.execute('PRAGMA compile_options').fetchall(),'pragmas':{n:db.execute('PRAGMA '+n).fetchall() for n in p1_schema.REQUIRED_PRAGMAS},'functions':[r for r in db.execute('PRAGMA function_list') if r[0].startswith('p1_')],'fingerprint':p1_schema.fingerprint('context'),'schema':p1_schema.schema_rows(db),'installed_files':files}
Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
