"""ADR 0031 I5: Independent Reviewer Counterexample and Invariant Test Suite.

Designed by independent reviewer to test:
A. Selection & Permission boundaries (untrusted inputs, omitted/permitted checks, exact replay)
B. Parent evidence implicit completion (synthesis pitfalls, differing clocks, missing vs existing parent)
C. Endpoint declaration & completeness (endpoints=None auto-generation vulnerability, 1-sided vs truncated)
D. Actual SQL atomicity & rollback under in-flight constraint failure (trigger injection on 2nd endpoint)
E. Provider semantic validation & G3=A permanent violation vs diagnosable dependency
F. Fences and schema validation (asymmetric checks, single trigger drops, refusal in normal product)
G. Pre-bind strict type verification before SQLite affinity conversions
H. Mutation rebind rejection on replay vs idempotency
I. Query filtering, isolation, and absence of endpoint cross-borrowing
"""

import json
import sqlite3
import pytest

from repo_catalog.adapters.sqlite import p1_schema
from repo_catalog.adapters.sqlite.p1_context import ContextStore
from repo_catalog.adapters.sqlite.production_context import Context, ContextError
from repo_catalog.domain.p1_context import (
    EventReportKey,
    FieldClock,
    MappingClaimKey,
    MappingSupport,
    ResourceKey,
    ResourceRepositoryRelation,
    TransferEventReport,
    canonical,
)
from repo_catalog.domain.parent_report import ParentReportKey
from repo_catalog.domain.resource_identification import ResourceIdentification as RI
from repo_catalog.domain.resource_stage import UnsupportedResourceStage, has_transfer_fence, validate_stage_storage

SERVICE = "aad25448-03eb-4f83-a75e-cb7055fd33be"
REPO_1 = "9ebbe38a-f937-40e6-a99c-701835ebcf10"
REPO_2 = "c58b4f17-f58c-4a33-8bc6-eb52c42337d1"
REPO_3 = "d3333333-3333-4333-8333-333333333333"

KEY_ISSUE_7 = ResourceKey.from_native(SERVICE, "issue", "7")
KEY_ISSUE_8 = ResourceKey.from_native(SERVICE, "issue", "8")

KEY_EVENT_7 = ResourceKey.document(KEY_ISSUE_7, "comment", "timeline_event", "77")
KEY_EVENT_8 = ResourceKey.document(KEY_ISSUE_8, "comment", "timeline_event", "88")

KEY_PROV_REPO_1 = ResourceKey.from_native(SERVICE, "repository", "org/repo1")
KEY_PROV_REPO_2 = ResourceKey.from_native(SERVICE, "repository", "org/repo2")

CLOCK_EVENT = FieldClock("event-clock", 100)
CLOCK_PARENT = FieldClock("parent-clock", 50)

PROV_PARENT = canonical({"source": "parent-orig", "evidence": ["p-ev", 1]})
PROV_EVENT = canonical({"source": "event-orig", "evidence": ["e-ev", 2]})

FENCES = ("i2_transfer_stage_fence", "i2_transfer_report_stage_fence")


def _parent_scope(clock: FieldClock = CLOCK_PARENT) -> str:
    return canonical(
        {
            "clock": json.loads(clock.encode()),
            "document_kind": "timeline_event",
            "state": "complete",
        }
    )


def _parent_members(issue: ResourceKey) -> str:
    return canonical([list(issue.coordinates())])


def make_parent_report(
    event: ResourceKey = KEY_EVENT_7,
    issue: ResourceKey = KEY_ISSUE_7,
    clock: FieldClock = CLOCK_PARENT,
    provenance: str = PROV_PARENT,
) -> ParentReportKey:
    return ParentReportKey(
        resource=event,
        members_json=_parent_members(issue),
        provenance_json=provenance,
        scope_json=_parent_scope(clock),
    )


def create_isolated_db() -> sqlite3.Connection:
    db = sqlite3.connect(":memory:", isolation_level=None)
    p1_schema.register_functions(db)
    p1_schema.configure(db)
    db.executescript(p1_schema.compose("context"))
    assert p1_schema.schema_rows(db) == p1_schema.expected_schema("context")
    for fence in FENCES:
        db.execute(f"DROP TRIGGER {fence}")
    return db


def create_normal_db() -> sqlite3.Connection:
    db = sqlite3.connect(":memory:", isolation_level=None)
    p1_schema.register_functions(db)
    p1_schema.configure(db)
    db.executescript(p1_schema.compose("context"))
    return db


def _setup_base_records(
    db: sqlite3.Connection,
    *,
    register_event: bool = True,
    register_issue: bool = True,
    register_parent_report: bool = True,
    register_repos: bool = True,
    register_prov_repos: bool = True,
    register_mapping_support: bool = False,
    issue_key: ResourceKey = KEY_ISSUE_7,
    event_key: ResourceKey = KEY_EVENT_7,
    parent_clock: FieldClock = CLOCK_PARENT,
    parent_prov: str = PROV_PARENT,
):
    db.execute("INSERT OR IGNORE INTO providers VALUES(?,?,?)", (SERVICE, "test", "{}"))

    if register_repos:
        for r_id in (REPO_1, REPO_2, REPO_3):
            db.execute(
                "INSERT OR IGNORE INTO repository_context VALUES(?,?)", (r_id, "{}")
            )

    if register_prov_repos:
        for prov_repo in (KEY_PROV_REPO_1, KEY_PROV_REPO_2):
            ri = RI.unscoped(prov_repo)
            db.execute(
                """INSERT OR IGNORE INTO resources(
                    service_instance_uuidv4, resource_kind, provider_resource_id,
                    identifier_namespace_kind, identifier_namespace_id, document_kind, provider_document_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (*prov_repo.coordinates(), *ri.columns),
            )

    if register_issue:
        ri_issue = RI.unscoped(issue_key)
        db.execute(
            """INSERT OR IGNORE INTO resources(
                service_instance_uuidv4, resource_kind, provider_resource_id,
                identifier_namespace_kind, identifier_namespace_id, document_kind, provider_document_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (*issue_key.coordinates(), *ri_issue.columns),
        )

    if register_event:
        ri_event = RI.scoped(
            event_key,
            issue_key,
            "timeline_event",
            "77" if issue_key == KEY_ISSUE_7 else "88",
        )
        db.execute(
            """INSERT OR IGNORE INTO resources(
                service_instance_uuidv4, resource_kind, provider_resource_id,
                identifier_namespace_kind, identifier_namespace_id, document_kind, provider_document_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (*event_key.coordinates(), *ri_event.columns),
        )

    if register_parent_report:
        db.execute(
            """INSERT OR IGNORE INTO resource_relations(
                service_instance_uuidv4, resource_kind, provider_resource_id,
                relation_kind, members_json, provenance_json, scope_json, observed_at_us
            ) VALUES (?, ?, ?, 'parent', ?, ?, ?, ?)""",
            (
                *event_key.coordinates(),
                _parent_members(issue_key),
                parent_prov,
                _parent_scope(parent_clock),
                10,
            ),
        )

    if register_mapping_support:
        for prov_repo, target_uuid in (
            (KEY_PROV_REPO_1, REPO_1),
            (KEY_PROV_REPO_2, REPO_2),
        ):
            db.execute(
                """INSERT OR IGNORE INTO resource_repository_relations(
                    service_instance_uuidv4, resource_kind, provider_resource_id,
                    relation_kind, target_json, clock_json, provenance_json, observed_at_us
                ) VALUES (?, ?, ?, 'represents_repository', ?, ?, ?, ?)""",
                (
                    *prov_repo.coordinates(),
                    canonical(target_uuid),
                    parent_clock.encode(),
                    parent_prov,
                    10,
                ),
            )


# ==============================================================================
# SECTION A: Selection & Permission Boundary
# ==============================================================================

def test_selection_permission_store_trust_boundary():
    """Verify that ContextStore.admit_transfer_event lacks caller permission enforcement.
    
    In contrast to Context.relation(), which checks selected_resources and permitted,
    ContextStore.admit_transfer_event acts strictly as a store-level invariant enforcer.
    If an external caller passes a transfer report containing resources/repositories
    outside their granted scope, ContextStore admits it without permission error.
    This establishes that permission filtering is NOT an I5 Store Admission guarantee,
    and MUST be enforced at I6 Wire / Routing layer.
    """
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Valid report referencing REPO_1 and REPO_2
    report = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(),
    )

    # Store admits it directly without any permission argument
    res = store.admit_transfer_event(report)
    assert res == "insert"

    # Replay succeeds as duplicate without caller permission check
    assert store.admit_transfer_event(report) == "duplicate"


def test_selection_truncation_rejection():
    """TransferEventReport with selection_truncated=True or omitted_roles MUST be rejected."""
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Truncated report
    report_trunc = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        parent_report=make_parent_report(),
    )
    object.__setattr__(report_trunc, "selection_truncated", True)

    with pytest.raises(ValueError, match="Selection truncated Transfer reports cannot be admitted"):
        store.admit_transfer_event(report_trunc)

    # Omitted roles report
    report_omitted = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        parent_report=make_parent_report(),
        omitted_roles=("transfer_to_repository",),
    )
    with pytest.raises(ValueError, match="Omitted roles Transfer reports cannot be admitted"):
        store.admit_transfer_event(report_omitted)


# ==============================================================================
# SECTION B: Parent Evidence Implicit Completion
# ==============================================================================

def test_parent_evidence_differing_clock_dependency_failure():
    """When parent_report is omitted, __post_init__ synthesizes parent scope with EVENT's clock.
    
    If the legitimate parent report in the database has a different clock (e.g. Issue clock),
    the synthesized scope fails to find the parent report, causing a 'Missing dependency' error.
    This demonstrates the danger of implicit parent completion: omission of parent_report
    cannot transparently locate an existing parent report with an independent clock.
    """
    db = create_isolated_db()
    # Issue parent report has CLOCK_PARENT (clock at_us=50)
    _setup_base_records(db, parent_clock=CLOCK_PARENT)
    store = ContextStore(db)

    # Call from_targets WITHOUT parent_report (relies on synthesis from CLOCK_EVENT, at_us=100)
    report_synthesized = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=None,  # omitted!
    )

    # The synthesized scope expects clock at_us=100, but DB has at_us=50
    with pytest.raises(ValueError, match="Missing dependency: eligible Parent report not found"):
        store.admit_transfer_event(report_synthesized)

    # When the explicit parent report is supplied, admission succeeds
    report_explicit = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(clock=CLOCK_PARENT),
    )
    assert store.admit_transfer_event(report_explicit) == "insert"


def test_parent_evidence_differing_provenance_dependency_failure():
    """When parent_report is omitted, synthesized parent provenance uses event's provenance.
    
    If legitimate parent report has distinct provenance, dependency check fails.
    """
    db = create_isolated_db()
    _setup_base_records(db, parent_prov=PROV_PARENT)
    store = ContextStore(db)

    # Synthesis uses PROV_EVENT, but DB has PROV_PARENT
    report_synthesized = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        parent_report=None,
    )
    with pytest.raises(ValueError, match="Missing dependency: eligible Parent report not found"):
        store.admit_transfer_event(report_synthesized)


# ==============================================================================
# SECTION C: Endpoint Declaration & Completeness
# ==============================================================================

def test_endpoints_none_auto_synthesis_vulnerability():
    """Verify vulnerability where endpoints=None auto-generates declarations from relations.
    
    If a 2-sided transfer loses one endpoint before TransferEventReport construction
    (e.g. truncated on wire), and caller passes endpoints=None, TransferEventReport
    auto-synthesizes endpoints from the remaining 1 relation.
    Because declared_endpoints matches relations, Store Admission admits it as a 1-sided transfer!
    This proves that Store Admission CANNOT detect wire truncation when endpoints=None is used;
    the provider's original declared endpoints MUST be carried and verified.
    """
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Construct report with only 1 relation and endpoints=None
    rel_from = ResourceRepositoryRelation(
        resource=KEY_EVENT_7,
        relation_kind="transfer_from_repository",
        clock=CLOCK_EVENT,
        target_json=canonical(REPO_1),
        provenance_json=PROV_EVENT,
        observed_at_us=100,
    )

    # Caller passes endpoints=None
    report = TransferEventReport(
        report_key=EventReportKey(KEY_EVENT_7, CLOCK_EVENT, PROV_EVENT),
        observed_at_us=100,
        from_relations=(rel_from,),
        to_relations=(),
        from_provider_repository=KEY_PROV_REPO_1,
        parent_report=make_parent_report(),
        endpoints=None,  # triggers auto-synthesis!
    )

    # Synthesized endpoints has 1 element
    assert len(report.endpoints) == 1
    # Store admits it as genuine 1-sided transfer!
    assert store.admit_transfer_event(report) == "insert"


def test_endpoints_declared_mismatch_rejected():
    """When endpoints are explicitly declared, missing relations are strictly rejected."""
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    rel_from = ResourceRepositoryRelation(
        resource=KEY_EVENT_7,
        relation_kind="transfer_from_repository",
        clock=CLOCK_EVENT,
        target_json=canonical(REPO_1),
        provenance_json=PROV_EVENT,
        observed_at_us=100,
    )

    # Provider declared 2 endpoints
    declared = (
        ("transfer_from_repository", canonical(REPO_1)),
        ("transfer_to_repository", canonical(REPO_2)),
    )

    # But only 1 relation supplied
    report = TransferEventReport(
        report_key=EventReportKey(KEY_EVENT_7, CLOCK_EVENT, PROV_EVENT),
        observed_at_us=100,
        from_relations=(rel_from,),
        to_relations=(),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(),
        endpoints=declared,
    )

    with pytest.raises(ValueError, match="Declared endpoints in scope do not match supplied endpoint relations"):
        store.admit_transfer_event(report)


def test_genuine_1sided_and_explicit_null():
    """Genuine 1-sided transfers and explicit-null targets are admitted when lawfully declared."""
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Genuine 1-sided
    report_1sided = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=None,
        from_provider_repository=KEY_PROV_REPO_1,
        parent_report=make_parent_report(),
    )
    assert store.admit_transfer_event(report_1sided) == "insert"

    # Explicit null
    clock_null = FieldClock("event-clock", 101)
    report_null = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=clock_null,
        provenance_json=PROV_EVENT,
        observed_at_us=101,
        from_target_json=canonical(REPO_1),
        to_target_json="null",
        from_provider_repository=KEY_PROV_REPO_1,
        parent_report=make_parent_report(),
    )
    assert store.admit_transfer_event(report_null) == "insert"


# ==============================================================================
# SECTION D: In-Flight SQL Atomicity & Rollback
# ==============================================================================

def test_atomicity_inflight_sql_failure_rolls_back_savepoint():
    """Independent atomicity test exercising in-flight SQL failure after first INSERT succeeds.
    
    The Author's test only exercised pre-flight Python checks (missing repository_context).
    Here, we inject a temporary trigger on resource_repository_relations that fires on the
    second endpoint (relation_kind = 'transfer_to_repository'), causing a SQLite ABORT error.
    We verify:
    1. Pre-checks pass.
    2. SAVEPOINT p1_transfer_event is initiated.
    3. INSERT into resource_relations succeeds.
    4. First endpoint INSERT succeeds.
    5. Second endpoint INSERT fails with SQL constraint error.
    6. ROLLBACK TO p1_transfer_event executes.
    7. resource_relations has 0 transfer_event_report rows.
    8. resource_repository_relations has 0 transfer rows.
    """
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Inject failure on second endpoint
    db.execute("""
        CREATE TRIGGER injected_second_endpoint_failure
        BEFORE INSERT ON resource_repository_relations
        FOR EACH ROW WHEN NEW.relation_kind = 'transfer_to_repository'
        BEGIN
            SELECT RAISE(ABORT, 'Injected second endpoint failure');
        END;
    """)

    report = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(),
    )

    with pytest.raises(sqlite3.IntegrityError, match="Injected second endpoint failure"):
        store.admit_transfer_event(report)

    # Verify zero partial writes in resource_relations
    report_rows = db.execute(
        "SELECT COUNT(*) FROM resource_relations WHERE relation_kind='transfer_event_report'"
    ).fetchone()[0]
    assert report_rows == 0, f"Expected 0 transfer_event_report rows, found {report_rows}"

    # Verify zero partial writes in resource_repository_relations
    ep_rows = db.execute(
        "SELECT COUNT(*) FROM resource_repository_relations WHERE relation_kind IN ('transfer_from_repository', 'transfer_to_repository')"
    ).fetchone()[0]
    assert ep_rows == 0, f"Expected 0 transfer endpoint rows, found {ep_rows}"

    # Remove the trigger and verify clean admission succeeds
    db.execute("DROP TRIGGER injected_second_endpoint_failure")
    res = store.admit_transfer_event(report)
    assert res == "insert"

    report_rows_after = db.execute(
        "SELECT COUNT(*) FROM resource_relations WHERE relation_kind='transfer_event_report'"
    ).fetchone()[0]
    assert report_rows_after == 1


# ==============================================================================
# SECTION E: Provider Semantic Validation & G3=A Invariant
# ==============================================================================

def test_provider_event_meaning_and_resource_kind():
    """Event resource kind must be 'comment' and event_type must be 'transferred'."""
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Invalid event resource_kind ('issue')
    with pytest.raises(ValueError, match="requires resource_kind == 'comment'"):
        TransferEventReport.from_targets(
            KEY_ISSUE_7,  # issue instead of comment
            clock=CLOCK_EVENT,
            provenance_json=PROV_EVENT,
            observed_at_us=100,
            from_target_json=canonical(REPO_1),
            parent_report=make_parent_report(),
        )

    # Invalid event_type
    with pytest.raises(ValueError, match="requires genuine event_type='transferred'"):
        TransferEventReport.from_targets(
            KEY_EVENT_7,
            clock=CLOCK_EVENT,
            provenance_json=PROV_EVENT,
            observed_at_us=100,
            from_target_json=canonical(REPO_1),
            event_type="closed",
            parent_report=make_parent_report(),
        )


def test_g3a_permanent_violation_mismatched_parent_issue():
    """G3=A: Reported parent Issue does not match native parent Issue -> permanent violation."""
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    # Event 7 is child of Issue 7, but parent_report points to Issue 8
    parent_report_mismatched = make_parent_report(
        event=KEY_EVENT_7,
        issue=KEY_ISSUE_8,
    )

    report = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        parent_report=parent_report_mismatched,
    )

    with pytest.raises(ValueError, match="G3=A permanent violation"):
        store.admit_transfer_event(report)


# ==============================================================================
# SECTION F: Fences and Schema Validation
# ==============================================================================

def test_normal_fenced_product_refuses_transfer():
    """In a normal product DB, fences prevent Transfer admission and direct SQL insertion."""
    db = create_normal_db()
    assert has_transfer_fence(db) is True

    # 1. Direct SQL insertion on resource_relations is blocked by trigger
    with pytest.raises(sqlite3.IntegrityError, match="I2_TRANSFER_UNSUPPORTED"):
        db.execute(
            """INSERT INTO resource_relations(
                service_instance_uuidv4, resource_kind, provider_resource_id,
                relation_kind, members_json, provenance_json, scope_json, observed_at_us
            ) VALUES (?, ?, ?, 'transfer_event_report', '[]', '{}', '{}', 100)""",
            KEY_EVENT_7.coordinates(),
        )

    # 2. Direct SQL insertion on resource_repository_relations is blocked by trigger
    with pytest.raises(sqlite3.IntegrityError, match="I2_TRANSFER_UNSUPPORTED"):
        db.execute(
            """INSERT INTO resource_repository_relations(
                service_instance_uuidv4, resource_kind, provider_resource_id,
                relation_kind, target_json, clock_json, provenance_json, observed_at_us
            ) VALUES (?, ?, ?, 'transfer_from_repository', '\"repo\"', '{}', '{}', 100)""",
            KEY_EVENT_7.coordinates(),
        )

    # 3. ContextStore.admit_transfer_event raises UnsupportedResourceStage
    store = ContextStore(db)
    report = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        parent_report=make_parent_report(),
    )
    with pytest.raises(UnsupportedResourceStage):
        store.admit_transfer_event(report)


def test_asymmetric_fence_drop_detection(tmp_path):
    """Verify behavior when only one of the two fence triggers is dropped.
    
    Context._validate_schema() rejects single trigger drop with UNSUPPORTED_SCHEMA.
    has_transfer_fence(db) inspects only i2_transfer_stage_fence, showing asymmetric check.
    """
    # Drop only i2_transfer_stage_fence
    cat1 = tmp_path / "cat1"
    cat1.mkdir()
    p1_schema.initialize(cat1 / "context.sqlite3", "context", REPO_1, SERVICE)
    db1 = p1_schema.connect(cat1 / "context.sqlite3", "context")
    db1.execute("DROP TRIGGER i2_transfer_stage_fence")
    assert has_transfer_fence(db1) is False  # reports false because fence 1 is dropped!
    
    db1.execute("BEGIN IMMEDIATE")
    with pytest.raises(ContextError) as exc_info1:
        Context(db1, cat1)
    assert exc_info1.value.code == "UNSUPPORTED_SCHEMA"
    db1.close()

    # Drop only i2_transfer_report_stage_fence
    cat2 = tmp_path / "cat2"
    cat2.mkdir()
    p1_schema.initialize(cat2 / "context.sqlite3", "context", REPO_1, SERVICE)
    db2 = p1_schema.connect(cat2 / "context.sqlite3", "context")
    db2.execute("DROP TRIGGER i2_transfer_report_stage_fence")
    assert has_transfer_fence(db2) is True  # reports true because fence 1 is still present!
    
    db2.execute("BEGIN IMMEDIATE")
    with pytest.raises(ContextError) as exc_info2:
        Context(db2, cat2)
    assert exc_info2.value.code == "UNSUPPORTED_SCHEMA"
    db2.close()


# ==============================================================================
# SECTION G: Pre-Bind Strict Type Validation
# ==============================================================================

def test_prebind_type_strictness():
    """Pre-bind strict type verification rejects bool, float, str, negative, zero."""
    # observed_at_us: bool
    with pytest.raises((TypeError, ValueError)):
        TransferEventReport.from_targets(
            KEY_EVENT_7, clock=CLOCK_EVENT, provenance_json=PROV_EVENT,
            observed_at_us=True, from_target_json=canonical(REPO_1), parent_report=make_parent_report(),
        )
    # observed_at_us: float
    with pytest.raises((TypeError, ValueError)):
        TransferEventReport.from_targets(
            KEY_EVENT_7, clock=CLOCK_EVENT, provenance_json=PROV_EVENT,
            observed_at_us=123.45, from_target_json=canonical(REPO_1), parent_report=make_parent_report(),
        )
    # observed_at_us: str
    with pytest.raises((TypeError, ValueError)):
        TransferEventReport.from_targets(
            KEY_EVENT_7, clock=CLOCK_EVENT, provenance_json=PROV_EVENT,
            observed_at_us="100", from_target_json=canonical(REPO_1), parent_report=make_parent_report(),
        )
    # clock.at_us: bool
    with pytest.raises((TypeError, ValueError)):
        FieldClock("event", True)
    # clock.at_us: float
    with pytest.raises((TypeError, ValueError)):
        FieldClock("event", 12.3)
    # clock.at_us: negative
    with pytest.raises((TypeError, ValueError)):
        FieldClock("event", -1)
    # clock.at_us: zero
    with pytest.raises((TypeError, ValueError)):
        FieldClock("event", 0)


# ==============================================================================
# SECTION H: Mutation Rebind Rejection vs Idempotency
# ==============================================================================

def test_mutation_rebind_rejection_and_idempotency():
    """Replay with identical payload succeeds as 'duplicate'; modified payload/time raises rebind error."""
    db = create_isolated_db()
    _setup_base_records(db)
    store = ContextStore(db)

    report = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(),
    )

    assert store.admit_transfer_event(report) == "insert"
    assert store.admit_transfer_event(report) == "duplicate"

    # Rebind with altered observed_at_us
    report_altered_time = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=200,  # changed!
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(),
    )
    with pytest.raises(ValueError, match="Transfer report original payload/time rebind"):
        store.admit_transfer_event(report_altered_time)

    # Rebind with altered target payload
    report_altered_target = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_3),  # changed!
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(),
    )
    with pytest.raises(ValueError, match="Transfer report original payload/time rebind"):
        store.admit_transfer_event(report_altered_target)


# ==============================================================================
# SECTION I: Multi-Event Query Filtering & Absence of Endpoint Cross-Borrowing
# ==============================================================================

def test_query_filtering_no_endpoint_cross_borrowing():
    """transfer_event_reports queries full 10-column schema without cross-borrowing across reports."""
    db = create_isolated_db()
    _setup_base_records(db, issue_key=KEY_ISSUE_7, event_key=KEY_EVENT_7)
    _setup_base_records(db, issue_key=KEY_ISSUE_8, event_key=KEY_EVENT_8)
    store = ContextStore(db)

    # Report for Event 7 (REPO_1 -> REPO_2)
    report7 = TransferEventReport.from_targets(
        KEY_EVENT_7,
        clock=CLOCK_EVENT,
        provenance_json=PROV_EVENT,
        observed_at_us=100,
        from_target_json=canonical(REPO_1),
        to_target_json=canonical(REPO_2),
        from_provider_repository=KEY_PROV_REPO_1,
        to_provider_repository=KEY_PROV_REPO_2,
        parent_report=make_parent_report(event=KEY_EVENT_7, issue=KEY_ISSUE_7),
    )
    store.admit_transfer_event(report7)

    # Report for Event 8 (REPO_2 -> REPO_3)
    clock8 = FieldClock("event-clock", 200)
    report8 = TransferEventReport.from_targets(
        KEY_EVENT_8,
        clock=clock8,
        provenance_json=PROV_EVENT,
        observed_at_us=200,
        from_target_json=canonical(REPO_2),
        to_target_json=canonical(REPO_3),
        from_provider_repository=KEY_PROV_REPO_2,
        to_provider_repository=KEY_PROV_REPO_1,
        parent_report=make_parent_report(event=KEY_EVENT_8, issue=KEY_ISSUE_8),
    )
    store.admit_transfer_event(report8)

    # Query reports for Event 7 specifically
    res7 = store.transfer_event_reports(KEY_EVENT_7)
    assert len(res7) == 1
    r7 = res7[0]
    assert r7.event_resource == KEY_EVENT_7
    assert r7.from_relations[0].target_repository_uuidv4 == REPO_1
    assert r7.to_relations[0].target_repository_uuidv4 == REPO_2
    # Verify no endpoint from Event 8 is attached to Event 7
    assert not any(r.target_repository_uuidv4 == REPO_3 for r in (*r7.from_relations, *r7.to_relations))

    # Query reports filtering by repository REPO_3
    res_repo3 = store.transfer_event_reports(repository_uuidv4=REPO_3)
    assert len(res_repo3) == 1
    assert res_repo3[0].event_resource == KEY_EVENT_8
