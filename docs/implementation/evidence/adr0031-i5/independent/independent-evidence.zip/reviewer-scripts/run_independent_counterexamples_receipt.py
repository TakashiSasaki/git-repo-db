"""Run independent reviewer counterexample suite and produce receipts."""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/home/ubuntu/github/git-repo-db/review/adr0031-i5-independent-20261022")
TEST_FILE = Path("/tmp/i5-independent-review/reviewer-scripts/test_independent_counterexamples.py")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sqlite", choices=("3.51.3", "3.53.1"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)

    lib_dir = (
        "/home/ubuntu/.local/share/git-repo-db-sqlite-3510300"
        if args.sqlite == "3.51.3"
        else "/home/ubuntu/.local/share/git-repo-db-sqlite-3530100"
    )

    env = os.environ.copy()
    env["LD_LIBRARY_PATH"] = lib_dir
    env["PYTHONPATH"] = str(ROOT / "src")

    py = str(ROOT / ".venv/bin/python")
    junit_xml = out / "counterexamples.xml"
    log_file = out / "counterexamples.log"

    cmd = [
        py,
        "-m",
        "pytest",
        "-v",
        str(TEST_FILE),
        f"--junitxml={junit_xml}",
    ]

    t0 = time.time()
    with log_file.open("w") as f:
        proc = subprocess.run(cmd, env=env, cwd=str(ROOT), stdout=f, stderr=subprocess.STDOUT)
    elapsed = time.time() - t0

    receipt = {
        "command": cmd,
        "sqlite_version": args.sqlite,
        "exit_code": proc.returncode,
        "elapsed_seconds": elapsed,
        "junit_xml": str(junit_xml),
    }

    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"Independent counterexamples [{args.sqlite}]: exit {proc.returncode} in {elapsed:.2f}s")
    sys.exit(proc.returncode)

if __name__ == "__main__":
    main()
