# Initial disposable composition failure

The first external proposal copied Resources UPDATE/DELETE guards into its
replacement fragment, while unchanged product context.sql already defined those
same names later. `probe.py newer 3.53.1` exited 1 at `db.executescript(ddl)`:

```text
sqlite3.OperationalError: trigger resources_no_update already exists
```

No test cases executed. The exact attempted composed SQL is retained alongside
this note. The final proposal removes the duplicate definitions and retains the
existing product guards. No product source was patched.
