import json,collections,xml.etree.ElementTree as ET,pathlib,csv
base=pathlib.Path('/workspace/task-g-review/evidence');lanes={}
for label in ('broad-3513-dynamic','broad-3531'):
 path=base/label;rt=ET.parse(path/'regressions.xml');data=[];outcomes={}
 for n in rt.iter('testcase'):
  node=n.attrib.get('file',n.attrib['classname'].replace('.','/'))+'::'+n.attrib['name']
  # JUnit xunit1 classname preserves file-independent node identity via journal crosscheck.
  child=next((x for x in n if x.tag in ('failure','error','skipped')),None)
  outcome='passed' if child is None else child.tag;outcomes[node]=outcome
  if child is None:continue
  body=''.join(child.itertext());code=('I2_TRANSFER_UNSUPPORTED' if 'I2_TRANSFER_UNSUPPORTED' in body else 'I2_IDENTIFICATION_WIRE_UNSUPPORTED' if 'I2_IDENTIFICATION_WIRE_UNSUPPORTED' in body else 'OTHER')
  category={'I2_TRANSFER_UNSUPPORTED':'intended_I3_I5_dependency','I2_IDENTIFICATION_WIRE_UNSUPPORTED':'intended_I6_wire_dependency'}.get(code,'investigate_I2')
  data.append(dict(nodeid=node,phase='setup' if child.tag=='error' else 'call',result=child.tag,code=code,classification=category,assertion_status='later_assertions_unexecuted' if child.tag=='failure' else 'entire_test_body_unexecuted'))
 (path/'failures.json').write_text(json.dumps(data,indent=2))
 with (path/'failures.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 lanes[label]={'counts':dict(collections.Counter((r['classification']+':'+r['phase']) for r in data)),'node_outcomes':outcomes}
summary={'same_outcomes':lanes['broad-3513-dynamic']['node_outcomes']==lanes['broad-3531']['node_outcomes'],'lanes':{k:v['counts'] for k,v in lanes.items()}}
(base/'failure-classification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
