import json,pathlib,xml.etree.ElementTree as ET,hashlib,sys,subprocess
base=pathlib.Path('/workspace/task-g-review');out=base/'evidence'
def read(p):return json.loads(p.read_text())
def results(p):
 r=ET.parse(p);nodes=list(r.iter('testcase'));return dict(executed=len(nodes),passed=sum(not any(c.tag in ('failure','error','skipped') for c in n) for n in nodes),failed=sum(any(c.tag=='failure' for c in n) for n in nodes),errors=sum(any(c.tag=='error' for c in n) for n in nodes),skipped=sum(any(c.tag=='skipped' for c in n) for n in nodes))
lanes={}
for v,b in [('3.51.3','broad-3513-dynamic'),('3.53.1','broad-3531')]:
 s=read(out/b/'summary.json');own=results(out/('sealed-independent-'+v+'.xml'));rt=read(out/b/'input-binding.json')['runtime'];sql=read(out/('sql-'+v)/'summary.json')
 assert s['run']['passed']==2747 and s['run']['failed']==59 and s['run']['error']==20 and s['run']['executed']==2826 and s['run']['exit_code']==1
 assert s['inputs_unchanged'] and s['run']['reconciliation']['consistent_node_execution']
 assert own==dict(executed=46,passed=44,failed=2,errors=0,skipped=0)
 assert sql['total']==sql['passed']==301 and not sql['failures']
 lanes[v]={'broad':s,'reviewer_authored':own,'sql_groups':{k:sql[k] for k in ('total','passed','failures','counts')},'runtime':rt}
inst=[]
for p in sorted((out/'distributions').glob('3.*/outside/sealed-independent.json')):
 d=read(p);assert all(x['ordinary_read_accepted'] and not x['stop_after_candidates'] and x['stop_after_identification'] and x['authority_unchanged'] for x in d['results']);inst.append({'path':str(p.relative_to(base)),**d})
assert len(inst)==4
cmds=read(out/'sealed-independent-commands.json');assert len(cmds)==6 and all(c['exit_code']==1 and c['inputs_unchanged'] for c in cmds)
distribution=read(out/'distributions/summary.json');assert distribution['i2_installed_passed'] and not distribution['original_access_passed']
summary={'verdict':'READY WITH CONDITIONS','verdict_scope':'bounded I2 persistence and mandatory staged refusals','whole_product_acceptance':False,'whole_product_verdict':'NOT READY','assessment_exit_code':1,'input_audit':read(out/'input-audit.json'),'lanes':lanes,'failure_classification':read(out/'failure-classification.json'),'task_a_retention':read(out/'task-a-retention.json'),'distribution':distribution,'installed_independent':inst,'sealed_independent_commands':cmds,'new_finding':{'id':'G-R1','classification':'I7 residual stored-identification coverage','severity':'medium','affected_route':'production Context.candidates','cases_failed_per_runtime':2},'driver_hashes':{p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in ['test_independent.py','installed_independent.py','sealed_independent.py','assess.py']}}
(out/'review-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Both broad cohorts and SQL diagnostics reproduced; reviewer-authored 44 pass / 2 fail per runtime; incomplete full acceptance: exit 1.')
sys.exit(1)
