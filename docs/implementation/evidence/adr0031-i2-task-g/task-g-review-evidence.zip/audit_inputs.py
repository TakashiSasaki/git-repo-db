import pathlib,subprocess,json,hashlib,zipfile
base=pathlib.Path('/workspace/task-g-review');repo=base/'repo'
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
files=git('ls-files').splitlines();manifest={p:{'bytes':(repo/p).stat().st_size,'sha256':sha((repo/p).read_bytes())} for p in files}
(base/'evidence/full-input-manifest.json').write_text(json.dumps(manifest,indent=2))
ix=json.loads((repo/'docs/implementation/evidence/adr0031-i2-task-e/artifact-index.json').read_text());zpath=repo/'docs/implementation/evidence/adr0031-i2-task-e/task-e-evidence.zip'
with zipfile.ZipFile(zpath) as z:
 verify=[x['path'] for x in ix['members'] if len(z.read(x['path']))!=x['bytes'] or sha(z.read(x['path']))!=x['sha256']]
summary=dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),executed_commit=ix['executed_commit'],executed_tree=git('rev-parse',ix['executed_commit']+'^{tree}'),tracked_files=len(files),status=git('status','--porcelain','--untracked-files=no'),manifest_sha256=sha((base/'evidence/full-input-manifest.json').read_bytes()),published_delta=git('diff','--name-status',ix['executed_commit'],'HEAD'),source_tests_identical=not bool(git('diff',ix['executed_commit'],'HEAD','--','src','tests','scripts','pyproject.toml','uv.lock')),author_archive_sha256=sha(zpath.read_bytes()),author_archive_matches=sha(zpath.read_bytes())==ix['archive']['sha256'],author_members=len(ix['members']),author_mismatches=verify)
(base/'evidence/input-audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
