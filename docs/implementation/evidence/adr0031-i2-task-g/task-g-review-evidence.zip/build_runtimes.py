import subprocess,json,hashlib,urllib.request,zipfile,pathlib,time,sys,platform
root=pathlib.Path('/workspace/task-g-review/runtime'); builds=[]
for v,num in [('3.51.3','3510300'),('3.53.1','3530100')]:
 url=f'https://sqlite.org/2026/sqlite-amalgamation-{num}.zip'; archive=root/f'{num}.zip'
 urllib.request.urlretrieve(url,archive)
 with zipfile.ZipFile(archive) as z:z.extractall(root)
 source=root/f'sqlite-amalgamation-{num}'/'sqlite3.c'; out=root/v;out.mkdir(exist_ok=True)
 argv=['gcc','-O1','-g0','-fPIC','-shared','-DSQLITE_THREADSAFE=1','-DSQLITE_ENABLE_FTS5','-DSQLITE_ENABLE_COLUMN_METADATA','-DSQLITE_ENABLE_RTREE',str(source),'-o',str(out/'libsqlite3.so.0'),'-lm','-ldl','-lpthread']
 t=time.time(); p=subprocess.run(argv,capture_output=True,text=True)
 (out/'build.log').write_text(p.stdout+p.stderr)
 builds.append(dict(version=v,url=url,argv=argv,exit_code=p.returncode,seconds=time.time()-t,files={str(x.relative_to(root)):dict(bytes=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in [archive,source,source.with_suffix('.h'),source.parent/'sqlite3ext.h',out/'libsqlite3.so.0']}))
 (root/'provenance.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),compiler=subprocess.check_output(['gcc','--version'],text=True),builds=builds),indent=2))
 print(v,p.returncode,flush=True)
