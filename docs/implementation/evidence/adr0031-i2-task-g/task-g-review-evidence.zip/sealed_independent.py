import pathlib,json,hashlib,subprocess,os,time,sys
base=pathlib.Path('/workspace/task-g-review');out=base/'evidence';inputs=['test_independent.py','installed_independent.py']
def hashes():return {p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in inputs}
original=hashes();receipts=[]
def run(argv,env,log,label):
 start=time.time()
 with log.open('w') as f:p=subprocess.run(argv,env=env,cwd=base,stdout=f,stderr=subprocess.STDOUT)
 r=dict(label=label,argv=argv,cwd=str(base),started_epoch=start,elapsed_seconds=time.time()-start,exit_code=p.returncode,inputs=hashes(),inputs_unchanged=hashes()==original)
 receipts.append(r);(out/'sealed-independent-commands.json').write_text(json.dumps(receipts,indent=2))
for v in ('3.51.3','3.53.1'):
 env=dict(os.environ,LD_LIBRARY_PATH=str(base/'runtime'/v),PYTHONPATH=str(base/'repo/src')+':'+str(base/'repo'))
 run([str(base/'venv/bin/python'),'-m','pytest',str(base/'test_independent.py'),'-q','--junitxml='+str(out/('sealed-independent-'+v+'.xml'))],env,out/('sealed-independent-'+v+'.log'),v+'-46-case')
 for a in ('wheel','sdist-wheel'):
  artifact=out/'distributions'/(v+'-'+a);script=artifact/'outside/installed_independent.py'
  assert hashlib.sha256(script.read_bytes()).hexdigest()==original['installed_independent.py']
  run([str(artifact/'venv/bin/python'),'-I',str(script),str(artifact/'outside/sealed-independent.json')],env,out/('sealed-installed-'+v+'-'+a+'.log'),v+'-'+a+'-installed-independent')
print([(r['label'],r['exit_code'],r['inputs_unchanged']) for r in receipts])
