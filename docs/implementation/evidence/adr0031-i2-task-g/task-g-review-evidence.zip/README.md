# Task G review artifacts

Read [REPORT.md](REPORT.md) for the scoped verdict, exact inputs, results, failure classification and new G-R1 counterexample. The reviewer changed no tracked product, test, ADR or existing GitHub PR. No publication was performed.

All paths below are relative to this review directory. `repo/` is a detached worktree at PR #124's exact HEAD. `venv/` uses dynamically linked `/usr/bin/python3.13`; the preinstalled static Python is unsuitable for substituting SQLite 3.51.3.

```sh
python build_runtimes.py
cd repo
VIRTUAL_ENV=/workspace/task-g-review/venv uv sync --frozen --all-groups --active
LD_LIBRARY_PATH=../runtime/3.51.3 PYTHONPATH=src ../venv/bin/python scripts/verify_i2.py --sqlite 3.51.3 --output /absolute/new-broad-3513
LD_LIBRARY_PATH=../runtime/3.53.1 PYTHONPATH=src ../venv/bin/python scripts/verify_i2.py --sqlite 3.53.1 --output /absolute/new-broad-3531
LD_LIBRARY_PATH=../runtime/3.51.3 PYTHONPATH=src ../venv/bin/python scripts/verify_i2_sql_counterexamples.py . 3.51.3 /absolute/new-sql-3513
```

Repeat the SQL driver with 3.53.1. Use fresh output directories. Expected broad exit is 1; SQL exit is 0. These existing Author drivers are re-executions, not independently authored tests.

Independent counterexamples:

```sh
LD_LIBRARY_PATH=/workspace/task-g-review/runtime/3.51.3 PYTHONPATH=/workspace/task-g-review/repo/src:/workspace/task-g-review/repo /workspace/task-g-review/venv/bin/python -m pytest /workspace/task-g-review/test_independent.py -q
```

Repeat with 3.53.1. Expected current result: 44 pass, 2 fail, exit 1. `sealed_independent.py` captures these child processes and installed counterexample attempts with exact driver hashes. Its exit 0 means capture completed; inspect the recorded child exits. `assess.py` records the summary and exits 1 for incomplete acceptance.

The original distribution reproduction script is preserved at `reproduction/distributions.py`. It was extracted unchanged from the hash-verified Author archive. Invoke with repository path, exact HEAD, fresh output directory and `--runtime-root` pointing to the independently built version-named library directories. It builds direct wheel/sdist-wheel and runs both installed I2 and unchanged Access smokes. Current orchestrator exit is 1. Run `installed_independent.py OUTPUT_JSON` with each isolated venv's `python -I` outside checkout to reproduce G-R1 without source imports.

Evidence layout:

- `evidence/broad-3513-dynamic/`, `broad-3531/`: complete collection, selected nodes, logs, XML, JSONL phases, input bindings, reconciliation and per-node failure CSV/JSON.
- `evidence/sql-3.51.3/`, `sql-3.53.1/`: 301-case summaries, product/old SQL, full statements/errors/rowsets and inventories.
- `evidence/sealed-independent-*`: final 46-case logs/XML and per-process input hashes/exits.
- `evidence/distributions/`: build/install commands, artifact hashes, installed-file manifests, runtime origins and four Author/original smoke outcomes. Portable archive retains receipts and built wheels; the full source sdist, venvs and extracted sources stay local.
- `evidence/distributions/*/outside/sealed-independent.json`: final independent installed reproduction, both Global and Scoped outcomes.
- `evidence/task-a-*`: retained original-node comparison and all four actual first failure traces.
- `runtime/provenance.json`: official sources, build commands and hashes.
- `sources/`: read-only GitHub PR metadata snapshots.
- `artifact-index.json`: size/hash of every portable member; `task-g-review-evidence.zip` is separately hashed in `archive-receipt.json`.

Preliminary/static-runtime and initial installed diagnostic failures remain clearly separate from final execution. No preliminary run is added to the final case counts. The portable archive excludes databases, runtime binaries, venvs, full extracted source copies and nested predecessor evidence archives.
