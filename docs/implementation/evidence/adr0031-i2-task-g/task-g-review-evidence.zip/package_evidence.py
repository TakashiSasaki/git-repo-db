import pathlib,json,hashlib,zipfile
base=pathlib.Path('/workspace/task-g-review');paths=[]
for name in ['REPORT.md','README.md','test_independent.py','installed_independent.py','sealed_independent.py','classify.py','audit_inputs.py','build_runtimes.py','assess.py','package_evidence.py']:
 paths.append(base/name)
for folder in ['sources','reproduction']:
 paths.extend(x for x in (base/folder).rglob('*') if x.is_file())
paths.append(base/'runtime/provenance.json')
paths.extend((base/'runtime').glob('3.*/build.log'))
for p in (base/'evidence').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(base/'evidence');parts=rel.parts
 if parts[0]=='distributions':
  if len(parts)>1 and parts[1] in ('source','sdist-source','source.tar.gz'):continue
  if 'venv' in parts:continue
  if p.suffix in ('.sqlite3','.db','.pyc') or '__pycache__' in parts:continue
  if len(parts)>1 and parts[1] in ('dist','sdist-wheel') and p.suffix!='.whl':continue
  if 'outside' in parts and p.suffix not in ('.json','.py'):continue
 paths.append(p)
paths=sorted(set(paths))
entries=[dict(path=str(p.relative_to(base)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
index={'format':'git-repo-db-task-g-independent-review-v1','head':'4cb90d35bd9c572239496a24cb0dd62049029235','tree':'991d588051766ef1b6ba7c1db9309d60caf47fee','independent_review':True,'verdict':'READY WITH CONDITIONS','full_acceptance':False,'index_excludes_itself':True,'members':entries}
(base/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
zpath=base/'task-g-review-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(base))
 z.write(base/'artifact-index.json','artifact-index.json')
with zipfile.ZipFile(zpath) as z:
 mismatches=[e['path'] for e in entries if len(z.read(e['path']))!=e['bytes'] or hashlib.sha256(z.read(e['path'])).hexdigest()!=e['sha256']]
 assert not mismatches
 assert set(z.namelist())=={e['path'] for e in entries}|{'artifact-index.json'}
receipt=dict(path=zpath.name,bytes=zpath.stat().st_size,sha256=hashlib.sha256(zpath.read_bytes()).hexdigest(),indexed_members=len(entries),archive_members=len(entries)+1,verified=True,mismatches=mismatches,index_sha256=hashlib.sha256((base/'artifact-index.json').read_bytes()).hexdigest())
(base/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
