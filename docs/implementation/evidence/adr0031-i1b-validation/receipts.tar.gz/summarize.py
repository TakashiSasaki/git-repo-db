import collections
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

BASE=Path(__file__).parent
lanes={}
for path in sorted(BASE.glob('*/receipt.json')):
    r=json.loads(path.read_text())
    keys=('label','head','tree','sqlite','sqlite_source_id','interpreter','collected','collection_errors','selected','executed','passed','failed','errored','skipped','xfailed','deselected','exit_code','wall_seconds','inputs_unchanged','selected_equals_executed','selected_equals_junit','every_executed_has_three_phases','failures')
    lanes[r['label']]={k:r[k] for k in keys if k in r}

final={}
modules={}
for version in ('3513','3531'):
    path=BASE/('final-r2-broad-'+version)
    r=json.loads((path/'receipt.json').read_text())
    events=[json.loads(s) for s in (path/'journal.jsonl').read_text().splitlines()]
    selected=(path/'selected.txt').read_text().splitlines()
    starts=[e['nodeid'] for e in events if e['event']=='start']
    finishes=[e['nodeid'] for e in events if e['event']=='finish']
    phases=collections.defaultdict(list)
    for e in events:
        if e['event']=='phase':phases[e['nodeid']].append(e)
    assert collections.Counter(selected)==collections.Counter(starts)==collections.Counter(finishes)
    assert len(set(selected))==len(selected)
    assert all(collections.Counter(e['phase'] for e in es)=={'setup':1,'call':1,'teardown':1} for es in phases.values())
    expected_junit=[]
    for node in selected:
        module_path,rest=node.split('::',1)
        prefix,bracket,parameters=rest.partition('[')
        parts=prefix.split('::')
        expected_junit.append(('.'.join([module_path[:-3].replace('/','.'),*parts[:-1]]),parts[-1]+bracket+parameters))
    actual_junit=[(c.get('classname'),c.get('name')) for c in ET.parse(path/'junit.xml').findall('.//testcase')]
    assert collections.Counter(expected_junit)==collections.Counter(actual_junit)
    assert r['inputs_unchanged']
    mods=collections.defaultdict(collections.Counter)
    failures={}
    for node,es in phases.items():
        call=next(e for e in es if e['phase']=='call')
        errors=[e for e in es if e['phase']!='call' and e['outcome']=='failed']
        outcome='errored' if errors else ('xfailed' if call['wasxfail'] and call['outcome']=='skipped' else call['outcome'])
        module=node.split('::')[0]
        mods[module]['executed']+=1
        mods[module][outcome]+=1
        if outcome in ('failed','errored'):
            text='\n'.join(e['longrepr'] for e in es if e['outcome']=='failed')
            category='I2 generalized composite-local Resource persistence' if 'Current packaged DDL requires nonempty scalar local document IDs' in text else 'UNRESOLVED: inspect exact stack'
            failures[node]={'category':category,'first_failure':text}
    final[version]={'receipt':lanes[r['label']], 'failures':failures,'three_way_node_reconciliation':True,
                    'junit_reconciliation_note':'The preserved runner field selected_equals_junit=false was a work-only parser bug: four parameter IDs contain literal :: (IPv6/ext URI). This reconciliation splits only the unparametrized prefix, preserves complete parameter text and verifies duplicate-aware classname/name counters against raw JUnit. No test node was missing or substituted.'}
    modules[version]=mods

left=json.loads((BASE/'final-r2-broad-3513/receipt.json').read_text())
right=json.loads((BASE/'final-r2-broad-3531/receipt.json').read_text())
assert left['input_hashes']==right['input_hashes']
assert set(final['3513']['failures'])==set(final['3531']['failures'])
ordinary=set((BASE/'final-r2-ordinary-3531/selected.txt').read_text().splitlines())
cohort=set((BASE/'final-r2-broad-3531/selected.txt').read_text().splitlines())
assert cohort<=ordinary
(BASE/'ordinary-not-executed-on-final-freeze.txt').write_text(''.join(n+'\n' for n in sorted(ordinary-cohort)))
summary={'scope':'Development integration validation; no product/distribution/release acceptance',
         'lanes':lanes,'final':final,'modules':modules,
         'frozen_inputs':len(left['input_hashes']),
         'same_inputs_across_runtimes':True,
         'ordinary_not_executed_on_final_freeze':len(ordinary-cohort),
         'diagnostic_broad2_interruption':'Intentional SIGINT after Access/P1-P7 integration portion, during unrelated legacy tests. 2090 starts, 2089 completed; 2046 passed, 43 failed, one incomplete. Original runner defaulted missing-call to skipped=1; raw receipt is retained unchanged and is superseded only for that classification here. Not a complete/passing run.',
         'invalid_minimum_attempt':'baseline-intake-3513 actually loaded SQLite 3.49.1 from uv managed Python. 48 failures, not supported-runtime validation; retained. Corrected by explicit /usr/bin/python3.13 binding and exact SQL version/source-ID checks.',
         'baseline_collection':'First raw collection lacked declared docs dependency PyYAML and found two obsolete module-level native ResourceKey fixtures. After uv sync --frozen --group docs, baseline-ordinary-3531 retained the two actual fixture errors. Final ordinary collection is complete with no errors.'}
(BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

with (BASE/'failure-disposition.csv').open('w') as stream:
    writer=csv.writer(stream,lineterminator="\n")
    writer.writerow(('node','first_recorded_lane','diagnostic_first_failure','final_disposition','first_reached_layer','unexecuted_stage'))
    seen=set()
    for lane in ('diagnostic-broad2-3531','final-broad-3531'):
        for c in ET.parse(BASE/lane/'junit.xml').findall('.//testcase'):
            fail=c.find('failure')
            if fail is None:fail=c.find('error')
            if fail is None:continue
            node=c.get('classname').replace('.','/')+'.py::'+c.get('name')
            if node in seen:continue
            seen.add(node)
            remains=node in final['3531']['failures']
            packaging='tests/packaging/' in node
            writer.writerow((node,lane,fail.get('message','').splitlines()[0],
                             'remaining I2 dependency' if remains else ('packaging interpreter selection repaired; passed on both final runtimes' if packaging else 'obsolete fixture/reference repaired; passed on both final runtimes'),
                             'ContextStore.resource scalar-local storage gate' if remains else ('sdist-derived wheel build environment' if packaging else 'native/serialized fixture boundary'),
                             'downstream semantic/Transfer/Exchange assertions after failed intake' if remains else 'none for this node'))
print(json.dumps({'lanes':{k:v for k,v in lanes.items() if k.startswith('final-')},'ordinary_unexecuted':len(ordinary-cohort)},indent=2))
