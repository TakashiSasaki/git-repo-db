import collections
import hashlib
import json
import os
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/git-repo-db')
BASE = Path(__file__).parent
label, mode, *args = sys.argv[1:]
out = BASE / label
out.mkdir()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
def inputs():
    paths = git('ls-files', 'src', 'tests', 'scripts', 'pyproject.toml', 'uv.lock', '.python-version', '.github/workflows').splitlines()
    return {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
before=inputs()
env=dict(os.environ)
env['PATH']=str(Path(sys.executable).parent) + os.pathsep + env['PATH']
env['PYTHONPATH']=str(BASE) + os.pathsep + str(ROOT) + os.pathsep + str(ROOT/'src')
env['ADR31_RECEIPT']=str(out)
env['RESOURCE_IDENTITY_SQL_REPORT']=str(out/'sql-runtime.json')
if mode in ('collect', 'test'):
    command=[sys.executable, '-m', 'pytest', '-p', 'receipt_plugin', '-q', '-m', 'not live and not benchmark', *args]
    command+=['--collect-only'] if mode=='collect' else ['--junitxml='+str(out/'junit.xml')]
else:
    command=[sys.executable, *args]
db=sqlite3.connect(':memory:')
receipt={'label':label,'mode':mode,'command':command,'cwd':str(ROOT),'python':sys.version,'interpreter':sys.executable,
 'harness_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'run.py',BASE/'receipt_plugin.py')},
 'sqlite':sqlite3.sqlite_version,'sqlite_source_id':db.execute('select sqlite_source_id()').fetchone()[0],
 'compile_options':[r[0] for r in db.execute('pragma compile_options')],
 'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain'),
 'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'],cwd=ROOT)).hexdigest(),
 'input_hashes':before,'environment_overrides':{k:env.get(k) for k in ('PATH','PYTHONPATH','LD_LIBRARY_PATH','ADR31_RECEIPT','RESOURCE_IDENTITY_SQL_REPORT','TMPDIR','REPO_CATALOG_WHEELHOUSE')}}
t=time.monotonic()
with (out/'output.log').open('w') as log:
    process=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exit_code=process.returncode,wall_seconds=time.monotonic()-t,inputs_unchanged=before==inputs())
events=[json.loads(s) for s in (out/'journal.jsonl').read_text().splitlines()] if (out/'journal.jsonl').exists() else []
selected=(out/'selected.txt').read_text().splitlines() if (out/'selected.txt').exists() else []
starts=[e['nodeid'] for e in events if e['event']=='start']
phase=collections.defaultdict(dict)
for e in events:
    if e['event']=='phase': phase[e['nodeid']][e['phase']]=e
counts=collections.Counter()
failures={}
for node, reports in phase.items():
    errors=[r for k,r in reports.items() if k!='call' and r['outcome']=='failed']
    call=reports.get('call',{})
    result='errored' if errors else ('xfailed' if call.get('wasxfail') and call.get('outcome')=='skipped' else call.get('outcome','skipped'))
    counts[result]+=1
    if result in ('failed','errored'): failures[node]=result
receipt.update(collected=len(selected)+sum(len(e['nodes']) for e in events if e['event']=='deselected'),
 collection_errors=sum(e['event']=='collection_error' for e in events),
 selected=len(selected),executed=len(starts),passed=counts['passed'],failed=counts['failed'],errored=counts['errored'],skipped=counts['skipped'],xfailed=counts['xfailed'],
 deselected=sum(len(e['nodes']) for e in events if e['event']=='deselected'),failures=failures,
 selected_equals_executed=collections.Counter(selected)==collections.Counter(starts),
 every_executed_has_three_phases=all(set(phase[n])=={'setup','call','teardown'} for n in starts))
if (out/'junit.xml').exists():
    suite=ET.parse(out/'junit.xml')
    receipt['junit_cases']=len(suite.findall('.//testcase'))
    expected=[]
    for n in selected:
        path,*rest=n.split('::')
        expected.append(('.'.join([path[:-3].replace('/','.'),*rest[:-1]]),rest[-1]))
    actual=[(c.get('classname'),c.get('name')) for c in suite.findall('.//testcase')]
    receipt['selected_equals_junit']=collections.Counter(expected)==collections.Counter(actual)
if mode=='script' and args==['scripts/verify_access_distribution.py']:
    dist=ROOT/'artifacts/access-registry/distribution.json'
    if dist.exists():
        import shutil
        shutil.copyfile(dist,out/'distribution.json')
receipt['artifact_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k in ('label','exit_code','wall_seconds','sqlite','collected','selected','executed','passed','failed','errored','skipped','xfailed','deselected','selected_equals_executed','inputs_unchanged')},indent=2))
sys.exit(process.returncode)
