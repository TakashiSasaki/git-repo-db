import ast
import json
from pathlib import Path

ROOT=Path('/workspace/git-repo-db')
rows=[]
def scan(path,source,container=None):
    try:tree=ast.parse(source)
    except SyntaxError:return
    for node in ast.walk(tree):
        if isinstance(node,ast.Call):
            function=ast.unparse(node.func)
            if function=='ResourceKey' or function.startswith('ResourceKey.'):
                category='strict serialized reconstruction or intentional refusal' if function=='ResourceKey' else ('native identity' if function=='ResourceKey.from_native' else 'explicit native factory or contract decoder')
                rows.append(dict(path=str(path.relative_to(ROOT)),line=node.lineno,embedded_at=container,call=ast.get_source_segment(source,node),boundary=category))
        if container is None and isinstance(node,ast.Constant) and type(node.value)is str and ('ResourceKey(' in node.value or 'ResourceKey.' in node.value):
            scan(path,node.value,node.lineno)
for directory in ('tests','scripts'):
    for path in sorted((ROOT/directory).rglob('*.py')):scan(path,path.read_text())
output={'scope':'All active tests/**/*.py and scripts/**/*.py; direct AST calls and parseable embedded Python strings; no indirect alias/data-flow proof','calls':rows}
Path(__file__).with_name('active-boundary-audit.json').write_text(json.dumps(output,indent=2)+'\n')
print(len(rows),'active constructor/factory calls inventoried')
