import json
import os
from pathlib import Path

_encode = json.JSONEncoder(ensure_ascii=True, sort_keys=True).encode
_base = Path(os.environ['ADR31_RECEIPT'])
_stream = (_base / 'journal.jsonl').open('w')

def event(**data):
    _stream.write(_encode(data) + '\n')
    _stream.flush()

def pytest_collection_finish(session):
    (_base / 'selected.txt').write_text(''.join(i.nodeid + '\n' for i in session.items))
    event(event='collection', selected=len(session.items), collected=session.testscollected)

def pytest_deselected(items):
    event(event='deselected', nodes=[i.nodeid for i in items])

def pytest_collectreport(report):
    if report.failed:
        event(event='collection_error', nodeid=report.nodeid, longrepr=str(report.longrepr))

def pytest_runtest_logstart(nodeid, location):
    event(event='start', nodeid=nodeid)

def pytest_runtest_logreport(report):
    event(event='phase', nodeid=report.nodeid, phase=report.when,
          outcome=report.outcome, duration=report.duration,
          wasxfail=str(getattr(report, 'wasxfail', '')),
          longrepr=str(report.longrepr) if report.failed else '')

def pytest_runtest_logfinish(nodeid, location):
    event(event='finish', nodeid=nodeid)

def pytest_sessionfinish(session, exitstatus):
    event(event='sessionfinish', exitcode=int(exitstatus))
