import json
import os
from pathlib import Path
import subprocess
import sys

BASE=Path(__file__).parent
ROOT=Path('/workspace/git-repo-db')
paths=json.loads((BASE/'cohort.json').read_text())
minimum='/workspace/adr0031-min-venv/bin/python'
newer='/workspace/git-repo-db/.venv/bin/python'
def invoke(python,label,mode,args,env):
    result=subprocess.run([python,str(BASE/'run.py'),label,mode,*args],cwd=ROOT,env=env)
    return result.returncode
base=dict(os.environ,TMPDIR='/workspace/adr0031-pytest-tmp')
mini=dict(base,LD_LIBRARY_PATH='/workspace/adr0031-sqlite3513',REPO_CATALOG_WHEELHOUSE='/workspace/adr0031-wheelhouse3513')
pack=[f'tests/packaging/test_p{i}_distribution.py' for i in range(1,8)]
pack+=['tests/integration/p1/test_derivatives.py::test_context_search_resolves_actual_text_fk_in_projection_and_fallback','--basetemp=/workspace/adr0031-pytest-tmp/preflight3513']
if invoke(minimum,'preflight-distribution-fixtures-3513','test',pack,mini):sys.exit(1)
invoke(minimum,'final-distribution-3513','script',['scripts/verify_access_distribution.py'],mini)
for version,python,env in [('3513',minimum,mini),('3531',newer,dict(base,REPO_CATALOG_WHEELHOUSE='/workspace/adr0031-wheelhouse3531'))]:
    for label,mode,args in [('final-r2-ordinary-'+version,'collect',[]),('final-r2-cohort-collection-'+version,'collect',paths),('final-r2-broad-'+version,'test',paths+['--basetemp=/workspace/adr0031-pytest-tmp/finalr2'+version])]:
        code=invoke(python,label,mode,args,env)
        if mode=='collect' and code:sys.exit(code)
