import pathlib,os,subprocess,json,time
root=pathlib.Path('/workspace/i3-parent');out=pathlib.Path('/workspace/i3-review');rows=[]
for version in ('3.51.3','3.53.1'):
 env=dict(os.environ,LD_LIBRARY_PATH='/workspace/i3-runtime/'+version,PYTHONDONTWRITEBYTECODE='1')
 command=[str(root/'.venv/bin/python'),str(out/'probe.py'),'--output',str(out/('probe-'+version+'.json'))]
 r=subprocess.run(command,cwd=root,env=env,text=True,capture_output=True);rows.append({'version':version,'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(out/'probe-processes.json').write_text(json.dumps(rows,indent=2)+'\n');print(version,r.returncode,r.stdout,flush=True)
