import pathlib,subprocess,json,re,hashlib,zipfile,xml.etree.ElementTree as ET,collections,sys,sqlite3
root=pathlib.Path('/workspace/i3-parent');out=pathlib.Path('/workspace/i3-review');base='a54e4432b0514ba5a5fe8e73ddcdbc492f99b95e'
sys.path.insert(0,str(root/'src'))
from repo_catalog.adapters.sqlite import p1_schema

def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def original(path):return subprocess.check_output(['git','show',base+':'+path],cwd=root)
checks={};frozen=git('rev-parse','HEAD')
paths=['docs/adr/0031-generalized-context-resources.md','docs/architecture/context-resource-schema.md','docs/implementation/context-resource-design-handoff.md','src/repo_catalog/adapters/sqlite/p1_ddl/core.sql','src/repo_catalog/adapters/sqlite/p1_ddl/coverage.sql','src/repo_catalog/adapters/sqlite/p1_ddl/operational.sql','src/repo_catalog/adapters/sqlite/p1_ddl/search.sql','src/repo_catalog/domain/resource_identification.py','src/repo_catalog/domain/resource_identity.py','src/repo_catalog/domain/resource_stage.py']
checks['unchanged_inputs']={p:original(p)==(root/p).read_bytes() for p in paths};assert all(checks['unchanged_inputs'].values())
oldsql=original('src/repo_catalog/adapters/sqlite/p1_ddl/context.sql').decode();newsql=(root/'src/repo_catalog/adapters/sqlite/p1_ddl/context.sql').read_text()
def trigger(sql,n):return re.search(r'CREATE TRIGGER '+n+r'\b.*?END;',sql,re.S).group()
checks['both_transfer_fences_exactly_unchanged']=all(trigger(oldsql,n)==trigger(newsql,n) for n in ['i2_transfer_stage_fence','i2_transfer_report_stage_fence']);assert checks['both_transfer_fences_exactly_unchanged']
checks['context_table_set_unchanged']=set(re.findall(r'CREATE TABLE (\w+)',oldsql))==set(re.findall(r'CREATE TABLE (\w+)',newsql));assert checks['context_table_set_unchanged']
checks['all_historical_evidence_unchanged']=git('diff','--name-only',base,frozen,'--','docs/implementation/evidence/adr0031-i2-task-e','docs/implementation/evidence/adr0031-i2-task-g','docs/implementation/evidence/context-resource-design')=='';assert checks['all_historical_evidence_unchanged']
oldmanifest=json.loads(original('src/repo_catalog/adapters/sqlite/p1_ddl/fingerprints.json'));newmanifest=p1_schema.expected_ddl_manifest();checks['other_store_fingerprints_unchanged']={n:oldmanifest['stores'][n]==newmanifest['stores'][n] for n in ['core','operational','search']};assert all(checks['other_store_fingerprints_unchanged'].values());p1_schema.verify_declared()
db=sqlite3.connect(':memory:');p1_schema.register_functions(db);p1_schema.configure(db);db.executescript(p1_schema.compose('context'));checks['generated_columns']=[list(r) for r in db.execute('PRAGMA table_xinfo(resource_relations)') if r[6]];assert len(checks['generated_columns'])==5 and all(r[6]==2 for r in checks['generated_columns']);checks['typed_index']=[list(r) for r in db.execute('PRAGMA index_xinfo(parent_report_typed_fk)')];assert len([r for r in checks['typed_index'] if r[5]])==9 and all(r[4]=='BINARY' for r in checks['typed_index'] if r[5]);checks['new_context_fingerprint']=p1_schema.fingerprint('context')
checks['test_delta']=git('diff','--numstat',base,frozen,'--','tests');assert all(line.split()[1]=='0' for line in checks['test_delta'].splitlines())
z=zipfile.ZipFile(root/'docs/implementation/evidence/adr0031-i2-task-g/task-g-review-evidence.zip')
previous=ET.fromstring(z.read('evidence/broad-3513-dynamic/regressions.xml'))
def faults(tree):return {(t.get('classname'),t.get('name')): 'failure' if t.find('failure') is not None else 'error' for t in tree.findall('.//testcase') if t.find('failure') is not None or t.find('error') is not None}
oldfaults=faults(previous);assert len(oldfaults)==79
oldnodes=set(z.read('evidence/broad-3513-dynamic/regressions.selected.txt').decode().splitlines())
checks['author_receipts_reconciled']={}
for version in ['3.51.3','3.53.1']:
 path=pathlib.Path('/workspace/i3-evidence')/('final-'+version);actual=faults(ET.parse(path/'regressions.xml').getroot());nodes=set((path/'regressions.selected.txt').read_text().splitlines());checks['author_receipts_reconciled'][version]={'same_original_79_nodes_and_phases':actual==oldfaults,'all_original_selected_nodes_included':oldnodes<=nodes,'additional_nodes':len(nodes-oldnodes)};assert actual==oldfaults and oldnodes<=nodes
commands=[]
for command in [['.venv/bin/python','scripts/build_p1_schema.py','--check'],['.venv/bin/python','scripts/audit_p1_schema.py','--check'],['.venv/bin/python','scripts/audit_callsite_dependencies.py','--check'],['.venv/bin/python','scripts/audit_context_registration.py','--check'],['.venv/bin/ruff','check','src','tests','scripts'],['.venv/bin/ruff','format','--check','src','tests','scripts']]:
 r=subprocess.run(command,cwd=root,text=True,capture_output=True);commands.append({'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stdout+r.stderr
binding={'head':frozen,'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain'),'base':base,'changed_paths':git('diff','--name-status',base,frozen),'checks':checks,'static_commands':commands}
assert not binding['status'];(out/'independent-audit.json').write_text(json.dumps(binding,indent=2)+'\n');print('Independent schema/source/receipt audits passed')
