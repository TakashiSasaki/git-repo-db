import pathlib, subprocess, os, json, time, hashlib, sys, xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/i3-parent');out=pathlib.Path('/workspace/i3-review'); receipts=[]
selected=['tests/integration/p3/test_parent_reports.py','tests/integration/p1/test_schema.py','tests/integration/p1/test_coverage.py','tests/integration/p1/test_generalized_resources.py','tests/unit/test_resource_identification.py','tests/integration/access/test_registry_isolation.py']
for version in ['3.51.3','3.53.1']:
 env=dict(os.environ,LD_LIBRARY_PATH='/workspace/i3-runtime/'+version,PYTHONDONTWRITEBYTECODE='1')
 cmd=[str(root/'.venv/bin/python'),'-m','pytest','-q','-o','addopts=--strict-markers','-p','no:cacheprovider',*selected,'--junitxml='+str(out/(version+'.xml')),'--basetemp='+str(out/('tmp-'+version))]
 started=time.time();r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True)
 (out/(version+'.stdout')).write_text(r.stdout);(out/(version+'.stderr')).write_text(r.stderr)
 cases=ET.parse(out/(version+'.xml')).findall('.//testcase')
 counts={'executed':len(cases),'failed':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}; counts['passed']=counts['executed']-counts['failed']-counts['errors']-counts['skipped']
 receipts.append({'sqlite_library':env['LD_LIBRARY_PATH'],'command':cmd,'exit_code':r.returncode,'counts':counts,'started':started,'elapsed':time.time()-started})
 print(version,r.returncode,counts,flush=True)
 (out/'pytest-processes.json').write_text(json.dumps(receipts,indent=2)+'\n')
