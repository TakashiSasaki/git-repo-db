import pathlib,subprocess,os,tarfile,json,hashlib,sys
root=pathlib.Path('/workspace/i3-parent');out=pathlib.Path('/workspace/i3-review/packages');out.mkdir();source=out/'source';source.mkdir();head='61c87ced5245caf3a991592a8eb745eef7126177'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
receipts=[]
def run(label,cmd,cwd,env=None):
 r=subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,text=True,capture_output=True);(out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr);receipts.append({'label':label,'command':[str(x) for x in cmd],'cwd':str(cwd),'exit_code':r.returncode});(out/'processes.json').write_text(json.dumps(receipts,indent=2)+'\n');assert r.returncode==0,(label,r.stderr);return r
archive=out/'source.tar.gz'
with archive.open('wb') as f:r=subprocess.run(['git','archive','--format=tar.gz',head],cwd=root,stdout=f)
assert r.returncode==0
with tarfile.open(archive) as tf:tf.extractall(source,filter='data')
python=root/'.venv/bin/python'
run('direct-build',['uv','build','--python',python,'--offline','--no-build-isolation','--out-dir',out/'direct'],source)
sdist=next((out/'direct').glob('*.tar.gz'))
with tarfile.open(sdist) as tf:tf.extractall(out/'unpacked',filter='data')
rebuild=next((out/'unpacked').iterdir());run('sdist-build',['uv','build','--python',python,'--wheel','--offline','--no-build-isolation','--out-dir',out/'sdist-wheel'],rebuild)
wheels={'wheel':next((out/'direct').glob('*.whl')),'sdist-wheel':next((out/'sdist-wheel').glob('*.whl'))};results=[]
env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
for version in ('3.51.3','3.53.1'):
 for variant,wheel in wheels.items():
  label=version+'-'+variant;base=out/label;base.mkdir();venv=base/'venv';outside=base/'outside';outside.mkdir()
  run(label+'-venv',['uv','venv','--offline','--python',python,venv],outside,env)
  run(label+'-install',['uv','pip','install','--offline','--python',venv/'bin/python','--no-deps',wheel],outside,env)
  lane=dict(env,LD_LIBRARY_PATH='/workspace/i3-runtime/'+version)
  run(label+'-probe',[venv/'bin/python','-I','/workspace/i3-review/probe.py','--output',base/'probe.json'],outside,lane)
  probe=json.loads((base/'probe.json').read_text());assert probe['runtime']['sqlite_version']==version;origin=pathlib.Path(probe['runtime']['module_origin']);assert origin.is_relative_to(venv)
  package=origin.parents[2];assert package.name=='repo_catalog',package
  files={}
  for p in package.rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
    rel=p.relative_to(package);original=source/'src/repo_catalog'/rel;files[str(rel)]={'sha256':sha(p),'source_sha256':sha(original)}
  assert all(v['sha256']==v['source_sha256'] for v in files.values())
  (base/'installed-files.json').write_text(json.dumps(files,indent=2)+'\n')
  results.append({'version':version,'variant':variant,'probe_groups':probe['groups_executed'],'probe_passes':probe['groups_passed'],'exit_code':0,'file_count':len(files),'all_source_hashes_match':True,'wheel_sha256':sha(wheel),'source_id':probe['runtime']['sqlite_source_id']})
summary={'head':head,'source_archive_sha256':sha(archive),'sdist_sha256':sha(sdist),'wheels':{n:sha(p) for n,p in wheels.items()},'results':results}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
