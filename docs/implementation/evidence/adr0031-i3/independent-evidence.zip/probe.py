"""Independently authored I3 SQL and production API counterexamples."""
import argparse, pathlib, sqlite3, json, tempfile, hashlib, traceback
from repo_catalog.adapters.sqlite import p1_schema
from repo_catalog.adapters.sqlite.production_context import Context
from repo_catalog.domain.p1_context import ResourceKey
from repo_catalog.domain.resource_identification import ResourceIdentification as RI
from repo_catalog.domain.production_context import ResourceRelation,ContextError

S='6f6e4777-a077-4a3f-84fe-f1442501cd4a'
R='b39f0953-9b44-477d-9a05-09675996a50c'
C='a2d38291-770f-4db6-bdd9-c6cff47d5f63'
def J(v):return json.dumps(v,ensure_ascii=True,sort_keys=True,separators=(',',':'),allow_nan=False)
columns='service_instance_uuidv4,resource_kind,provider_resource_id,relation_kind,members_json,provenance_json,scope_json,observed_at_us'
SQL='INSERT INTO resource_relations('+columns+') VALUES(?,?,?,?,?,?,?,?)'
P=J({'source':'independent-I3-review','evidence':['capture','independent-clock']})
child=(S,'document',J(['global-review',['',[]]]))
parent=(S,'project',J(['P','7']))
def report(m=parent,observed=None,clock=None,provenance=P):return (*child,'parent',J([m]),provenance,J({'state':'complete','clock':{'domain':'original-review-clock','at_us':clock},'document_kind':None}),observed)
def resource(d,key,meta=(None,None,None,None)):
 d.execute('INSERT INTO resources(service_instance_uuidv4,resource_kind,provider_resource_id,identifier_namespace_kind,identifier_namespace_id,document_kind,provider_document_id) VALUES(?,?,?,?,?,?,?)',(*key,*meta))
def raw():
 d=sqlite3.connect(':memory:',isolation_level=None);p1_schema.register_functions(d);p1_schema.configure(d);d.executescript(p1_schema.compose('context'));d.execute('INSERT INTO providers VALUES(?,?,?)',(S,'review','{}'));resource(d,child,(None,None,None,child[2]));return d
def rows(d):return {n: sorted(d.execute('SELECT * FROM "'+n+'"').fetchall(),key=J) for n, in d.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
results=[]
def case(name,fn):
 try:
  extra=fn() or {};results.append({'name':name,'pass':True,**extra})
 except Exception as e:results.append({'name':name,'pass':False,'error':repr(e),'trace':traceback.format_exc()})
def refusal(d,sql,row,code=None):
 before=rows(d)
 try:d.execute(sql,row)
 except sqlite3.DatabaseError as e:
  if code is not None:assert e.sqlite_errorcode==code,(e.sqlite_errorcode,e)
  assert rows(d)==before
  return {'extended_code':getattr(e,'sqlite_errorcode',None),'message':str(e)}
 raise AssertionError('Invalid SQL admitted')
def missing():
 d=raw();r=refusal(d,SQL,report(),787);resource(d,parent);assert d.execute('SELECT count(*) FROM resource_relations').fetchone()[0]==0;d.execute(SQL,report());assert d.execute('SELECT source_document_kind,parent_id FROM resource_relations').fetchone()==('',parent[2]);assert d.execute('PRAGMA foreign_key_check').fetchall()==[];return r
case('child-before-parent-no-replay-and-resupply',missing)
for name,idx,value in [('null-members',4,None),('json-null-members',4,'null'),('null-parent-ID',4,J([[S,'project',None]])),('null-parent-kind',4,J([[S,None,J('7')]])),('raw-parent-ID',4,J([[S,'project','7']])),('decoded-parent-ID',4,J([[S,'project',['P','7']]])),('noncanonical-parent-ID',4,J([[S,'project','[ "P","7"]']])),('omitted-subtype',6,J({'state':'complete','clock':{'domain':'original','at_us':None}})),('omitted-clock',6,J({'state':'complete','document_kind':None})),('extra-scope',6,J({'state':'complete','document_kind':None,'clock':{'domain':'original','at_us':None},'x':0})),('boolean-clock',6,J({'state':'complete','document_kind':None,'clock':{'domain':'original','at_us':True}})),('noncanonical-clock',6,'{"state":"complete", "document_kind":null,"clock":{"domain":"original","at_us":null}}'),('noncanonical-provenance',5,P+' '),('null-evidence',5,J({'source':'original','evidence':None})),('missing-parent',4,J([[S,'project',J('missing')]])),('multi-member',4,J([parent,child])),('empty-members',4,'[]')]:
 def invalid(idx=idx,value=value):
  d=raw();resource(d,parent);r=list(report());r[idx]=value;return refusal(d,SQL.replace('INSERT INTO','INSERT OR IGNORE INTO'),r)
 case(name,invalid)
for base_time,next_time in [(None,7),(7,None),(7,8)]:
 for label,sql in [('ignore',SQL.replace('INSERT INTO','INSERT OR IGNORE INTO')),('nothing',SQL+' ON CONFLICT DO NOTHING'),('replace',SQL.replace('INSERT INTO','REPLACE INTO')),('noop',SQL+' ON CONFLICT DO UPDATE SET observed_at_us=resource_relations.observed_at_us')]:
  def conflict(sql=sql,base_time=base_time,next_time=next_time):
   d=raw();resource(d,parent);d.execute(SQL,report(observed=base_time));return refusal(d,sql,report(observed=next_time),1811)
  case('time-rebind-'+label+'-'+str(base_time)+'-'+str(next_time),conflict)
def alternatives():
 d=raw();resource(d,parent);p8=(S,'project',J('P8'));resource(d,p8)
 for r in [report(),report(p8),report(clock=8),report(provenance=J({'source':'other','evidence':'separate'}))]:d.execute(SQL,r)
 assert d.execute('SELECT count(*) FROM resource_relations').fetchone()[0]==4
 d.execute(SQL+' ON CONFLICT DO NOTHING',report());assert d.execute('SELECT count(*) FROM resource_relations').fetchone()[0]==4
 return {'full_rows':rows(d)['resource_relations']}
case('all-actual-key-alternatives-retained',alternatives)
def complete_fk():
 d=raw();resource(d,parent);d.execute(SQL,report());key=report()[:-1]+('',parent[1]);names=columns.split(',')[:-1]+['source_document_kind','parent_kind'];d.execute('CREATE TABLE consumer('+','.join(n+' TEXT NOT NULL' for n in names)+',FOREIGN KEY('+','.join(names)+') REFERENCES resource_relations('+','.join(names)+')) STRICT');sql='INSERT INTO consumer VALUES('+','.join('?' for _ in key)+')';d.execute(sql,key)
 errors=[]
 for i in range(len(key)):
  r=list(key);r[i]+='different';errors.append(refusal(d,sql,r,787))
 return {'components_rejected':len(errors),'errors':errors}
case('complete-nine-component-consumer-reference',complete_fk)
def atomic():
 d=raw();resource(d,parent);r=report();bad=list(r);bad[4]='[]';sql='INSERT INTO resource_relations('+columns+') VALUES(?,?,?,?,?,?,?,?),(?,?,?,?,?,?,?,?)';result=refusal(d,sql,(*r,*bad),1811);d.execute('BEGIN');d.execute('SAVEPOINT s');d.execute(SQL,r);d.execute('ROLLBACK TO s');assert d.execute('SELECT count(*) FROM resource_relations').fetchone()[0]==0;d.execute('RELEASE s');d.execute(SQL,r);d.execute('ROLLBACK');assert d.execute('SELECT count(*) FROM resource_relations').fetchone()[0]==0;return result
case('statement-savepoint-transaction-rollback',atomic)
def native_other_issue():
 d=raw();i7=(S,'issue',J('I7'));i8=(S,'issue',J('I8'));event=(S,'comment',J(['issue',i7[2],'timeline_event',['E','7']]));resource(d,event,('issue',i7[2],'timeline_event',J(['E','7'])));resource(d,i8);r=(*event,'parent',J([i8]),P,J({'clock':{'domain':'original','at_us':None},'document_kind':'timeline_event','state':'complete'}),None);d.execute(SQL,r);before=rows(d)
 er=refusal(d,SQL,(*event,'transfer_event_report','[]',P,'{}',None),1811);assert rows(d)==before
 return er
case('I8-report-without-native-I7-permitted-transfer-fenced',native_other_issue)
def nonleaf_scoped():
 d=raw();pr=(S,'pull_request',J('PR'));scoped=(S,'document',J(['pull_request',pr[2],'body',['D',[]]]));resource(d,scoped,('pull_request',pr[2],'body',J(['D',[]])));resource(d,pr)
 r=(*scoped,'parent',J([pr]),P,J({'clock':{'domain':'x','at_us':1},'document_kind':'body','state':'complete'}),1);d.execute(SQL,r)
 g=report(scoped);d.execute(SQL,g);opaque=(S,'opaque-child',J('C'));resource(d,opaque);d.execute(SQL,(*opaque,'parent',J([child]),P,J({'clock':{'domain':'x','at_us':1},'document_kind':None,'state':'complete'}),1));assert d.execute('SELECT count(*) FROM resource_relations').fetchone()[0]==3
 wrong=list(r);wrong[6]=J({'clock':{'domain':'x','at_us':1},'document_kind':None,'state':'complete'});return refusal(d,SQL,wrong,787)
case('scoped-and-global-Documents-with-children-and-source-type-binding',nonleaf_scoped)
def bounded():
 d=raw();errors=[]
 for scope in ['['*10000+'[]'+']'*10000,J({'value':'a'*262145})]:
  assert d.execute('SELECT p1_parent_report_v1(?,?,?,?,?,?,?)',(*child,report()[4],P,scope,None)).fetchone()==(0,)
 return {'bounded_rejections':2}
case('finite-row-local-predicate',bounded)
def api():
 with tempfile.TemporaryDirectory(prefix='i3-independent-') as p:
  p=pathlib.Path(p);p1_schema.initialize(p/'context.sqlite3','context',R,C);ch=ResourceKey(*child);pa=ResourceKey(*parent);relation=ResourceRelation(ch,'parent',(pa,),P,report()[6],None)
  with Context.transaction(p) as ctx:
   ctx.provider(S,'test');ctx.resource(ch,identification=RI.global_document(ch));before=rows(ctx.db)
   try:ctx.relation(relation)
   except ContextError as e:assert e.code=='RESOURCE_UNAVAILABLE'
   else:raise AssertionError('missing API Parent admitted')
   assert rows(ctx.db)==before
  with Context.transaction(p) as ctx:
   ctx.resource(pa);assert ctx.relations(ch,'parent')==();assert ctx.relation(relation)=='insert';assert ctx.relation(relation)=='duplicate'
   for kwargs,expected in [({'permitted':lambda _:False},'PERMISSION_DENIED'),({'selected_resources':frozenset({ch})},'OMITTED_BY_SELECTION')]:
    before=rows(ctx.db)
    try:ctx.relation(relation,**kwargs)
    except ContextError as e:assert e.code==expected
    else:raise AssertionError('replay bypassed policy')
    assert rows(ctx.db)==before
  with Context.snapshot(p) as ctx:assert ctx.relations(ch,'parent')==(relation,)
 return {'original_observation_time':None,'replay_policy_rechecked':True}
case('production-API-no-deferred-payload-original-resupply-replay-policy',api)
d=raw();runtime={'sqlite_version':sqlite3.sqlite_version,'sqlite_source_id':d.execute('SELECT sqlite_source_id()').fetchone()[0],'options':d.execute('PRAGMA compile_options').fetchall(),'pragmas':{n:d.execute('PRAGMA '+n).fetchone()[0] for n in p1_schema.REQUIRED_PRAGMAS},'module_origin':str(pathlib.Path(p1_schema.__file__).resolve()),'function_flags':[r for r in d.execute('PRAGMA function_list') if r[0]=='p1_parent_report_v1']}
summary={'runtime':runtime,'groups_executed':len(results),'groups_passed':sum(r['pass'] for r in results),'groups_failed':sum(not r['pass'] for r in results),'results':results}
parser=argparse.ArgumentParser();parser.add_argument('--output',type=pathlib.Path,required=True);args=parser.parse_args();args.output.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['results','runtime']}));raise SystemExit(1 if summary['groups_failed'] else 0)
