import pathlib,zipfile,hashlib,json
out=pathlib.Path('/workspace/i3-evidence'); members={}
def add(p,name=None):
 p=pathlib.Path(p); members[name or str(p.relative_to(out))]=p.read_bytes()
for name in ['initial-github-state.json','prepublication-github-state.json','contract-inputs.json','baseline-79.json','author-processes.json','final-processes.json','failure-classification.json','schema-boundary-audit.json','static-checks.json','summary.json','REPORT.md']:
 add(out/name)
for p in (out/'baseline').rglob('*'):
 if p.is_file():add(p)
for prefix in ['author-3.51.3','author-3.53.1','sql-3.51.3','sql-3.53.1','final-3.51.3','final-3.53.1','final-sql-3.51.3','final-sql-3.53.1']:
 for p in (out/prefix).rglob('*'):
  if p.is_file():add(p)
 add(out/(prefix+'.log'))
for name in ['run_author.py','run_final.py','classify.py','audit.py','summarize.py','distributions.py','package_author.py']:
 add(out/name,'reproduction/'+name)
for p in (out/'distributions').iterdir():
 if p.is_file() and p.suffix in {'.json','.stdout','.stderr','.py'}:add(p)
for base in (out/'distributions').iterdir():
 if base.is_dir() and base.name.startswith(('3.51.3-','3.53.1-')):
  add(base/'installed-files.json')
  for name in ['i2.json','i3.json']:add(base/'outside'/name)
add(out/'distributions.log')
add('/workspace/i3-runtime/provenance.json','runtime/provenance.json')
index={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())}
members['member-index.json']=(json.dumps(index,indent=2)+'\n').encode()
archive=out/'author-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):
  info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
checks=[]
with zipfile.ZipFile(archive) as z:
 for name,r in index.items():
  b=z.read(name);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
 assert z.testzip() is None
receipt={'archive':'author-evidence.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'indexed_payload_members':len(index),'zip_members_including_index':len(members),'all_members_verified':True,'executed_head':'61c87ced5245caf3a991592a8eb745eef7126177','executed_tree':'6f259f7239d7330bea4d1dd1b6e04c316561728f','members':index}
(out/'artifact-index.json').write_text(json.dumps(receipt,indent=2)+'\n')
print({k:v for k,v in receipt.items() if k!='members'})
