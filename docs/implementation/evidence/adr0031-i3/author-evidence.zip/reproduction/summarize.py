import pathlib,json,hashlib,subprocess
root=pathlib.Path('/workspace/i3-parent');out=pathlib.Path('/workspace/i3-evidence')
def read(p):return json.loads((out/p).read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
lanes={}
base=set((out/'baseline/regressions.selected.txt').read_text().splitlines())
for v in ('3.51.3','3.53.1'):
 broad=read(f'final-{v}/summary.json');binding=read(f'final-{v}/input-binding.json')
 selected=set((out/f'final-{v}/regressions.selected.txt').read_text().splitlines())
 assert binding['head']==head and binding['tree']==tree and not binding['tracked_status']
 assert base<=selected and len(selected-base)==65
 assert broad['run']['passed']==2812 and broad['run']['failed']==59 and broad['run']['error']==20
 assert broad['parent_reports_overlapping_broad']['passed']==65
 assert broad['run']['reconciliation']['consistent_node_execution'] and broad['inputs_unchanged']
 sql=read(f'final-sql-{v}/summary.json')
 lanes[v]={'runtime':binding['runtime'],'ordinary_collected':broad['ordinary_collected'],'selected':broad['selected'],'unexecuted_ordinary':broad['unexecuted_ordinary'],'all_2826_inherited_selected':base<=selected,'new_parent_nodes':len(selected-base),'broad':broad['run'],'parent_overlapping_broad':broad['parent_reports_overlapping_broad'],'sql_diagnostic':sql,'input_manifest_sha256':hashlib.sha256(json.dumps(binding['inputs'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'inputs_unchanged':True}
summary={'author_verification':True,'whole_product_acceptance':False,'independent_review':'separate_report_required','base_head':'a54e4432b0514ba5a5fe8e73ddcdbc492f99b95e','executed_head':head,'executed_tree':tree,'lanes':lanes,'failure_classification':read('failure-classification.json'),'distributions':read('distributions/summary.json'),'static_checks':read('static-checks.json'),'initial_attempt':{'head':'5abb1140d50f290674758812a99b9b7749e2643d','tree':'49efc948618fdeb7a073f8406027c78a16434934','per_runtime':{'executed':2889,'passed':2808,'failed':61,'error':20,'parent_passed':63},'additional_failures':'two unchanged isolation tests: new opt-in Parent module missing exact-path audit classification; fixed in final; source/receipts retained'},'G_R1':'Open I7 follow-up; Task G evidence inherited, not rerun as complete Recovery','exit_codes':{'broad_per_runtime':1,'parent_per_runtime':0,'sql_per_runtime':0,'distribution_orchestrator':1,'original_access_smoke_each':1,'i2_installed_each':0,'i3_installed_each':0,'author_driver_wrapper':0,'final_driver_wrapper':0}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'executed_head':head,'executed_tree':tree,'runtimes':{v:r['runtime']['sqlite_source_id'] for v,r in lanes.items()}},indent=2))
