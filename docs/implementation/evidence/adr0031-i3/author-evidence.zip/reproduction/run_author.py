import os, subprocess, json, pathlib, time, hashlib
root=pathlib.Path('/workspace/i3-parent')
out=pathlib.Path('/workspace/i3-evidence')
python=root/'.venv/bin/python'
receipts=[]
for version in ('3.51.3','3.53.1'):
 env=dict(os.environ, LD_LIBRARY_PATH=f'/workspace/i3-runtime/{version}', REPO_CATALOG_WHEELHOUSE='/workspace/i3-wheelhouse')
 env['PATH']=str(python.parent)+os.pathsep+env.get('PATH','')
 for name,command in [(f'author-{version}',[str(python),'scripts/verify_i3.py','--sqlite',version,'--output',str(out/f'author-{version}')]),(f'sql-{version}',[str(python),'scripts/verify_i2_sql_counterexamples.py',str(root),version,str(out/f'sql-{version}')])]:
  started=time.time()
  with (out/f'{name}.log').open('w') as log:
   r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipt={'name':name,'command':command,'cwd':str(root),'sqlite_library_path':env['LD_LIBRARY_PATH'],'start_epoch':started,'duration_seconds':time.time()-started,'exit_code':r.returncode}
  receipts.append(receipt); (out/'author-processes.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(json.dumps(receipt),flush=True)
