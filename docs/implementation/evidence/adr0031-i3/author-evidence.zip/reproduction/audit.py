import hashlib,json,pathlib,re,subprocess,sys,os
root=pathlib.Path('/workspace/i3-parent');out=pathlib.Path('/workspace/i3-evidence')
sys.path.insert(0,str(root/'src'))
from repo_catalog.adapters.sqlite import p1_schema
base='a54e4432b0514ba5a5fe8e73ddcdbc492f99b95e'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def original(path):return subprocess.check_output(['git','show',base+':'+path],cwd=root)
oldsql=original('src/repo_catalog/adapters/sqlite/p1_ddl/context.sql').decode()
newsql=(root/'src/repo_catalog/adapters/sqlite/p1_ddl/context.sql').read_text()
def trigger(sql,name):return re.search(r'CREATE TRIGGER '+name+r'\b.*?END;',sql,re.S).group()
oldmanifest=json.loads(original('src/repo_catalog/adapters/sqlite/p1_ddl/fingerprints.json'))
newmanifest=p1_schema.expected_ddl_manifest()
records={}
for store in p1_schema.STORES:
 schema=p1_schema.expected_schema(store)
 records[store]={'fingerprint':p1_schema.fingerprint(store),'tables':[r[1] for r in schema if r[0]=='table'],'schema_rows':schema,'same_fingerprint_as_base':oldmanifest['stores'][store]==newmanifest['stores'][store]}
changed=git('diff','--name-status',base,'HEAD')
unchanged={p:original(p)==(root/p).read_bytes() for p in ['docs/adr/0031-generalized-context-resources.md','docs/architecture/context-resource-schema.md','docs/implementation/context-resource-design-handoff.md','src/repo_catalog/adapters/sqlite/schema.py','src/repo_catalog/adapters/sqlite/p1_ddl/core.sql','src/repo_catalog/adapters/sqlite/p1_ddl/coverage.sql','src/repo_catalog/adapters/sqlite/p1_ddl/operational.sql','src/repo_catalog/adapters/sqlite/p1_ddl/search.sql','src/repo_catalog/domain/resource_identification.py','src/repo_catalog/domain/resource_stage.py','src/repo_catalog/domain/resource_identity.py']}
predecessor_evidence=git('diff','--name-only',base,'HEAD','--','docs/implementation/evidence/adr0031-i2-task-e','docs/implementation/evidence/adr0031-i2-task-g','docs/implementation/evidence/context-resource-design')
audit={'base':base,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'changed_files':changed,'unchanged_required_inputs':unchanged,'predecessor_evidence_diff':predecessor_evidence,'transfer_fences_identical':all(trigger(oldsql,n)==trigger(newsql,n) for n in ['i2_transfer_stage_fence','i2_transfer_report_stage_fence']),'resource_table_and_indexes_before_relations_identical':oldsql[oldsql.index('CREATE TABLE resources('):oldsql.index('CREATE TABLE resource_relations(')]==newsql[newsql.index('CREATE TABLE resources('):newsql.index('CREATE TABLE resource_relations(')],'stores':records}
assert all(unchanged.values()) and not predecessor_evidence and audit['transfer_fences_identical'] and audit['resource_table_and_indexes_before_relations_identical']
assert all(records[s]['same_fingerprint_as_base'] for s in ['core','operational','search'])
assert len(newmanifest['stores']['context']['tables'])==len(oldmanifest['stores']['context']['tables'])
(out/'schema-boundary-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
commands=[]
for command in [['.venv/bin/python','scripts/build_p1_schema.py','--check'],['.venv/bin/python','scripts/audit_p1_schema.py','--check'],['.venv/bin/python','scripts/audit_callsite_dependencies.py','--check'],['.venv/bin/python','scripts/audit_context_registration.py','--check'],['.venv/bin/python','scripts/audit_implementation_boundary.py','--check'],['.venv/bin/ruff','check','src','tests','scripts'],['.venv/bin/ruff','format','--check','src','tests','scripts'],['.venv/bin/python','scripts/ci_execute.py','reports'],['git','diff','--check',base,'HEAD']]:
 result=subprocess.run(command,cwd=root,text=True,capture_output=True)
 commands.append({'command':command,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
(out/'static-checks.json').write_text(json.dumps(commands,indent=2)+'\n')
print([(r['command'][1:3],r['exit_code']) for r in commands])
assert all(r['exit_code']==0 for r in commands)
