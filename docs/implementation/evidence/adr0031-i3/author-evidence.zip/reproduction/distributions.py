"""Build once from a pinned Git archive; attempt both smokes for both artifacts/runtimes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import tarfile
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('repo', type=Path)
    parser.add_argument('commit')
    parser.add_argument('output', type=Path)
    parser.add_argument('--runtime-root', type=Path, default=Path('/workspace/task-e-evidence/runtime'))
    args = parser.parse_args()
    root, out = args.repo.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    for key in ('PYTHONPATH', 'PYTHONHOME', 'GH_TOKEN', 'GITHUB_TOKEN', 'REPO_CATALOG_TEST_BOOTSTRAP'):
        env.pop(key, None)
    commands = []

    def run(label, argv, cwd, current_env=env):
        start = time.time()
        result = subprocess.run(list(map(str, argv)), cwd=cwd, env=current_env,
                                text=True, capture_output=True)
        (out / (label + '.stdout')).write_text(result.stdout)
        (out / (label + '.stderr')).write_text(result.stderr)
        receipt = dict(label=label, argv=list(map(str, argv)), cwd=str(cwd),
                       started_epoch=start, elapsed_seconds=time.time()-start,
                       exit_code=result.returncode)
        commands.append(receipt)
        write(out / 'commands.json', commands)
        return result

    archive = out / 'source.tar.gz'
    with archive.open('wb') as stream:
        result = subprocess.run(['git', 'archive', '--format=tar.gz', args.commit], cwd=root, stdout=stream)
    assert result.returncode == 0
    source = out / 'source'
    source.mkdir()
    with tarfile.open(archive) as tf:
        tf.extractall(source, filter='data')
    build = run('build-direct', ['uv', 'build', '--python', sys.executable, '--offline', '--no-build-isolation', '--out-dir', out / 'dist'], source)
    assert build.returncode == 0
    sdist = next((out / 'dist').glob('*.tar.gz'))
    with tarfile.open(sdist) as tf:
        tf.extractall(out / 'sdist-source', filter='data')
    rebuilt_source = next((out / 'sdist-source').iterdir())
    build = run('build-sdist-wheel', ['uv', 'build', '--python', sys.executable, '--wheel', '--offline', '--no-build-isolation', '--out-dir', out / 'sdist-wheel'], rebuilt_source)
    assert build.returncode == 0
    wheels = {'wheel': next((out / 'dist').glob('*.whl')),
              'sdist-wheel': next((out / 'sdist-wheel').glob('*.whl'))}
    smoke = runpy.run_path(str(source / 'scripts/verify_access_distribution.py'))['SMOKE']
    (out / 'original-access-smoke.py').write_text(smoke)
    inputs = dict(commit=args.commit,
                  tree=subprocess.check_output(['git', 'rev-parse', args.commit+'^{tree}'],cwd=root,text=True).strip(),
                  source_archive_sha256=sha(archive), sdist_sha256=sha(sdist),
                  wheels={name:dict(path=str(path),sha256=sha(path)) for name,path in wheels.items()},
                  original_access_smoke_sha256=sha(out / 'original-access-smoke.py'),
                  new_smoke_sha256=sha(source / 'scripts/verify_i2_distribution.py'))
    write(out / 'inputs.json', inputs)
    results = []
    for version in ('3.51.3', '3.53.1'):
        for name, wheel in wheels.items():
            label = version+'-'+name
            base = out / label
            outside = base / 'outside'
            outside.mkdir(parents=True)
            venv = base / 'venv'
            assert run(label+'-venv', ['uv','venv','--offline','--python',sys.executable,venv], outside).returncode == 0
            python = venv / 'bin/python'
            assert run(label+'-install',['uv','pip','install','--python',python,'--no-deps',wheel],outside).returncode == 0
            lane_env = dict(env, LD_LIBRARY_PATH=str(args.runtime_root / version))
            lane_env['PATH'] = str(venv / 'bin') + os.pathsep + lane_env.get('PATH','')
            runtime = run(label+'-runtime',[python,'-I','-c',"import json,sqlite3,sys,repo_catalog; print(json.dumps(dict(python=sys.executable, origin=repo_catalog.__file__, version=sqlite3.sqlite_version,source=sqlite3.connect(':memory:').execute('SELECT sqlite_source_id()').fetchone()[0])))"],outside,lane_env)
            assert runtime.returncode == 0
            actual = json.loads(runtime.stdout)
            assert actual['version'] == version
            assert Path(actual['origin']).is_relative_to(venv)
            parent_driver = outside / 'verify_i3_distribution.py'
            parent_driver.write_bytes((source / 'scripts/verify_i3_distribution.py').read_bytes())
            parent = run(label+'-i3-smoke',[python,'-I',parent_driver,'--output',outside/'i3.json'],outside,lane_env)
            driver = outside / 'verify_i2_distribution.py'
            driver.write_bytes((source / 'scripts/verify_i2_distribution.py').read_bytes())
            modern = run(label+'-i2-smoke',[python,'-I',driver,'--output',outside/'i2.json'],outside,lane_env)
            installed_files = {}
            installed_package = Path(actual['origin']).parent
            for file in installed_package.rglob('*'):
                if file.is_file() and '__pycache__' not in file.parts and file.suffix != '.pyc':
                    relative = file.relative_to(installed_package)
                    expected = source / 'src/repo_catalog' / relative
                    installed_files[str(relative)] = dict(sha256=sha(file),source_sha256=sha(expected) if expected.is_file() else None)
            binding = all(v['sha256']==v['source_sha256'] for v in installed_files.values())
            write(base / 'installed-files.json', installed_files)
            legacy = run(label+'-original-access-smoke',[python,'-I','-c',smoke],outside,lane_env)
            row = dict(runtime=actual,artifact=name,wheel_sha256=sha(wheel),sdist_sha256=sha(sdist),
                       i2_smoke_exit=modern.returncode,i3_smoke_exit=parent.returncode,installed_files_match_source=binding,
                       original_access_smoke_exit=legacy.returncode)
            if (outside/'i3.json').exists(): row['i3_receipt'] = json.loads((outside/'i3.json').read_text())
            if (outside/'i2.json').exists(): row['i2_receipt'] = json.loads((outside/'i2.json').read_text())
            results.append(row)
            write(out / 'results.json', results)
            print(label,modern.returncode,legacy.returncode,binding,flush=True)
    summary=dict(inputs=inputs,results=results,
                 i3_installed_passed=all(r['i3_smoke_exit']==0 for r in results),
                 i2_installed_passed=all(r['i2_smoke_exit']==0 and r['installed_files_match_source'] for r in results),
                 original_access_passed=all(r['original_access_smoke_exit']==0 for r in results))
    write(out / 'summary.json',summary)
    raise SystemExit(0 if summary['i2_installed_passed'] and summary['original_access_passed'] else 1)


if __name__=='__main__':
    main()
