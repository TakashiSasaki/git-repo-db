"""Compare actual JUnit non-successes with retained Task G's 79-node baseline."""
import collections,json,pathlib,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/i3-evidence')
base=json.loads((root/'baseline-79.json').read_text())
basekeys={(r['class'],r['name']):r for r in base}
summary={}
for version in ('3.51.3','3.53.1'):
 path=root/f'final-{version}'
 if not (path/'regressions.xml').exists(): continue
 current={}
 for tc in ET.parse(path/'regressions.xml').findall('.//testcase'):
  fault=next((tc.find(tag) for tag in ('failure','error') if tc.find(tag) is not None),None)
  if fault is None:continue
  body=''.join(fault.itertext())
  category='remaining_I6_wire' if 'I2_IDENTIFICATION_WIRE_UNSUPPORTED' in body else 'remaining_I4_I5_Transfer' if 'I2_TRANSFER_UNSUPPORTED' in body else 'unexpected'
  current[tc.get('classname'),tc.get('name')]={'class':tc.get('classname'),'name':tc.get('name'),'phase':'call' if fault.tag=='failure' else 'setup','category':category,'message':fault.get('message'),'trace':body,'later_assertions':'unexecuted'}
 comparison=[]
 for key,old in basekeys.items():
  new=current.get(key)
  comparison.append({'class':key[0],'name':key[1],'baseline_phase':old['phase'],'current_phase':new['phase'] if new else 'success','category':new['category'] if new else 'resolved','same_phase':bool(new and new['phase']==old['phase'])})
 summary[version]={'baseline_non_successes':len(base),'current_non_successes':len(current),'i3_resolved_baseline_non_successes':sum(k not in current for k in basekeys),'additional_non_successes':sum(k not in basekeys for k in current),'same_non_success_nodes_and_phases':set(basekeys)==set(current) and all(r['same_phase'] for r in comparison),'counts':dict(collections.Counter(r['category']+':'+r['phase'] for r in current.values())),'comparison':comparison}
 (path/'failure-details.json').write_text(json.dumps(list(current.values()),indent=2)+'\n')
(root/'failure-classification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:{n:v for n,v in r.items() if n!='comparison'} for k,r in summary.items()},indent=2))
