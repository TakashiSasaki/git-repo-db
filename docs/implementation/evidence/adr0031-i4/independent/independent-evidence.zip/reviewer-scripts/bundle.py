import hashlib,json,zipfile
from pathlib import Path
BASE=Path('/workspace/i4-independent');OUT=BASE/'evidence'
payload={}
def add(path,name):
 assert path.is_file();assert name not in payload;payload[name]=path
add(BASE/'REPORT.md','REPORT.md')
for p in sorted(BASE.glob('*.py')):add(p,'reviewer-scripts/'+p.name)
for name in ('inventory.log','setup.log','wheelhouse.log'):
 add(BASE/name,'setup/'+name)
for tag in ('3513','3531'):
 for p in (BASE/'runtime'/(tag+'.zip'),BASE/'runtime'/(tag+'-build.log'),BASE/'runtime'/tag/'libsqlite3.so.0'):
  add(p,str(p.relative_to(BASE)))
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT)
 if rel.parts[0]=='distributions' and len(rel.parts)>1 and rel.parts[1] in ('source.tar','source','from-sdist','direct-venv','sdist-venv'):continue
 add(p,'evidence/'+str(rel))
index={'review_product_head':'a9d4c3585806622b66d3c41132c2a9f8ab5c6f9e','review_product_tree':'3dd1e39e06d347883a6fb493e7b9b06fb6dbfb62','payload_entries':len(payload),'excluded_bulky_outputs':['evidence/distributions/source.tar','evidence/distributions/source/','evidence/distributions/from-sdist/','evidence/distributions/direct-venv/','evidence/distributions/sdist-venv/'],'payload':{name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in payload.items()}}
(BASE/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=BASE/'i4-independent-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in payload.items():z.write(p,name)
 z.write(BASE/'artifact-index.json','artifact-index.json')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(payload)+1
 for name,v in index['payload'].items():
  raw=z.read(name);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],name
summary={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'indexed_payload_entries':len(payload),'archive_entries_including_index':len(payload)+1,'report_sha256':hashlib.sha256((BASE/'REPORT.md').read_bytes()).hexdigest(),'all_payload_hashes_reverified':True}
(BASE/'ARTIFACTS.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
