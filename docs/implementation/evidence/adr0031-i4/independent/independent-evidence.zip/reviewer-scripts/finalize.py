"""Reconcile actual review outputs and prepare a portable evidence bundle."""
import collections,hashlib,json,shutil,subprocess,tarfile,zipfile
from pathlib import Path
BASE=Path('/workspace/i4-independent');ROOT=BASE/'repo';OUT=BASE/'evidence'
read=lambda p:json.loads(p.read_text())
result={'verdict':'LIMITED I4 INDEPENDENT REVIEW PASS','whole_adr_acceptance':False,'product_findings':0,'unresolved_review_findings':{'Critical':0,'High':0,'Medium':0,'Low':1},'low_finding':'I4-E1: whole-sdist inputs differ; runtime/wheel inputs equal','execution_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'execution_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'runtimes':{},'installed':{}}
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
for v in ('3.51.3','3.53.1'):
 d=OUT/('run-'+v);summary=read(d/'summary.json')
 assert summary['inputs_unchanged']
 assert summary['run']['passed']==3029 and summary['run']['failed']==59 and summary['run']['error']==20 and summary['run']['exit_code']==1
 assert summary['transfer_sql_overlapping_broad']['passed']==217 and summary['transfer_sql_overlapping_broad']['exit_code']==0
 assert summary['ordinary_collected']==5649 and summary['unexecuted_ordinary']==2541
 probe=read(OUT/('independent-v2-'+v)/'summary.json');assert probe['cases']==probe['passed']==153
 diag=read(OUT/('sql301-'+v)/'summary.json');assert diag['total']==diag['passed']==301
 rest=read(OUT/('restoration-'+v+'.json'));assert len(rest['unique_nodes'])==8 and rest['exitstatus']==0
 observations=read(OUT/('sql301-'+v)/'restoration-observations.json');assert len(observations)==105
 binding=read(d/'input-binding.json');assert binding['head']==result['execution_head'] and binding['tree']==result['execution_tree'] and binding['tracked_status']==''
 result['runtimes'][v]={'broad':{'executed':3108,'passed':3029,'call_failed':59,'setup_error':20,'exit_code':1},'i4':217,'i3_overlapping':65,'independent':probe,'sql_diagnostic':{'groups':301,'pass':301},'restored_poison_nodes':8,'diagnostic_inject_returns':105,'unexecuted_ordinary':2541,'context_fingerprint':binding['runtime']['context_fingerprint']}
dist=OUT/'distributions';processes=read(dist/'processes.json')
nonzero={r['name']:r['exit_code'] for r in processes if r['exit_code']}
assert nonzero=={a+'-'+v+'-access':1 for a in ('direct','sdist') for v in ('3.51.3','3.53.1')}
build=read(dist/'build-binding.json');assert build['head']==result['execution_head'] and build['tree']==result['execution_tree']
assert build['direct_wheel']==build['sdist_wheel']=={'sha256':'18038fd72b752767557e03ccc3c06cc94a61ec7a2f0f4fa49a3ef4893517c0f5','bytes':758668}
for artifact in ('direct','sdist'):
 for v in ('3.51.3','3.53.1'):
  label=artifact+'-'+v;runtime=read(dist/(label+'-runtime.json'));probe=read(OUT/(label+'-independent')/'summary.json')
  assert runtime['sqlite'][0]==v and probe['cases']==probe['passed']==153
  assert ('/'+artifact+'-venv/') in runtime['origin'] and '/repo/src/' not in runtime['origin']
  files=runtime['installed_files']
  assert len(files)==153
  for rel,h in files.items():assert hashlib.sha256((ROOT/'src/repo_catalog'/rel).read_bytes()).hexdigest()==h,rel
  xml=__import__('xml.etree.ElementTree',fromlist=['parse']).parse(dist/(label+'-i4.xml'))
  cases=xml.findall('.//testcase');assert len(cases)==217 and not xml.findall('.//failure') and not xml.findall('.//error') and not xml.findall('.//skipped')
  result['installed'][label]={'i4_passed':217,'independent_passed':153,'source_equal_installed_files':153,'i2_probe_exit':0,'i3_probe_exit':0,'original_access_smoke_exit':1,'origin':runtime['origin']}
review_processes=read(OUT/'review-processes.json')
assert {r['label']:r['exit_code'] for r in review_processes if r['exit_code']}=={'run-3.53.1-driver':1,'distributions-driver':1}
compare=read(OUT/'independent-failure-comparison.json')
assert all(r['additional']==r['resolved']==0 and len(r['line_offsets'])==18 and r['raw_messages_equal']==75 for r in compare.values())
result['build']=build;result['inherited_failures']={'retained':79,'additional':0,'resolved':0,'Transfer_call':45,'Transfer_setup':20,'I6_Wire_call':14,'line_offset_occurrences':18,'raw_messages_identical':75,'raw_temp_path_rendering_differences':4}
(OUT/'review-summary.json').write_text(json.dumps(result,indent=2)+'\n')
artifacts=OUT/'artifacts';artifacts.mkdir(exist_ok=True)
shutil.copyfile(next((dist/'source/dist').glob('*.whl')),artifacts/'direct.whl')
shutil.copyfile(next((dist/'from-sdist').glob('*/dist/*.whl')),artifacts/'sdist-derived.whl')
print(json.dumps(result,indent=2))
