"""Independent phase/node and first-refusal comparison, no author comparator import."""
import collections,json,re,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
ROOT=Path('/workspace/i4-independent/repo');OUT=ROOT.parent/'evidence'
def parsed(raw):
 cases={};bad={}
 for c in ET.fromstring(raw).findall('.//testcase'):
  key=(c.attrib['classname'],c.attrib['name']);assert key not in cases
  fault=next((c.find(t) for t in ('failure','error','skipped') if c.find(t) is not None),None)
  cases[key]='pass' if fault is None else fault.tag
  if fault is not None and fault.tag!='skipped':
   text=fault.text or '';message=fault.get('message','')
   code=re.search(r'I2_(TRANSFER|IDENTIFICATION_WIRE)_UNSUPPORTED',message+'\n'+text)
   frames=[{'path':p,'line':int(n),'function':f} for p,n,f in re.findall(r'^(tests/[^\n:]+\.py|src/[^\n:]+\.py):(\d+):(?: in (\w+))?',text,re.M)]
   refusal=re.search(r'I2_(?:TRANSFER|IDENTIFICATION_WIRE)_UNSUPPORTED(?:: [^\n\\]*)?',message+'\n'+text)
   bad[key]={'phase':'call' if fault.tag=='failure' else 'setup','code':code.group() if code else None,'refusal':refusal.group() if refusal else None,'message':message,'frames':frames,'junit_test_file':c.get('file'),'junit_test_line':c.get('line')}
 return cases,bad
def journal(path,keys):
 events=[json.loads(l) for l in path.read_text().splitlines()]
 starts=collections.Counter(x['nodeid'] for x in events if x['event']=='start')
 phases=collections.Counter((x['nodeid'],x['phase']) for x in events if x['event']=='phase')
 setup={x['nodeid']:x['outcome'] for x in events if x['event']=='phase' and x['phase']=='setup'}
 assert len(starts)==len(keys) and all(v==1 for v in starts.values())
 assert all(phases[n,'setup']==phases[n,'teardown']==1 and phases[n,'call']==int(setup[n]=='passed') for n in starts)
 assert all(v==1 for v in phases.values())
 finishes=[e for e in events if e['event']=='finish']
 assert len(finishes)==1 and finishes[0]['status']=='failed' and finishes[0]['exitstatus']==1
 return {'starts':len(starts),'phase_counts':dict(collections.Counter(x['phase']+':'+x['outcome'] for x in events if x['event']=='phase')),'all_nodes_started_once':True,'all_required_phases_once':True,'finished':True,'finish':finishes[0]}
results={}
with zipfile.ZipFile(ROOT/'docs/implementation/evidence/adr0031-i3/author-evidence.zip') as z:
 for v in ('3.51.3','3.53.1'):
  base,old=parsed(z.read('final-'+v+'/regressions.xml'))
  current,new=parsed((OUT/('run-'+v)/'regressions.xml').read_bytes())
  assert len(base)==2891 and len(old)==79 and len(current)==3108
  assert set(base)<=set(current) and len(set(current)-set(base))==217
  assert all(k[0]=='tests.integration.p3.test_transfer_sql' for k in set(current)-set(base))
  comparison=[]; offsets=[]
  assert set(old)==set(new)
  for key,o in sorted(old.items()):
   n=new[key]
   same_phase=o['phase']==n['phase'];same_code=o['code']==n['code']
   frames_equal=[(f['path'],f['function']) for f in o['frames']]==[(f['path'],f['function']) for f in n['frames']]
   line_offsets=[{'path':a['path'],'function':a['function'],'baseline_line':a['line'],'current_line':b['line'],'offset':b['line']-a['line']} for a,b in zip(o['frames'],n['frames']) if a['line']!=b['line']]
   offsets+=line_offsets
   assert same_phase and same_code and frames_equal and o['refusal']==n['refusal']
   assert o['junit_test_file']==n['junit_test_file'] and o['junit_test_line']==n['junit_test_line']
   comparison.append({'class':key[0],'name':key[1],'baseline':o,'independent':n,'same_phase':same_phase,'same_stage_code':same_code,'same_source_paths_functions':frames_equal,'same_raw_message':o['message']==n['message'],'line_offsets':line_offsets})
  by=collections.Counter(n['phase']+':'+str(n['code']) for n in new.values())
  assert by=={'call:I2_TRANSFER_UNSUPPORTED':45,'setup:I2_TRANSFER_UNSUPPORTED':20,'call:I2_IDENTIFICATION_WIRE_UNSUPPORTED':14}
  assert collections.Counter(current.values())=={'pass':3029,'failure':59,'error':20}
  # Confirm I3 65, focused I4 217, and all eight restoration nodes actually passed.
  cohorts={prefix:sum(k[0]==prefix and state=='pass' for k,state in current.items()) for prefix in ('tests.integration.p3.test_parent_reports','tests.integration.p3.test_transfer_sql')}
  assert list(cohorts.values())==[65,217]
  poison=[state for k,state in current.items() if 'test_matching_schema_poison_stops_before_ordinary_exposure' in k[1]]
  assert poison==['pass']*8
  results[v]={'baseline_nodes':len(base),'independent_nodes':len(current),'outcomes':dict(collections.Counter(current.values())),'baseline_faults':len(old),'independent_faults':len(new),'additional':0,'resolved':0,'phase_and_owner_counts':dict(by),'cohorts':cohorts,'raw_messages_equal':sum(c['same_raw_message'] for c in comparison),'line_offsets':offsets,'comparison':comparison,'journal':journal(OUT/('run-'+v)/'regressions.jsonl',current)}
  assert all(x['path']=='src/repo_catalog/adapters/sqlite/p1_context.py' and x['offset']==4 for x in offsets)
(OUT/'independent-failure-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({v:{k:r[k] for k in ('baseline_nodes','independent_nodes','outcomes','additional','resolved','phase_and_owner_counts','raw_messages_equal')} for v,r in results.items()},indent=2))
