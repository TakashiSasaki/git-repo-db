import ast, collections, hashlib, json, subprocess, urllib.request, zipfile
from pathlib import Path

ROOT=Path('/workspace/i4-independent/repo')
OUT=ROOT.parent/'evidence'; OUT.mkdir(exist_ok=True)
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def write(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n')
refs={'base':'614ccaac3512a0df4291653fc83901df211f00f6','author':'f4d8c3d123552e765ef3f0ddaf4e83deaaa0e9c6','correction':'27fa4482caad9d146250e0a6701a5fcffc3da390','public':'a9d4c3585806622b66d3c41132c2a9f8ab5c6f9e'}
remote={}
for name,sha in refs.items():
 url=f'https://api.github.com/repos/TakashiSasaki/git-repo-db/git/commits/{sha}'
 with urllib.request.urlopen(url) as r: data=json.load(r)
 remote[name]={'url':url,'sha':data['sha'],'tree':data['tree']['sha'],'local_tree':git('rev-parse',sha+'^{tree}')}
 assert remote[name]['tree']==remote[name]['local_tree']
for num in (126,127):
 with urllib.request.urlopen(f'https://api.github.com/repos/TakashiSasaki/git-repo-db/pulls/{num}') as r:d=json.load(r)
 remote[str(num)]={k:d[k] for k in ('state','draft','merged','updated_at')}
 remote[str(num)].update(head=d['head']['sha'],base=d['base']['sha'])
write('github-refs.json',remote)
def tree(sha):
 return {line.split('\t',1)[1]:line.split('\t',1)[0].split()[2] for line in git('ls-tree','-r',sha).splitlines()}
a,b=tree(refs['author']),tree(refs['public'])
scope=lambda p:p.startswith(('src/','tests/','.github/')) or p in ('pyproject.toml','uv.lock','.python-version')
product={p:{'author_blob':a.get(p),'public_blob':b.get(p)} for p in sorted(set(a)|set(b)) if scope(p)}
assert all(v['author_blob']==v['public_blob'] for v in product.values())
write('blob-comparison.json',{'refs':refs,'compared_inputs':product,'all_identical':True,'all_tree_differences':{p:{'author':a.get(p),'public':b.get(p)} for p in sorted(set(a)|set(b)) if a.get(p)!=b.get(p)}})
p=ROOT/'docs/implementation/evidence/adr0031-i4'; index=json.loads((p/'artifact-index.json').read_text()); raw=(p/'author-evidence.zip').read_bytes()
assert len(raw)==5431376 and hashlib.sha256(raw).hexdigest()=='e452d2b86f99fff8f44993204d7e72df925b69b34086a6399d791aeb39c75948'
with zipfile.ZipFile(p/'author-evidence.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==840
 assert set(z.namelist())==set(index['payload'])
 for name,v in index['payload'].items():
  payload=z.read(name)
  assert len(payload)==v['bytes'] and hashlib.sha256(payload).hexdigest()==v['sha256'],name
 receipts={n:json.loads(z.read(n)) for n in z.namelist() if n.endswith('.execution.json') or n in ('distributions/processes.json','runtime-builds.json','remaining-processes.json')}
 bindings={n:json.loads(z.read(n)) for n in ('author-3.51.3/input-binding.json','author-3.53.1/input-binding.json','distributions/build-binding.json')}
 for n,v in bindings.items():
  assert v['head']==refs['author'] and v['tree']==remote['author']['tree']
 write('author-receipts-audit.json',{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'entries_verified':840,'bindings':bindings,'receipts':receipts})
 # Extract archived receipts for transparent comparison, never execute archived scripts.
 for n in z.namelist():
  if n.endswith(('regressions.xml','regressions.selected.txt','regressions.jsonl','targets.json')) and n.startswith('author-'):
   target=OUT/'author-archive'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n))
 # Runtime build source provenance is inspected separately.
 write('author-runtime-builds.json',json.loads(z.read('runtime-builds.json')))

# Original corruption inputs and every downstream AST assertion/route remain.
path='tests/integration/p1/test_generalized_resources.py'
def node_at(sha,path,name):
 return next(n for n in ast.parse(git('show',sha+':'+path)).body if isinstance(n,ast.FunctionDef) and n.name==name)
name='test_matching_schema_poison_stops_before_ordinary_exposure'
old,new=(node_at(s,path,name) for s in (refs['base'],refs['public']))
def downstream(n):
 pos=next(i for i,x in enumerate(n.body) if isinstance(x,ast.Assign) and any(isinstance(y,ast.Name) and y.id=='before' for y in x.targets))
 return [ast.dump(x,include_attributes=False) for x in n.body[pos:]]
assert downstream(old)==downstream(new)
oldif=next(n for n in old.body if isinstance(n,ast.If));newif=next(n for n in new.body if isinstance(n,ast.If))
assert ast.dump(oldif,include_attributes=False)==ast.dump(newif,include_attributes=False)
assert ast.dump(old.decorator_list[0])==ast.dump(new.decorator_list[0]) and ast.dump(old.decorator_list[1])==ast.dump(new.decorator_list[1])
diag='scripts/verify_i2_sql_counterexamples.py'
ot,nt=[ast.parse(git('show',s+':'+diag)) for s in (refs['base'],refs['public'])]
def excluding_inject(t):return [ast.dump(n,include_attributes=False) for n in t.body if not (isinstance(n,ast.FunctionDef) and n.name=='inject')]
assert excluding_inject(ot)==excluding_inject(nt)
write('fixture-static-audit.json',{'eight_nodes_decorators_unchanged':True,'original_poison_insert_ast_identical':True,'all_downstream_assertions_and_routes_ast_identical':True,'diagnostic_all_nodes_except_inject_ast_identical':True,'base':refs['base'],'public':refs['public']})
print('GitHub refs, blobs, 840 ZIP payloads, original poison and downstream assertions verified')
