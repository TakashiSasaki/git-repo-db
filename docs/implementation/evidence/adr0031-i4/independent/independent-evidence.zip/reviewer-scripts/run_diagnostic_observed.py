"""Execute unchanged 301-group script, observing each inject return."""
import json, runpy, sys
from pathlib import Path
from repo_catalog.adapters.sqlite import p1_schema
records=[]
def profile(frame,event,arg):
 if event=='return' and frame.f_code.co_name=='inject' and frame.f_code.co_filename.endswith('/scripts/verify_i2_sql_counterexamples.py'):
  db=frame.f_locals['db'];p1_schema.verify_connection(db)
  assert p1_schema.schema_rows(db)==p1_schema.expected_schema('context')
  records.append({'representation':frame.f_locals['representation'],'exact_schema':True,'pragmas':{n:db.execute('PRAGMA '+n).fetchone()[0] for n in p1_schema.REQUIRED_PRAGMAS},'udfs':[tuple(r) for r in db.execute('PRAGMA function_list') if r[0].startswith('p1_transfer_')]})
sys.setprofile(profile)
try:runpy.run_path(str(Path(sys.argv[1])/'scripts/verify_i2_sql_counterexamples.py'),run_name='__main__')
finally:
 sys.setprofile(None)
 (Path(sys.argv[3])/'restoration-observations.json').write_text(json.dumps(records,indent=2)+'\n')
