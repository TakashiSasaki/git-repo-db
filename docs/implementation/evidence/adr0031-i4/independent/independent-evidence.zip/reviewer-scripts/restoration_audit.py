"""Read-only observers at the original corruption-test restoration boundary."""
import json, os
from pathlib import Path
import pytest
from repo_catalog.adapters.sqlite import p1_schema

active=None; observations=[]; original=p1_schema.validate
def validate(db,store,*args,**kwargs):
 result=original(db,store,*args,**kwargs)
 if active and store=='context':
  poisoned=sum(db.execute("SELECT count(*) FROM "+t+" WHERE relation_kind LIKE 'transfer_%'").fetchone()[0] for t in ('resource_relations','resource_repository_relations'))
  if poisoned:
   p1_schema.verify_connection(db)
   assert p1_schema.schema_rows(db)==p1_schema.expected_schema('context')
   observations.append({'node':active,'poison_rows':poisoned,'exact_schema':True,'pragmas':{n:db.execute('PRAGMA '+n).fetchone()[0] for n in p1_schema.REQUIRED_PRAGMAS},'udfs':[tuple(r) for r in db.execute('PRAGMA function_list') if r[0].startswith('p1_transfer_')]})
 return result
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
 global active
 if 'test_matching_schema_poison_stops_before_ordinary_exposure' not in item.nodeid:
  yield;return
 active=item.nodeid;p1_schema.validate=validate
 try:yield
 finally:active=None;p1_schema.validate=original
def pytest_sessionfinish(session,exitstatus):
 target=Path(os.environ['RESTORATION_AUDIT'])
 target.write_text(json.dumps({'exitstatus':int(exitstatus),'observations':observations,'unique_nodes':sorted({r['node'] for r in observations})},indent=2)+'\n')
 assert len({r['node'] for r in observations})==8
