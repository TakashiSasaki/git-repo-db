"""Independent orchestration; product/test inputs are never changed."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/i4-independent/repo');BASE=ROOT.parent;OUT=BASE/'evidence';PY=ROOT/'.venv/bin/python'
records=[]
def run(label,argv,env,cwd=ROOT):
 start=time.time()
 with (OUT/(label+'.log')).open('w') as f:p=subprocess.run([str(v) for v in argv],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec={'label':label,'argv':[str(v) for v in argv],'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'sqlite_library':env['LD_LIBRARY_PATH']}
 records.append(rec);(OUT/'review-processes.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 return p.returncode
for version,tag in (('3.51.3','3513'),('3.53.1','3531')):
 env=dict(os.environ,LD_LIBRARY_PATH=str(BASE/'runtime'/tag),PATH=str(PY.parent)+os.pathsep+os.environ['PATH'])
 if version=='3.53.1':
  run('run-'+version+'-driver',[PY,'scripts/verify_i4.py','--sqlite',version,'--workers','4','--output',OUT/('run-'+version)],env)
  run('independent-v2-'+version,[PY,BASE/'independent_sql.py','--output',OUT/('independent-v2-'+version)],env)
 run('sql301-'+version,[PY,BASE/'run_diagnostic_observed.py',ROOT,version,OUT/('sql301-'+version)],env)
 for script in ('build_p1_schema.py','audit_p1_schema.py','audit_callsite_dependencies.py','audit_context_registration.py','audit_implementation_boundary.py'):
  run(version+'-'+script,[PY,ROOT/'scripts'/script,'--check'],env)
 penv=dict(env,PYTHONPATH=str(BASE),RESTORATION_AUDIT=str(OUT/('restoration-'+version+'.json')))
 run('eight-poison-'+version,[PY,'-m','pytest','-q','tests/integration/p1/test_generalized_resources.py','-k','test_matching_schema_poison_stops_before_ordinary_exposure','-p','restoration_audit','--junitxml='+str(OUT/('eight-poison-'+version+'.xml'))],penv)
env=dict(os.environ,LD_LIBRARY_PATH=str(BASE/'runtime/3513'),PATH=str(PY.parent)+os.pathsep+os.environ['PATH'])
run('distributions-driver',[PY,'scripts/verify_i4_distribution.py','--output',OUT/'distributions','--minimum-library',BASE/'runtime/3513','--newer-library',BASE/'runtime/3531'],env)
# Same independent probes run from an outside-checkout CWD through installed imports.
dist=OUT/'distributions';outside=dist/'outside'
for artifact in ('direct','sdist'):
 for version,tag in (('3.51.3','3513'),('3.53.1','3531')):
  env=dict(os.environ,LD_LIBRARY_PATH=str(BASE/'runtime'/tag),PYTHONPATH='',PATH=str(dist/(artifact+'-venv/bin'))+os.pathsep+os.environ['PATH'])
  run(artifact+'-'+version+'-independent',[dist/(artifact+'-venv/bin/python'),BASE/'independent_sql.py','--output',OUT/(artifact+'-'+version+'-independent')],env,outside)
