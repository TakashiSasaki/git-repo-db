"""Non-author SQL probes. Imports product APIs only, no author test helpers.

Run against frozen checkout or an installed wheel. Every disposable positive DB
is compared with product DDL before removing exactly the two stage fences.
"""
import argparse, hashlib, json, sqlite3, sys, tempfile
from pathlib import Path
from repo_catalog.adapters.sqlite import p1_schema as schema
from repo_catalog.domain.resource_identity import parse_identity
from repo_catalog.domain.time import validate_observation_us

J=lambda v:json.dumps(v,ensure_ascii=True,sort_keys=True,separators=(',',':'),allow_nan=False)
S='abcde123-4567-489a-8bcd-0123456789ab'
S2='abcde123-4567-489a-8bcd-0123456789ac'
R='12345678-1234-4123-8123-123456789abc'
C='12345678-1234-4123-8123-123456789abd'
FENCES={'i2_transfer_stage_fence','i2_transfer_report_stage_fence'}
RC='service_instance_uuidv4,resource_kind,provider_resource_id,relation_kind,members_json,provenance_json,scope_json,observed_at_us'
EC='service_instance_uuidv4,resource_kind,provider_resource_id,relation_kind,target_json,clock_json,provenance_json,observed_at_us,event_report_members_json,event_report_scope_json'
REL=f'INSERT INTO resource_relations({RC}) VALUES(?,?,?,?,?,?,?,?)'
EP=f'INSERT INTO resource_repository_relations({EC}) VALUES(?,?,?,?,?,?,?,?,?,?)'
RES='INSERT INTO resources(service_instance_uuidv4,resource_kind,provider_resource_id,identifier_namespace_kind,identifier_namespace_id,document_kind,provider_document_id) VALUES(?,?,?,?,?,?,?)'
records=[]; traces=[]; dbs=[]

def snap(db):
 return {n:[list(r) for r in db.execute('SELECT * FROM "'+n+'"')] for n, in db.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")}
def expect(name,db,sql,args=(),accept=False,unchanged=True):
 before=snap(db);error=None
 try: db.execute(sql,args)
 except (sqlite3.Error,OverflowError,ValueError,TypeError) as e:error={'class':type(e).__name__,'message':str(e),'code':getattr(e,'sqlite_errorcode',None),'name':getattr(e,'sqlite_errorname',None)}
 after=snap(db)
 okay=(error is None)==accept and (accept or not unchanged or before==after)
 record={'case':name,'sql':sql,'args':args,'expected':'accept' if accept else 'reject without row mutation','actual':'accept' if error is None else 'reject','error':error,'rowset_unchanged':before==after,'pass':okay}
 records.append(record)
 if not okay:raise AssertionError(record)
 return after
def dbnew(fenced=False,factory=False):
 if factory:
  temp=tempfile.TemporaryDirectory();dbs.append(temp)
  path=Path(temp.name)/'context.sqlite3';schema.initialize(path,'context',R,C);db=schema.connect(path,'context')
 else:
  db=sqlite3.connect(':memory:',isolation_level=None);schema.register_functions(db);schema.configure(db);db.executescript(schema.compose('context'))
 assert schema.schema_rows(db)==schema.expected_schema('context')
 original=schema.schema_rows(db)
 if not fenced:
  for n in sorted(FENCES):db.execute('DROP TRIGGER '+n)
  assert schema.schema_rows(db)==tuple(r for r in original if r[1] not in FENCES)
 schema.verify_connection(db)
 for ss in (S,S2):db.execute('INSERT INTO providers VALUES(?,?,?)',(ss,'synthetic-review','{}'))
 db.set_trace_callback(traces.append); dbs.append(db)
 return db
def data(db,issue=True,parent=True,service=S,event='evt/x',native='native/7',subtype='timeline_event'):
 iid=J(native); eid=J(['issue',iid,subtype,event]); coords=(service,'comment',eid)
 db.execute(RES,(*coords,'issue',iid,subtype,J(event)))
 if issue:db.execute(RES,(service,'issue',iid,None,None,None,None))
 pr=(*coords,'parent',J([[service,'issue',iid]]),J({'source':'review/parent','evidence':['a',7]}),J({'clock':{'domain':'parent-axis','at_us':101},'document_kind':subtype,'state':'complete'}),109)
 if parent:db.execute(REL,pr)
 scope={'clock':{'domain':'event-axis','at_us':211},'event_type':'transferred','from_provider_repository_id':None,'to_provider_repository_id':None,'provided_roles':['transfer_from_repository','transfer_to_repository'],'endpoints':[['transfer_from_repository','null'],['transfer_to_repository','null']],'parent_members_json':pr[4],'parent_provenance_json':pr[5],'parent_scope_json':pr[6]}
 er=(*coords,'transfer_event_report','[]',J({'source':'review/event','evidence':['b',9]}),J(scope),223)
 return coords,pr,er
def change_scope(row,**changes):
 s=json.loads(row[6]);s.update(changes);return (*row[:6],J(s),row[7])
def endpoint(er,role='transfer_from_repository'):
 return (*er[:3],role,'null',J(json.loads(er[6])['clock']),er[5],er[7],er[4],er[6])
def replace(row,index,value):return (*row[:index],value,*row[index+1:])
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False)
 try:
  run()
 finally:
  (args.output/'cases.json').write_text(json.dumps(records,ensure_ascii=True,sort_keys=True,default=repr)+'\n');(args.output/'sql-trace.json').write_text(J(traces)+'\n')
  (args.output/'summary.json').write_text(J({'cases':len(records),'passed':sum(r['pass'] for r in records),'sqlite':sqlite3.sqlite_version,'source_id':sqlite3.connect(':memory:').execute('select sqlite_source_id()').fetchone()[0],'independent':True})+'\n')
 print(f'{len(records)} independently designed SQL/API cases passed on {sqlite3.sqlite_version}')
def run():
 # Record actual engine/configuration/functions/DDL and inspect FK/index order.
 db=dbnew();_,pr,er=data(db)
 metadata={'python':sys.version,'origin':str(__import__('repo_catalog').__file__),'sqlite':db.execute('SELECT sqlite_version(),sqlite_source_id()').fetchone(),'compile_options':db.execute('PRAGMA compile_options').fetchall(),'pragmas':{n:db.execute('PRAGMA '+n).fetchone()[0] for n in schema.REQUIRED_PRAGMAS},'functions':[r for r in db.execute('PRAGMA function_list') if r[0].startswith('p1_')],'composed_fingerprint':schema.fingerprint('context'),'schema':schema.expected_schema('context'),'foreign_keys':{n:db.execute('PRAGMA foreign_key_list('+n+')').fetchall() for n in ('resources','resource_relations','resource_repository_relations')},'indexes':{n:db.execute('PRAGMA index_xinfo('+n+')').fetchall() for n in ('resources_native_event_fk','parent_report_typed_fk','event_report_identity_fk')},'column_types':{n:db.execute('PRAGMA table_xinfo('+n+')').fetchall() for n in ('resources','resource_relations','resource_repository_relations')}}
 assert all(r[4]=='BINARY' for r in metadata['indexes']['resources_native_event_fk'] if r[5])
 assert [r[2] for r in metadata['indexes']['resources_native_event_fk'] if r[5]]==['service_instance_uuidv4','resource_kind','provider_resource_id','reference_document_kind','identifier_namespace_kind','identifier_namespace_id']
 (ARGS_OUTPUT/'runtime.json').write_text(J(metadata)+'\n')
 expect('eligible event with original independent clocks',db,REL,er,True)
 expect('first endpoint',db,EP,endpoint(er),True);expect('second endpoint',db,EP,endpoint(er,'transfer_to_repository'),True)
 assert not db.execute('PRAGMA foreign_key_check').fetchall() and db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 # Missing dependency is not identity failure; arrival does not replay withheld rows.
 for missing in ('resource','report'):
  d=dbnew();coords,p,e=data(d,issue=missing!='resource',parent=False)
  expect('missing '+missing,d,REL,e)
  if missing=='resource':
   expect('Parent report missing referent',d,REL,p)
   d.execute(RES,(S,'issue',J('native/7'),None,None,None,None))
  assert d.execute("SELECT count(*) FROM resource_relations").fetchone()[0]==0
  expect('resupply original Parent after '+missing,d,REL,p,True)
  assert d.execute("SELECT count(*) FROM resource_relations WHERE relation_kind='transfer_event_report'").fetchone()[0]==0
  expect('resupply original Event after '+missing,d,REL,e,True)
 # Retain I8; reject permanently even with I7 report already present.
 d=dbnew();_,p,e=data(d);d.execute(RES,(S,'issue',J('other/8'),None,None,None,None));p8=replace(p,4,J([[S,'issue',J('other/8')]]));expect('lawful competing I8 Parent',d,REL,p8,True)
 e8=change_scope(e,parent_members_json=p8[4]);expect('I8 never supports native I7',d,REL,e8)
 expect('I7 with I8 retained',d,REL,e,True);assert d.execute("SELECT count(*) FROM resource_relations WHERE relation_kind='parent'").fetchone()[0]==2
 # Different full-key components cannot borrow legitimate evidence.
 for field in ('parent_members_json','parent_provenance_json','parent_scope_json'):
  d=dbnew();_,p,e=data(d);v=json.loads(json.loads(e[6])[field])
  if field=='parent_members_json':v[0][2]=J('absent')
  elif field=='parent_provenance_json':v['source']='REVIEW/parent'
  else:v['clock']['domain']='PARENT-axis'
  expect('full Parent key '+field,d,REL,change_scope(e,**{field:J(v)}))
 d=dbnew();_,p,e=data(d);_,_,other=data(d,event='second-event',issue=False,parent=False)
 expect('same native I7 cannot borrow first Event Parent report',d,REL,other)
 d=dbnew();_,p,e=data(d);upper=J('NATIVE/7');d.execute(RES,(S,'issue',upper,None,None,None,None))
 pcase=replace(p,4,J([[S,'issue',upper]]));d.execute(REL,pcase)
 assert d.execute('SELECT ? = ? COLLATE NOCASE',(J('native/7'),upper)).fetchone()[0]==1
 expect('NOCASE lookalike Parent cannot satisfy BINARY native FK',d,REL,change_scope(e,parent_members_json=pcase[4]))
 for mutation in ('event','service','subtype'):
  d=dbnew();_,p,e=data(d);_,_,other=data(d,service=S2 if mutation=='service' else S,event='other' if mutation=='event' else 'evt/x',subtype='reply' if mutation=='subtype' else 'timeline_event',native='native/7' if mutation=='service' else 'different-native')
  expect('cannot borrow report from '+mutation,d,REL,change_scope(other,parent_members_json=p[4],parent_provenance_json=p[5],parent_scope_json=p[6]))
 # Every required nullable support projection and CHECK UNKNOWN variant.
 for field in json.loads(er[6]):
  for mode in ('null','missing'):
   d=dbnew();_,p,e=data(d);s=json.loads(e[6])
   if mode=='null':s[field]=None
   else:del s[field]
   expect('scope '+field+' '+mode,d,REL,replace(e,6,J(s)),accept=mode=='null' and field in ('from_provider_repository_id','to_provider_repository_id'))
 # Canonical and malformed strings, input SQL types, clock/time boundaries.
 for raw in ('{}','null','false','[1]',' ["x"]','"\\u0078"','"\\ud800"','"x"\n','[','{"x":1,"x":2}'):
  d=dbnew();_,p,e=data(d);expect('noncanonical identity '+raw,d,REL,replace(e,2,raw))
 for field,bads in ((4,['null','[null]',b'[]',None]),(5,['null','{}','{"source":"x","source":"y","evidence":1}',None]),(6,['null','{','{"clock":NaN}',None]),(7,[0,-1,1.5,b'1',str(2**63)])):
  for v in bads:
   d=dbnew();_,p,e=data(d);expect('bad column '+str(field)+' '+repr(v),d,REL,replace(e,field,v))
 for value in (None,1,2**63-1):
  d=dbnew();_,p,e=data(d);e=replace(e,7,value);expect('observed inclusive '+str(value),d,REL,e,True);expect('endpoint observed '+str(value),d,EP,endpoint(e),True)
 for v in (True,'1',1.0,0,-1,2**63):
  d=dbnew();_,p,e=data(d);expect('strict JSON clock '+repr(v),d,REL,change_scope(e,clock={'domain':'event-axis','at_us':v}))
 for depth in (31,32,33):
  raw='['*depth+'"x"'+']'*depth
  d=dbnew();expect('identity depth '+str(depth),d,RES,(S,'vendor.probe',raw,None,None,None,None),depth<=32)
 for length in (262144,262145):
  raw='"'+'x'*(length-2)+'"';d=dbnew();expect('identity bytes '+str(length),d,RES,(S,'vendor.probe',raw,None,None,None,None),length==262144)
 for count in (4095,4096):
  raw='['+','.join('""' for _ in range(count))+']';d=dbnew();expect('identity nodes '+str(count+1),d,RES,(S,'vendor.probe',raw,None,None,None,None),count==4095)
 # Scope aggregate ceiling independent of identity ceiling.
 d=dbnew();_,p,e=data(d);expect('aggregate scope over limit',d,REL,change_scope(e,event_type='z'*262145))
 # Endpoint complete direct report key, original clock/provenance/time, null cases.
 for col,val in ((2,J(['issue',J('native/7'),'timeline_event','other'])),(5,J({'domain':'event-axis','at_us':212})),(6,J({'source':'review/EVENT','evidence':['b',9]})),(7,224),(8,None),(9,None),(8,'[null]'),(9,'{}')):
  d=dbnew();_,p,e=data(d);d.execute(REL,e);expect('endpoint key column '+str(col)+' '+repr(val),d,EP,replace(endpoint(e),col,val))
 # Same-event new provenance and independent clock reports coexist.
 d=dbnew();_,p,e=data(d);d.execute(REL,e)
 e2=replace(change_scope(e,clock={'domain':'separate-axis','at_us':None}),7,None);expect('independent clock Event',d,REL,e2,True);expect('independent clock endpoint',d,EP,endpoint(e2),True)
 e3=replace(e,5,J({'source':'another-observer','evidence':3}));expect('independent provenance Event',d,REL,e3,True)
 # Pre-conflict guards, immutable guards, whole-group scope/members/time rebind.
 for label,verb,tail in [('insert','INSERT',''),('ignore','INSERT OR IGNORE',''),('replace','REPLACE',''),('nothing','INSERT',' ON CONFLICT DO NOTHING'),('upsert','INSERT',' ON CONFLICT DO UPDATE SET observed_at_us=excluded.observed_at_us')]:
  for target in ('event-time','event-scope','event-members','endpoint-time','endpoint-scope'):
   d=dbnew();_,p,e=data(d);d.execute(REL,e);ep=endpoint(e);d.execute(EP,ep)
   if target=='event-time':row=replace(e,7,225)
   elif target=='event-scope':row=change_scope(e,event_type='another-original-type')
   elif target=='event-members':row=replace(e,4,J([[S,'repository',J('fake')]]))
   elif target=='endpoint-time':row=replace(ep,7,None)
   else:row=replace(ep,9,change_scope(e,event_type='another-original-type')[6])
   sql=(REL if target.startswith('event-') else EP).replace('INSERT',verb,1)+tail
   expect(label+' '+target,d,sql,row)
 for table in ('resources','resource_relations','resource_repository_relations'):
  d=dbnew();_,p,e=data(d);d.execute(REL,e);d.execute(EP,endpoint(e))
  for sql in ('UPDATE '+table+' SET provider_resource_id=provider_resource_id','DELETE FROM '+table):expect('immutable '+sql,d,sql)
 for q in (REL,EP):
  d=dbnew();_,p,e=data(d);d.execute(REL,e);ep=endpoint(e)
  if q==EP:d.execute(EP,ep)
  row=e if q==REL else ep
  for sql in (q.replace('INSERT','INSERT OR IGNORE',1),q+' ON CONFLICT DO NOTHING'):
   before=snap(d);expect('legitimate replay',d,sql,row,True);assert snap(d)==before
 # Multirow statement atomicity and explicit savepoint/outer rollback.
 for mode in ('multirow','savepoint','transaction'):
  d=dbnew();_,p,e=data(d);before=snap(d);bad=change_scope(e,parent_provenance_json=J({'source':'absent','evidence':1}))
  if mode=='multirow':expect('multirow rollback',d,REL+', (?,?,?,?,?,?,?,?)',(*e,*bad))
  else:
   d.execute('BEGIN');d.execute('SAVEPOINT unit');d.execute(REL,e);d.execute(EP,endpoint(e));expect('second endpoint fails '+mode,d,EP,replace(endpoint(e,'transfer_to_repository'),7,999))
   if mode=='savepoint':d.execute('ROLLBACK TO unit');d.execute('RELEASE unit');d.execute('COMMIT')
   else:d.execute('ROLLBACK')
  assert snap(d)==before
 # Deferral is deliberately unsupported, and unresolved FK fails actual COMMIT.
 d=dbnew();_,p,e=data(d,parent=False);d.execute('BEGIN');d.execute('PRAGMA defer_foreign_keys=ON')
 try:schema.verify_connection(d)
 except schema.SchemaError:pass
 else:raise AssertionError('unsupported deferral not diagnosed')
 d.execute(REL,e)
 try:d.execute('COMMIT')
 except sqlite3.IntegrityError:pass
 else:raise AssertionError('missing Parent survived deferred COMMIT')
 d.execute('ROLLBACK');records.append({'case':'unsupported deferral rejected and COMMIT FK failure rolls back','pass':True,'expected':'verify_connection refusal and COMMIT failure','actual':'both rejected'})
 # Product factories retain both fences for all write conflict forms.
 for factory in (False,True):
  for q in ('INSERT','INSERT OR IGNORE','REPLACE'):
   d=dbnew(fenced=True,factory=factory);_,p,e=data(d)
   expect('normal fence Event '+str(factory)+' '+q,d,REL.replace('INSERT',q,1),e)
   expect('normal fence endpoint '+str(factory)+' '+q,d,EP.replace('INSERT',q,1),endpoint(e))
 # I5 boundaries are explicit positive controls: direct SQL cannot see pre-affinity types,
 # authenticate a Provider, prove actual transferred meaning, or require all endpoints.
 for original in (True,'1',1.0):
  d=dbnew();_,p,e=data(d);expect('I5 original type affinity boundary '+repr(original),d,REL,replace(e,7,original),True)
  try:validate_observation_us(original)
  except (TypeError,ValueError):pass
  else:raise AssertionError('original type validation failed')
 d=dbnew();_,p,e=data(d);expect('I5 event semantics boundary',d,REL,change_scope(e,event_type='not-transferred'),True)
 assert d.execute('SELECT count(*) FROM resource_repository_relations').fetchone()[0]==0
 # Avoid interpreting endpoint omission as SQL completeness enforcement.
 records.append({'case':'I5 whole-unit completeness boundary','pass':True,'expected':'SQL permits report before endpoints','actual':'report stored, zero endpoints'})

if __name__=='__main__':
 # Output selector duplicated solely for runtime metadata path; no source injection.
 ARGS_OUTPUT=Path(sys.argv[sys.argv.index('--output')+1]);main()
