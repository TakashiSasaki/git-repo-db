"""Sequential author final lanes; preserve every actual process exit."""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

repo = Path("/workspace/git-repo-db")
out = Path("/workspace/scratch/i4-evidence")
py = Path("/workspace/scratch/i4-py313/bin/python")
records = []


def run(name, args, version="3.51.3"):
    lib = Path("/workspace/scratch/i4-runtimes") / (
        "sqlite-amalgamation-" + {"3.51.3": "3510300", "3.53.1": "3530100"}[version]
    )
    env = dict(
        os.environ,
        LD_LIBRARY_PATH=str(lib),
        PATH=str(py.parent) + os.pathsep + os.environ["PATH"],
    )
    start = time.time()
    with (out / (name + ".log")).open("w") as f:
        proc = subprocess.run(
            [str(py), *map(str, args)],
            cwd=repo,
            env=env,
            stdout=f,
            stderr=subprocess.STDOUT,
        )
    r = {
        "name": name,
        "argv": [str(py), *map(str, args)],
        "version_requested": version,
        "library": str(lib),
        "exit_code": proc.returncode,
        "elapsed_seconds": time.time() - start,
    }
    records.append(r)
    (out / "remaining-processes.json").write_text(json.dumps(records, indent=2) + "\n")
    print(name, proc.returncode, flush=True)


run(
    "sql-3.51.3",
    ["scripts/verify_i2_sql_counterexamples.py", repo, "3.51.3", out / "sql-3.51.3"],
)
run(
    "supplemental-3.51.3",
    [out / "supplemental_sql.py", repo, out / "supplemental-3.51.3.json"],
)
run(
    "author-3.53.1",
    ["scripts/verify_i4.py", "--sqlite", "3.53.1", "--output", out / "author-3.53.1"],
    "3.53.1",
)
run(
    "sql-3.53.1",
    ["scripts/verify_i2_sql_counterexamples.py", repo, "3.53.1", out / "sql-3.53.1"],
    "3.53.1",
)
run(
    "supplemental-3.53.1",
    [out / "supplemental_sql.py", repo, out / "supplemental-3.53.1.json"],
    "3.53.1",
)
run(
    "first-failure-comparison",
    [
        "scripts/compare_i4_failures.py",
        "--evidence",
        out,
        "--output",
        out / "failure-classification.json",
    ],
)
run(
    "distributions",
    [
        "scripts/verify_i4_distribution.py",
        "--output",
        out / "distributions",
        "--minimum-library",
        "/workspace/scratch/i4-runtimes/sqlite-amalgamation-3510300",
        "--newer-library",
        "/workspace/scratch/i4-runtimes/sqlite-amalgamation-3530100",
    ],
)
for version in ["3.51.3", "3.53.1"]:
    for script in [
        "build_p1_schema.py",
        "audit_p1_schema.py",
        "audit_callsite_dependencies.py",
        "audit_context_registration.py",
        "audit_implementation_boundary.py",
    ]:
        run(
            "audit-" + version + "-" + script, ["scripts/" + script, "--check"], version
        )
sys.exit(int(any(r["exit_code"] for r in records)))
