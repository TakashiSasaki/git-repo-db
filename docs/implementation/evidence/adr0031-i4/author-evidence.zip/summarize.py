"""Verify frozen I4 receipts; counts are per runtime and overlapping cohorts."""

import collections
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

out = Path("/workspace/scratch/i4-evidence")
root = Path("/workspace/git-repo-db")


def read(p):
    return json.loads((out / p).read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def outcomes(cases):
    result = collections.Counter()
    for c in cases:
        kind = (
            "failed"
            if c.find("failure") is not None
            else "error"
            if c.find("error") is not None
            else "skipped"
            if c.find("skipped") is not None
            else "passed"
        )
        result[kind] += 1
    return dict(result)


summary = {
    "author_verification": True,
    "independent_review": "pending_non_author_review_of_frozen_inputs",
    "whole_product_acceptance": False,
    "base_head": "614ccaac3512a0df4291653fc83901df211f00f6",
    "base_tree": "0e35eccffd996c5b7ed175a53adebf2ac76b16cb",
    "i3_reviewed_product_tree": "6f259f7239d7330bea4d1dd1b6e04c316561728f",
    "lanes": {},
    "G_R1": "open_I7_not_retested_or_resolved",
    "fences": "both_product_SQL_fences_and_application_refusals_retained",
    "initial_attempt": "development/superseded-7858615 retains 3108 nodes:3021 pass,67 fail,20 errors; eight old corruption-injector failures corrected without product weakening",
}
for version in ["3.51.3", "3.53.1"]:
    binding = read(f"author-{version}/input-binding.json")
    run = read(f"author-{version}/summary.json")
    assert not binding["tracked_status"]
    assert run["inputs_unchanged"]
    summary["executed_head"] = binding["head"]
    summary["executed_tree"] = binding["tree"]
    expected = read("author-3.51.3/input-binding.json")
    assert binding["inputs"] == expected["inputs"]
    cases = ET.parse(out / f"author-{version}/regressions.xml").findall(".//testcase")
    subs = {
        "I4": outcomes(
            [
                c
                for c in cases
                if c.get("classname") == "tests.integration.p3.test_transfer_sql"
            ]
        ),
        "I3": outcomes(
            [
                c
                for c in cases
                if c.get("classname") == "tests.integration.p3.test_parent_reports"
            ]
        ),
        "I2_dedicated": outcomes(
            [
                c
                for c in cases
                if c.get("classname")
                in [
                    "tests.integration.p1.test_generalized_resources",
                    "tests.unit.test_resource_identification",
                    "tests.packaging.test_p1_distribution",
                ]
            ]
        ),
    }
    assert subs == {
        "I4": {"passed": 217},
        "I3": {"passed": 65},
        "I2_dedicated": {"passed": 86},
    }
    assert (
        run["run"]["passed"] == 3029
        and run["run"]["failed"] == 59
        and run["run"]["error"] == 20
    )
    assert run["run"]["skipped"] == run["run"]["xfail"] == run["run"]["xpass"] == 0
    assert run["run"]["reconciliation"]["consistent_node_execution"]
    diag = read(f"sql-{version}/summary.json")
    assert diag["total"] == diag["passed"] == 301
    failures = read("failure-classification.json")[version]
    assert (
        failures["baseline_non_successes"] == 79
        and failures["current_non_successes"] == 79
        and failures["same_nodes"]
    )
    category = collections.Counter()
    line_deltas = collections.Counter()
    for c in failures["comparison"]:
        assert (
            c["same_stage_refusal"]
            and c["same_phase"]
            and c["same_trace_paths_functions"]
        )
        cur = c["current"]
        category[
            ("wire" if "WIRE" in cur["stage_refusal"] else "Transfer")
            + ":"
            + cur["phase"]
        ] += 1
        for old, new in zip(c["baseline"]["frames"], cur["frames"]):
            if old["line"] != new["line"]:
                line_deltas[(old["path"], new["line"] - old["line"])] += 1
    assert category == {"Transfer:call": 45, "Transfer:setup": 20, "wire:call": 14}
    rt = binding["runtime"]
    assert rt["sqlite_version"] == version
    assert len(read(f"supplemental-{version}.json")["groups"]) == 3
    summary["lanes"][version] = {
        "runtime": {
            k: rt[k]
            for k in [
                "python",
                "executable",
                "sqlite_version",
                "sqlite_source_id",
                "compile_options",
                "pragmas",
                "context_fingerprint",
            ]
        },
        "required_transfer_udfs": [
            r for r in rt["functions"] if r[0].startswith("p1_transfer_")
        ],
        "ordinary_collected_total": 5651,
        "ordinary_selected_after_two_opt_in_deselections": 5649,
        "selected_executed": 3108,
        "ordinary_unexecuted": 2541,
        "broad": {
            k: run["run"][k]
            for k in [
                "passed",
                "failed",
                "error",
                "skipped",
                "xfail",
                "xpass",
                "exit_code",
                "executed",
            ]
        },
        "overlapping_subsets": subs,
        "I4_focused_exit": run["transfer_sql_overlapping_broad"]["exit_code"],
        "sql_diagnostic": diag,
        "supplemental_sql_groups": 3,
        "failure_categories": dict(category),
        "trace_line_deltas": [
            {"path": p, "delta": d, "occurrences": n}
            for (p, d), n in line_deltas.items()
        ],
        "exact_raw_message_equal_count": sum(
            c["same_message"] for c in failures["comparison"]
        ),
    }

build = read("distributions/build-binding.json")
assert build["head"] == summary["executed_head"]
source = out / "distributions/source/src/repo_catalog"
expected = {
    str(p.relative_to(source)): sha(p)
    for p in source.rglob("*")
    if p.is_file()
    and p.suffix in (".py", ".sql", ".json")
    and "__pycache__" not in p.parts
}
installed = []
for tag in ["direct", "sdist"]:
    for version in ["3.51.3", "3.53.1"]:
        name = f"{tag}-{version}"
        rt = read("distributions/" + name + "-runtime.json")
        assert rt["sqlite"][0] == version
        assert rt["installed_files"] == expected
        cases = ET.parse(out / "distributions" / f"{name}-i4.xml").findall(
            ".//testcase"
        )
        assert outcomes(cases) == {"passed": 217}
        installed.append(
            {
                "lane": name,
                "i4": outcomes(cases),
                "source_package_hashes_match": True,
                "origin": rt["origin"],
                "sqlite": rt["sqlite"],
                "fingerprint": rt["fingerprint"],
            }
        )
process = read("distributions/processes.json")
for p in process:
    expected_exit = 1 if p["name"].endswith("-access") else 0
    assert p["exit_code"] == expected_exit, (p, expected_exit)
summary["distributions"] = {
    "build": build,
    "installed": installed,
    "processes": process,
    "orchestrator_exit_code": 1,
    "original_access_smokes": "four failures retained at Transfer preflight; later assertions unexecuted",
}
summary["static_contract"] = read("static-contract.json")
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print("Final runtime, node, SQL, distribution and source bindings verified")
