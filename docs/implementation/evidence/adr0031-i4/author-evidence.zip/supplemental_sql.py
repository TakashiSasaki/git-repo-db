"""Additional author probes against frozen product DDL, not independent review."""

import importlib.util
import json
import sqlite3
import sys
import tempfile
from pathlib import Path

from repo_catalog.adapters.sqlite import p1_schema
from repo_catalog.adapters.sqlite.production_context import Context
from repo_catalog.domain.production_context import ContextError

repo = Path(sys.argv[1])
out = Path(sys.argv[2])
spec = importlib.util.spec_from_file_location(
    "i4_tests", repo / "tests/integration/p3/test_transfer_sql.py"
)
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
results = []


def fresh(path=None):
    if path:
        p1_schema.initialize(path, "context", t.R, t.C)
        db = p1_schema.connect(path, "context")
    else:
        db = sqlite3.connect(":memory:", isolation_level=None)
        p1_schema.register_functions(db)
        p1_schema.configure(db)
        db.executescript(p1_schema.compose("context"))
    assert p1_schema.schema_rows(db) == p1_schema.expected_schema("context")
    fences = [
        tuple(r)
        for r in db.execute(
            "SELECT name,sql FROM sqlite_schema WHERE name IN ('i2_transfer_stage_fence','i2_transfer_report_stage_fence') ORDER BY name"
        )
    ]
    for name, _ in fences:
        db.execute("DROP TRIGGER " + name)
    db.execute("INSERT INTO providers VALUES(?,?,?)", (t.S, "test", "{}"))
    return db, fences


with tempfile.TemporaryDirectory() as work:
    db, fences = fresh()
    event, issue, pr, report = t.setup(db)
    db.execute(t.REL, report)
    db.execute(t.EP, t.endpoint(report))
    altparent = t.parent(
        event,
        issue,
        provenance=t.J({"source": "parent-second", "evidence": 99}),
        clock=None,
        observed=None,
    )
    db.execute(t.REL, altparent)
    second = list(t.event_row(event, altparent))
    second[5] = t.J({"source": "event-second", "evidence": 101})
    db.execute(t.REL, second)
    db.execute(t.EP, t.endpoint(second))
    assert (
        db.execute(
            "SELECT count(*) FROM resource_relations WHERE relation_kind='transfer_event_report'"
        ).fetchone()[0]
        == 2
    )
    results.append(
        {
            "group": "genuine competing Event reports and independent Parent evidence",
            "rows": t.rows(db),
        }
    )
    before = t.rows(db)
    db.execute("BEGIN")
    db.execute("PRAGMA defer_foreign_keys=1")
    try:
        p1_schema.verify_connection(db)
    except p1_schema.SchemaError as e:
        assert "defer_foreign_keys" in str(e)
    else:
        raise AssertionError("deferred unsupported profile accepted")
    third = list(t.event_row(event, altparent))
    third[5] = t.J({"source": "third", "evidence": 102})
    scope = json.loads(third[6])
    scope["parent_provenance_json"] = t.J({"source": "absent", "evidence": 103})
    third[6] = t.J(scope)
    db.execute(t.REL, third)
    try:
        db.execute("COMMIT")
    except sqlite3.IntegrityError as e:
        assert e.sqlite_errorcode == 787
    else:
        raise AssertionError("deferred FK commit succeeded")
    db.execute("ROLLBACK")
    p1_schema.configure(db)
    assert t.rows(db) == before
    results.append(
        {
            "group": "deliberately unsupported deferred FK profile rejects at verification and COMMIT; rollback retains originals"
        }
    )
    db.close()
    directory = Path(work)
    db, fences = fresh(directory / "context.sqlite3")
    _, _, _, report = t.setup(db)
    db.execute(t.REL, report)
    db.execute(t.EP, t.endpoint(report))
    for _, sql in fences:
        db.execute(sql)
    p1_schema.validate(db, "context")
    assert not db.execute("PRAGMA foreign_key_check").fetchall()
    db.close()
    try:
        with Context.snapshot(directory) as context:
            context.identification(t.ResourceKey(*report[:3]))
    except ContextError as e:
        assert e.code == "AUTHORITATIVE_CORRUPTION", e.code
    else:
        raise AssertionError(
            "typed storage became available through normal product route"
        )
    assert (directory / "p1-recovery-stop.json").exists()
    results.append(
        {
            "group": "valid typed Transfer injected in isolated DB and exact fences restored; normal product enters Recovery Stop",
            "stop": json.loads((directory / "p1-recovery-stop.json").read_text()),
        }
    )
out.write_text(
    json.dumps(
        {
            "author": True,
            "full_acceptance": False,
            "sqlite": sqlite3.connect(":memory:")
            .execute("SELECT sqlite_version(),sqlite_source_id()")
            .fetchone(),
            "groups": results,
        },
        indent=2,
    )
    + "\n"
)
print(len(results), "supplemental groups passed")
