"""Deterministic indexed evidence freeze; excludes the enumerated bulky build trees."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path("/workspace/scratch/i4-evidence")
dest = Path("/workspace/git-repo-db/docs/implementation/evidence/adr0031-i4")
files = []
for path in sorted(root.rglob("*")):
    if not path.is_file():
        continue
    relative = path.relative_to(root)
    if "__pycache__" in relative.parts or ".pytest_cache" in relative.parts:
        continue
    if relative.parts[0] == "distributions":
        if len(relative.parts) == 2:
            if path.name == "source.tar":
                continue
        elif relative.parts[1] == "outside" and len(relative.parts) == 3:
            if path.suffix != ".py":
                continue
        else:
            continue
    if path.suffix not in {
        ".py",
        ".json",
        ".jsonl",
        ".log",
        ".xml",
        ".txt",
        ".md",
        ".sql",
        ".diff",
        ".patch",
        ".whl",
    }:
        continue
    files.append(path)
index = {}
archive = dest / "author-evidence.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in files:
        name = str(path.relative_to(root))
        raw = path.read_bytes()
        index[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, raw)
receipt = {
    "author_verification": True,
    "full_acceptance": False,
    "archive": archive.name,
    "bytes": archive.stat().st_size,
    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "executed_head": "f4d8c3d123552e765ef3f0ddaf4e83deaaa0e9c6",
    "executed_tree": "764414d23797179c6988349ca4a236c6b929a44e",
    "helper_head": "27fa4482caad9d146250e0a6701a5fcffc3da390",
    "payload_entries": len(index),
    "excluded_bulky_outputs": [
        "distributions/source.tar",
        "distributions/source/",
        "distributions/from-sdist/",
        "distributions/direct-venv/",
        "distributions/sdist-venv/",
    ],
    "payload": index,
}
(dest / "artifact-index.json").write_text(json.dumps(receipt, indent=2) + "\n")
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(index)
    for name, r in index.items():
        raw = z.read(name)
        assert len(raw) == r["bytes"] and hashlib.sha256(raw).hexdigest() == r["sha256"]
print(json.dumps({k: v for k, v in receipt.items() if k != "payload"}))
