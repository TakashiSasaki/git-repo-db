from pathlib import Path
s=Path('/workspace/git-repo-db/scripts/compare_i4_failures.py').read_text()
s=s.replace('f"author-{version}/regressions.xml"','f"final-{version}/regressions.xml"')
s=s.replace('"message": event.get("message"),','''"message": event.get("message"),
                "stage_refusal": re.findall(r"I2_(?:TRANSFER|IDENTIFICATION_WIRE)_UNSUPPORTED[^\\n]*", trace)[-1].replace("\\\\n", ""),''')
s=s.replace('"same_message": bool(new and new["message"] == old["message"]),','''"same_message": bool(new and new["message"] == old["message"]),
                        "same_stage_refusal": bool(new and new["stage_refusal"] == old["stage_refusal"]),''')
s=s.replace('and c["same_message"]','and c["same_stage_refusal"]')
# Use a precise stage-code + original refusal text, avoiding pytest's command repr.
s=s.replace('re.findall(r"I2_(?:TRANSFER|IDENTIFICATION_WIRE)_UNSUPPORTED[^\\n]*", trace)[-1].replace("\\\\n", "")', 're.search(r"I2_(?:TRANSFER|IDENTIFICATION_WIRE)_UNSUPPORTED: [^\\n\\\\]*", event.get("message") or trace).group()')
p=Path('/workspace/scratch/i4-evidence/compare_final_failures.py')
p.write_text(s.replace('ROOT = Path(__file__).resolve().parents[1]', 'ROOT = Path("/workspace/git-repo-db")'))
Path('/workspace/scratch/i4-evidence/corrected-helper-source.py').write_text(s)
