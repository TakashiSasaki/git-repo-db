# Frozen ADR 0031 I4 author review packet

Author product execution: f4d8c3d123552e765ef3f0ddaf4e83deaaa0e9c6,
tree 764414d23797179c6988349ca4a236c6b929a44e.
Base: 614ccaac3512a0df4291653fc83901df211f00f6,
tree 0e35eccffd996c5b7ed175a53adebf2ac76b16cb.
Final evidence-helper/skill correction: 27fa4482caad9d146250e0a6701a5fcffc3da390,
tree 31b6de0bba1843f63cf2355850e4ebf27e098e74.
The final publication adds only evidence/documentation after that checkpoint;
its exact public HEAD/tree are bound in the new Draft PR author-report body.

Use the repository's final scripts/compare_i4_failures.py for final I3 receipt
comparison. The earlier comparison helper in the executed source incorrectly
selected superseded I3 author receipts. Its failed process is retained; the
corrected helper is separately executed and provided as final-comparison-helper.py.
All product, tests, build and package files are unchanged after execution.

Unzip author-evidence.zip and verify every byte length/SHA-256 against the sibling
artifact-index.json's payload map. Read REPORT.md and summary.json before counting
passes. Full pytest journals/JUnit, every focused SQL trace/final rowset, old and
new DDL, source/runtime hashes, UDF/pragma/source-ID measurements, wheel artifacts,
installed test inputs and process receipts are included. Source Git archive,
sdist, unpacked trees and virtual environments are omitted from this packet,
with their exact build hashes/commands retained; the fixed Git commit recreates
those inputs. runtime-builds.json identifies official runtime sources and builds.

Reproduce tests with actual dynamically linked SQLite 3.51.3 and 3.53.1 using
scripts/verify_i4.py and the unchanged lock. Reproduce all 301 SQL groups using
scripts/verify_i2_sql_counterexamples.py. Reproduce direct/sdist wheels and all
four installed lanes with scripts/verify_i4_distribution.py. The scripts require
fresh output directories. Qualify versions by SELECT sqlite_version(),
sqlite_source_id(); never spoof a version constant. The supplemental_sql.py script
accepts REPOSITORY OUTPUT and executes three additional author groups.

Normal product Transfer remains refused. Isolated constraint fixtures remove
only the two named fences after full schema comparison; corruption fixtures
explicitly disable additional enforcement solely to inject the original poison,
then restore the exact schema/configuration. Neither establishes supported writes.
217 focused I4 and 3108 broad nodes overlap; 65 I3/86 I2 are broad subsets.
Retain 59 failed calls, 20 setup errors and all 14 I6 Wire failures. All original
79 final non-success node/phase/refusal paths remain; assertions after refusal
and 2541 ordinary nodes remain unexecuted. No skip/xfail or whole-product PASS.

A different non-Author agent must independently inspect and execute. No independent
review is claimed. Preserve I5 event semantics, policy, original pre-affinity types,
complete endpoint atomicity and routing obligations. Both product fences remain;
G-R1 is unresolved for I7. No merge/release/deploy/P8/live-catalog authority.
