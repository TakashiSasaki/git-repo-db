"""Measure the final author-runner OS exit independently of tool transport."""
import datetime,json,pathlib,subprocess,time
B=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('/workspace/task-c-f1')
cmd=['/usr/bin/python3.13',str(R/'docs/implementation/evidence/adr0031-i2-f1/run_f1.py'),str(B/'final-run'),'--runtime-root',str(B/'runtime')]
t=time.monotonic();started=datetime.datetime.now(datetime.UTC).isoformat()
with (B/'final-run.log').open('w') as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
(B/'launcher-receipt.json').write_text(json.dumps({'argv':cmd,'cwd':str(R),'started_utc':started,'seconds':time.monotonic()-t,'exit_code':p.returncode},indent=2)+'\n')
raise SystemExit(p.returncode)
