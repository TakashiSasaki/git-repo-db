## Validation plan

Mode: `development`; Effective SHA `fa5d3baad773af3bada10d023c630713fc8a58c3`; full acceptance selected: False.
Acceptance input hash: `5ef8fe9a6ae184cc42b4da68c59cb519bf961f05263fbaf77e9d132a75f94dd4`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 200.
Selected test files: 0.
Unexecuted acceptance files: 200. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.348s.

### Scope reasons
Shared/executable input: src/repo_catalog/domain/resource_identity.py
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
