### fts: 0.03s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `fa5d3baad773af3bada10d023c630713fc8a58c3`, tree `318ad07874ab436206e6a61f231b308a421cfc54`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `fts-1792575726-c9a3cb98`. Dirty tree: `False`.
Command wall time: 0.03s; Cumulative test duration: 0.03s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
