## Validation plan

Mode: `development`; Effective SHA `58b17d1e69828c3c3120c435a39abcde16838ad3`; full acceptance selected: False.
Acceptance input hash: `b141d00bc2ee3393398876e4fc1fd8e37e78f39ea1043121e1fd284507d2fc94`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 203.
Selected test files: 0.
Unexecuted acceptance files: 203. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.342s.

### Scope reasons
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/cohort.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/i1_event_journal.py.txt
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/i1b-i3-newer.log.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/i1b-intake-regression-adapted.log.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/i1b-intake-regression-initial.log.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/input-manifest.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/production_smoke.py.txt.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/receipt-manifest.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/receipts.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/run_validation.py.txt
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/sqlite3513-production-smoke.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/sqlite3513-sql-runtime.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/sqlite3531-production-smoke.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/sqlite3531-sql-runtime.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/author/summary.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/boundary-audit.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/counterexamples.py.txt
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/manifest.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/minimum-author-suite.log.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/minimum-author-suite.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/minimum.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/newer-author-suite.log.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/newer-author-suite.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0031-i1/codec-review/newer.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/i1a-ci-summary.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/i1a-development-ci.zip
Unknown dependency path: docs/implementation/evidence/adr0031-i1/integration-review/frozen-input-sha256.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/integration-review/reproduce.py.txt
Unknown dependency path: docs/implementation/evidence/adr0031-i1/integration-review/sqlite-3.51.3.json
Unknown dependency path: docs/implementation/evidence/adr0031-i1/integration-review/sqlite-3.53.1.json
Shared/executable input: src/repo_catalog/adapters/github/production_intake.py
Shared/executable input: src/repo_catalog/adapters/sqlite/p1_context.py
Shared/executable input: src/repo_catalog/adapters/sqlite/production_context.py
Shared/executable input: src/repo_catalog/application/acquisition.py
Shared/executable input: src/repo_catalog/application/exchange.py
Shared/executable input: src/repo_catalog/cli/production_query.py
Shared/executable input: src/repo_catalog/domain/p1_context.py
Shared/executable input: src/repo_catalog/domain/production_query.py
Shared/executable input: src/repo_catalog/domain/selective_exchange.py
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
