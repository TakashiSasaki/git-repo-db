### report-validation: 0.75s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `58b17d1e69828c3c3120c435a39abcde16838ad3`, tree `ec7ddcd0ddb4715a5fc604d2cac2581f5142d409`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `report-validation-1792576796-71bf76f9`. Dirty tree: `False`.
Command wall time: 0.75s; Cumulative test duration: 0.75s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
