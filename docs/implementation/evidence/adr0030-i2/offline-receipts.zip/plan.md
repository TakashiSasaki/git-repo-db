## Validation plan

Mode: `development`; Effective SHA `4235232e3b1384a19caabc4ef91c4b7b2703025f`; full acceptance selected: False.
Acceptance input hash: `527e4485764751d0f9cf10ddfb87aaef37c268b6cf0ffe6d123e032acc0d3fc0`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 195.
Selected test files: 0.
Unexecuted acceptance files: 195. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.414s.

### Scope reasons
Shared/executable input: .github/workflows/access-registry.yml
Unknown dependency path: docs/implementation/evidence/adr0030-i2/recovery.json
Shared/executable input: scripts/verify_access_distribution.py
Shared/executable input: src/repo_catalog/adapters/github/production_intake.py
Shared/executable input: src/repo_catalog/adapters/sqlite/p1_context.py
Shared/executable input: src/repo_catalog/adapters/sqlite/production_context.py
Shared/executable input: src/repo_catalog/application/acquisition.py
Shared/executable input: src/repo_catalog/domain/acquisition.py
Shared/executable input: src/repo_catalog/domain/p1_context.py
Shared/executable input: src/repo_catalog/domain/ports/p1_context.py
Dynamic test dependency requires full selection: tests/integration/test_catalog3_exchange.py
