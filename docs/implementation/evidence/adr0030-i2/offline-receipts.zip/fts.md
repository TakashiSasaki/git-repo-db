### fts: 0.02s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `4235232e3b1384a19caabc4ef91c4b7b2703025f`, tree `28b53a862db969e3231bd1a6f08a0c7f20d22874`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `fts-1792421545-50e78b18`. Dirty tree: `False`.
Command wall time: 0.02s; Cumulative test duration: 0.02s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
