### fts: 0.03s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `29ab752dfdd2f1a517bf8d2248887ad1d283ea3a`, tree `c5c85897826e4e2bc756c6ce811fef4d67a4b9e5`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `fts-1792174285-009cb75e`. Dirty tree: `False`.
Command wall time: 0.03s; Cumulative test duration: 0.03s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
