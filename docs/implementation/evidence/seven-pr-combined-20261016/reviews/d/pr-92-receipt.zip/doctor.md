### doctor: 0.11s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `10408198e8fc1c8f8e727bca58d014df2da995b0`, tree `a63fd1ea38fd22f6b45843cc60129fd946c563c6`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `doctor-1792176076-5de8d697`. Dirty tree: `False`.
Command wall time: 0.11s; Cumulative test duration: 0.11s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
