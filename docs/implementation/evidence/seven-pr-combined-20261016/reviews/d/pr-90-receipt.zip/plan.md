## Validation plan

Mode: `development`; Effective SHA `808382273fca2a4a8cad68017bf6c087c2ff6be8`; full acceptance selected: False.
Acceptance input hash: `b0ac6327edb17ecd551d003517e1ffc4062b7729b07768c7afa8da42b0a7bc72`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 176.
Selected test files: 0.
Unexecuted acceptance files: 176. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.039s.

### Scope reasons
Effective merge parents do not match event revisions
