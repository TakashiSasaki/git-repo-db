### doctor: 0.11s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `808382273fca2a4a8cad68017bf6c087c2ff6be8`, tree `71a8187a42de547f9f4bf8063632bc908e8e48ba`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `doctor-1792175242-a1caaba6`. Dirty tree: `False`.
Command wall time: 0.11s; Cumulative test duration: 0.11s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
