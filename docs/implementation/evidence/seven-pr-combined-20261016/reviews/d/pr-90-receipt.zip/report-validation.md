### report-validation: 0.22s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `808382273fca2a4a8cad68017bf6c087c2ff6be8`, tree `71a8187a42de547f9f4bf8063632bc908e8e48ba`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `report-validation-1792175241-89be2cd3`. Dirty tree: `False`.
Command wall time: 0.22s; Cumulative test duration: 0.22s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
