## Validation plan

Mode: `development`; Effective SHA `03b43fc87960b2d9144d6ef5803353e1dbcaf13b`; full acceptance selected: False.
Acceptance input hash: `e7cdef7a613db7b06026dcd0bc1ba4b0b91e86cdfe79355e337578df26d86529`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 158.
Selected test files: 0.
Unexecuted acceptance files: 158. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.037s.

### Scope reasons
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/artifact-sha256.json
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/classification.csv
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/classification.json
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/current-nodes.txt
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/disposition-audit.log
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/node-renames.json
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/reconciliation.json
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/reviews.json
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/after-initial/after-initial.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/after-initial/after-initial.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/after-initial/after-initial.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/after-second/after-second.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/after-second/after-second.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/after-second/after-second.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/before/before.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/before/before.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/before/before.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/clock/clock.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/clock/clock.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/clock/clock.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/deeper/deeper.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/deeper/deeper.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/deeper/deeper.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/equal-clock/equal-clock.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/equal-clock/equal-clock.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/equal-clock/equal-clock.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/final/final.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/final/final.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/final/final.xml.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/restart/restart.jsonl.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/restart/restart.log.gz
Unknown dependency path: docs/implementation/evidence/schema21-collection-20261016/runs/restart/restart.xml.gz
