### report-validation: 0.18s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `03b43fc87960b2d9144d6ef5803353e1dbcaf13b`, tree `62208ed7243aaacd45c3a9706dd957cbb1ebb222`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `report-validation-1792174508-7e7c7926`. Dirty tree: `False`.
Command wall time: 0.18s; Cumulative test duration: 0.18s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
