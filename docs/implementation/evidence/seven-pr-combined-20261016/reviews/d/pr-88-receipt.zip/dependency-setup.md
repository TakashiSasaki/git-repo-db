### dependency-setup: 0.60s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `80c3f278592e73efc2fd4049b96c17afb3d17257`, tree `87cd5817c5e945b0f29b8501bfa3fda6d2674dc4`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `dependency-setup-1792165517-aaf14990`. Dirty tree: `False`.
Command wall time: 0.60s; Cumulative test duration: 0.60s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
