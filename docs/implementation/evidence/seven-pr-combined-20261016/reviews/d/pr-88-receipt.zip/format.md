### format: 0.10s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `80c3f278592e73efc2fd4049b96c17afb3d17257`, tree `87cd5817c5e945b0f29b8501bfa3fda6d2674dc4`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `format-1792165518-b8d2a721`. Dirty tree: `False`.
Command wall time: 0.10s; Cumulative test duration: 0.10s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
