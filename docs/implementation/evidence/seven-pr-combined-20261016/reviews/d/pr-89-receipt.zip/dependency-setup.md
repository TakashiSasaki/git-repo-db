### dependency-setup: 0.47s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `80cf3399ab2469e5cdf791890bf95d4e813581e9`, tree `ed80623514a5e574d1e24e908b95504f60b815db`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `dependency-setup-1792162095-f2b4bbd5`. Dirty tree: `False`.
Command wall time: 0.47s; Cumulative test duration: 0.47s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
