### format: 0.06s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `80cf3399ab2469e5cdf791890bf95d4e813581e9`, tree `ed80623514a5e574d1e24e908b95504f60b815db`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `format-1792162096-9da64d8e`. Dirty tree: `False`.
Command wall time: 0.06s; Cumulative test duration: 0.06s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
