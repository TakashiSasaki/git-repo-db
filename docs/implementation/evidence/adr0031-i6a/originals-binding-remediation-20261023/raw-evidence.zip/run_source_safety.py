"""Source focused control execution; overlaps full, not benchmark evidence."""
import pathlib,sys,os,json,sqlite3,shutil
root=pathlib.Path('/workspace/git-repo-db');sys.path.insert(0,str(root))
from scripts import verify_i5_offline as e
out=pathlib.Path('/workspace/task-a-artifacts/source-safety');out.mkdir(exist_ok=False)
os.environ.update(PATH=str(pathlib.Path(sys.executable).parent)+os.pathsep+os.environ['PATH'],TMPDIR='/workspace/task-a-tmp',PYTHONPATH='/workspace/task-a-tools',UV_CACHE_DIR='/workspace/uv-cache',I6A_SQL_PROBE_OUTPUT=str(out/'sql-observations.json'))
def binding():return dict(head=e.git('rev-parse','HEAD'),tree=e.git('rev-parse','HEAD^{tree}'),inputs=e.input_hashes(),status=e.git('status','--porcelain','--untracked-files=no'))
e.write_json(out/'binding-before.json',binding());e.write_json(out/'runtime.json',e.runtime_metadata(sqlite3.connect(':memory:')))
targets=['tests/integration/p3/test_transfer_sql.py','tests/integration/p3/test_transfer_admission.py','tests/integration/p3/test_parent_reports.py','tests/unit/test_context_admission.py','tests/unit/test_transfer_originals.py','tests/unit/test_context_fences_i6a.py','tests/unit/test_context_oid_admission_i6a.py','tests/unit/test_context_admission_bounds_i6a.py','tests/unit/test_context_coordinator_admission.py','tests/unit/test_context_refusal_order_i6a.py','tests/integration/p1/test_coordination.py','tests/integration/i6a','tests/unit/test_i6a_regression_bindings.py']
nodes,r=e.collect(out,'focused-collection',targets)
assert r['exit_code']==0
execute=e.execute
def typed(out,name,args):
 os.environ['I6A_REPORTS_SIDECAR']=str(out/(name+'.report-types.jsonl'))
 return execute(out,name,['-p','i6a_report_types',*args,'--basetemp='+str(out/'basetemp')])
e.execute=typed
r=e.run_cohort(out,'ordinary',nodes,0)
e.write_json(out/'binding-after.json',binding());raise SystemExit(r['exit_code'])
