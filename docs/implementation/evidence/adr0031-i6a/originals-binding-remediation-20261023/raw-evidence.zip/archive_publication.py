"""Preserve execution files only, never disposable databases/environments."""
from pathlib import Path
import hashlib,json,zipfile,shutil,subprocess
source=Path('/workspace/task-a-artifacts'); publication=Path('/workspace/task-a-publication')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(name,value): (publication/name).write_text(json.dumps(value,indent=2)+'\n')
for target,original in [('full-summary.json','full-analysis/summary.json'),('diagnostic-summary.json','diagnostic-analysis/summary.json'),('first-boundary-changes.json','diagnostic-analysis/first-boundary-changes.json'),('binding-controls.json','binding-actual-controls.json'),('installed-summary.json','installed-verification-handoff.json'),('pre-submission-recheck.json','pre-submission-recheck.json')]: shutil.copy2(source/original,publication/target)
binding=json.loads((source/'full/binding-before.json').read_text());root=Path('/workspace/git-repo-db');mismatches=[]
for path,digest in binding['inputs'].items():
 raw=(root/path).read_bytes();frozen=subprocess.check_output(['git','show',binding['head']+':'+path],cwd=root)
 if sha(raw)!=digest or sha(frozen)!=digest:mismatches.append(path)
assert not mismatches
write('source-input-binding.json',{'base_head':'274645e7dd451e24f324feb81b1591a64ba2a7ab','base_tree':'773c7de12d2ea564aeabe4c87a980e4fe438ce1f','tested_head':binding['head'],'tested_tree':binding['tree'],'input_count':len(binding['inputs']),'inputs':binding['inputs'],'publication_input_mismatches':mismatches,'scope':'Execution inputs remain equal after evidence/skill additions. Full later source archive/sdist is not claimed built or qualified.'})
write('findings.json',{'implementation_author_verification':True,'independent_review':'pending separate Task C; not initiated here','findings':[{'id':'ORIGINALS-M1','prior_severity':'Medium','status':'implemented_requires_non_author_re_review','saved_counterexample_before':{'required_refusals':0,'exit_code':1},'after_each_source_direct_sdist':{'required_refusals':4,'ordinary_fence_controls':2,'exit_code':0},'new_automated_nodes':75,'authority_before_complete_originals':True,'zero_writes_before_refusal':True},{'id':'I6A-IR-L01','prior_severity':'Low','status':'implemented_requires_non_author_re_review','plain_and_gzip_bindings_required':True,'missing_either_or_both':'explicit inconsistent-run error','head_tree_inputs_status_compared':True,'automated_nodes':27}], 'remaining_downstream_unsuccessful_nodes':{'I6-C':242,'I7_composition':14,'Transfer_stage':43},'independent_acceptance':'not declared','full_acceptance':False})
write('executions.json',{'full':json.loads((source/'full/ordinary.execution.json').read_text()),'source_safety':json.loads((source/'source-safety/ordinary.execution.json').read_text()),'source_authorization':json.loads((source/'source-auth/reconciled-execution.json').read_text()),'installed':json.loads((source/'installed-verification-handoff.json').read_text()),'scope':'Overlapping actual invocations, not additive unique coverage or independent acceptance. Full legacy duplicate-subtest flags retained; typed audit in full-summary separately reconciles all protocols. All nonzero earlier setup/iterative invocations preserved in raw evidence.'})
files=[]
for path in sorted(source.rglob('*')):
 if not path.is_file() or path.is_symlink(): continue
 rel=path.relative_to(source)
 if any(part in {'basetemp','__pycache__','pr146-raw-one-invocation'} for part in rel.parts):continue
 if path.suffix in {'.pyc','.db','.sqlite','.whl'}:continue
 files.append((rel.as_posix(),path))
entries={}
with zipfile.ZipFile(publication/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for rel,path in files:
  raw=path.read_bytes();info=zipfile.ZipInfo(rel,date_time=(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,raw)
  entries[rel]={'bytes':len(raw),'sha256':sha(raw)}
write('raw-index.json',{'scope':'Actual Task A execution files; disposable basetemp databases, environments and extracted unchanged #146 raw copies excluded. Baseline provenance and receipts retained. Original relative artifact paths preserved.','members':entries})
payloads={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(publication.iterdir()) if p.is_file() and p.name!='artifact-index.json'}
write('artifact-index.json',{'tested_head':binding['head'],'tested_tree':binding['tree'],'scope':'Index excludes itself; publication Git tree binds index. No independent acceptance or final full-sdist qualification.','payloads':payloads})
print(json.dumps({'raw_members':len(entries),'payloads':len(payloads),'raw_zip_bytes':(publication/'raw-evidence.zip').stat().st_size}))
