"""Explain all23 differences from #146 raw one-invocation, without synthesis."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT=Path('/workspace/task-a-artifacts/full-analysis')
ROOT=Path('/workspace/git-repo-db')
rows=json.loads(gzip.decompress((OUT/'node-comparison.json.gz').read_bytes()))
prior=json.loads(gzip.decompress((ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-independent/failure-audit/full-latest-node-map.json.gz').read_bytes()))
prior={r['nodeid']:r for r in prior}
xml=ET.parse(OUT/'pr146-raw-one-invocation/ordinary.xml')
traces={}
for case in xml.iter('testcase'):
    for kind in ['failure','error']:
        event=case.find(kind)
        if event is not None:traces[(case.get('classname'),case.get('name'))]=event.text or '';break

def key(node):
    head,bracket,parameter=node.partition('[');parts=head.split('::');parts[-1]+=bracket+parameter
    return parts[0].removesuffix('.py').replace('/','.')+''.join('.'+p for p in parts[1:-1]),parts[-1]

changed=[]
for row in rows:
    if 'versus_raw_one_invocation' not in row or row['versus_raw_one_invocation']['same_outcome_phase']:continue
    node=row['nodeid'];old=prior[node];trace=traces[key(node)]
    if old['was_uv_cache_blocked_in_full']:
        assert 'Failed to initialize cache' in trace and 'Read-only file system' in trace
        cause='pr146-raw-uv-cache-read-only-setup-error'
    else:
        assert old['was_extra_timeout_in_full']
        assert "'timed_out': True" in row['raw_baseline']['message'] and "'timeout_seconds': 30" in row['raw_baseline']['message']
        cause='pr146-raw-30-second-query-timeout'
    changed.append({'nodeid':node,'before':row['raw_baseline'],'current':row['new'],'cause_observed_in_pr146_raw_trace':cause,'pr146_raw_trace_sha256':hashlib.sha256(trace.encode()).hexdigest(),'prior_latest_outcome_phase_equals_current':row['versus_prior_combined_latest']['same_outcome_phase'],'current_classification':row['classification']})
assert len(changed)==23
cache=[r for r in changed if r['cause_observed_in_pr146_raw_trace']=='pr146-raw-uv-cache-read-only-setup-error']
assert len(cache)==22 and Counter(r['current']['outcome'] for r in cache)=={'passed':18,'failed':4}
timeout=[r for r in changed if r not in cache];assert len(timeout)==1 and timeout[0]['current']['outcome']=='passed'
result={'scope':'Actual current single full run versus actual #146 raw single run; no retry outcomes are inserted into either run. All23 node outcome/phase deltas are causally checked against archived raw traceback content.','raw_delta_count':23,'archived_readonly_uv_cache_setup_errors':22,'current_outcomes_for_those22':dict(Counter(r['current']['outcome'] for r in cache)),'archived_timeout_count':1,'current_timeout_node_outcome':'passed','new_unknown_outcome_phase_differences':0,'rows':changed,'analysis_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'raw-one-run-delta.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
