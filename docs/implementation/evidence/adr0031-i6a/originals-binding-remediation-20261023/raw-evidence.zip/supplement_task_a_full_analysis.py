"""Resolve caught-I7 full failures with separate current diagnostic evidence.

This adds classification evidence, never replacement test outcomes. Full JUnit
messages remain raw, including pytest's path-length-dependent repr abbreviation.
"""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re

OUT=Path('/workspace/task-a-artifacts/full-analysis')
DIAG=Path('/workspace/task-a-artifacts/diagnostic-analysis')

def load(path):
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)
def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode();path.write_bytes(gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw)
def signature(result):
    return {'outcome':result['outcome'],'phase':result['phase'],'assertion_first_line':result['message'].splitlines()[0],'receipt_reasons':dict(Counter(re.findall(r"'reason': ([^}\n]+)",result['message']))),'trace_coordinates':[(f['path'],f['line']) for f in result['frames']]}

rows=load(OUT/'node-comparison.json.gz');diagnostic={r['nodeid']:r for r in load(DIAG/'node-comparison.json.gz')};summary=load(OUT/'summary.json')
# Preserve the exact initial limited-trace analysis, including unresolved13.
for name in ['summary.json','node-comparison.json.gz','unsuccessful-comparison.json.gz']:
    before=OUT/('before-current-diagnostic-'+name)
    if not before.exists():before.write_bytes((OUT/name).read_bytes())
resolved=[]
for row in rows:
    if row.get('classification')!='UNRESOLVED_REQUIRES_REVIEW':continue
    proof=diagnostic[row['nodeid']]
    assert proof['classification']=='I7-composition'
    assert proof['actual_admission_exception_frames']
    assert any(frame['path'].endswith('/context_admission.py') and frame['source'].strip()=='raise AdmissionRefused("PERMISSION_DENIED")' for frame in proof['actual_admission_exception_frames'])
    assert any(frame['path'].endswith('/recovery.py') for frame in proof['actual_admission_exception_frames'])
    new=signature(row['new']);current_diagnostic=signature(proof['new_diagnostic']);previous=signature(row['latest_prior_baseline'])
    assert new==current_diagnostic,(row['nodeid'],new,current_diagnostic)
    assert all(new[key]==previous[key] for key in ['outcome','phase','assertion_first_line','receipt_reasons'])
    assert row['versus_prior_combined_latest']['same_normalized_path_functions']
    assert 'Context admission error: PERMISSION_DENIED' in row['new']['message']
    row['classification']='I7-composition'
    row['classification_basis']='Actual current separate diagnostic captures Recovery admission refusal; current full and diagnostic match exact outcome/phase, assertion first line, all receipt reason strings/multiplicities and complete traceback coordinates. Full matches prior outcome/phase/assertion/reasons/source-function sequence. No diagnostic outcome replaces the full result.'
    row['current_diagnostic_evidence']={'comparison_signature':new,'actual_admission_exception_frames':proof['actual_admission_exception_frames'],'actual_local_assertion_lines_entered':proof['actual_local_assertion_lines_entered'],'diagnostic_node_map_sha256':hashlib.sha256((DIAG/'node-comparison.json.gz').read_bytes()).hexdigest(),'literal_full_message_remains_different':'pytest abbreviates MergeReceipt repr at a length depending on absolute destination path; raw messages/traces and initial unresolved analysis retained.'}
    resolved.append({'nodeid':row['nodeid'],'signature':new,'previous_signature':previous})
assert len(resolved)==13
unsuccessful=[row for row in rows if row.get('new') and row['new']['outcome']!='passed']
summary['all_unsuccessful_classes']=dict(Counter(row['classification'] for row in unsuccessful))
summary['inherited299']['classifications']=dict(Counter(row['classification'] for row in rows if row.get('latest_prior_baseline') and row['latest_prior_baseline']['outcome']!='passed'))
summary['unresolved_nodes']=[r['nodeid'] for r in unsuccessful if r['classification'].startswith('UNRESOLVED')]
summary['current_diagnostic_classification_supplement']={'resolved_count':len(resolved),'category':'I7-composition','scope':'Separate diagnostic supplies actual caught-event stacks only. One full-run counts/outcomes remain unchanged. Initial full analysis unresolved13 is preserved.','signature_comparisons':'Exact full-vs-current-diagnostic outcome/phase, first assertion line, receipt reasons and multiplicities, traceback coordinates; same prior source function trace. Raw complete messages still retained; no arbitrary-path normalization pretends equality.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'node_comparisons':resolved}
save(OUT/'node-comparison.json.gz',rows);save(OUT/'unsuccessful-comparison.json.gz',unsuccessful);save(OUT/'summary.json',summary)
print(json.dumps({'full_counts':summary['new_run']['counts'],'classes':summary['all_unsuccessful_classes'],'resolved_current_diagnostic':len(resolved),'unresolved':len(summary['unresolved_nodes'])},indent=2))
