import sys,pathlib,os,subprocess,time,json,hashlib
root=pathlib.Path('/workspace/git-repo-db');out=pathlib.Path('/workspace/task-a-artifacts/source-auth');records=[]
env=dict(os.environ,PATH=str(pathlib.Path(sys.executable).parent)+os.pathsep+os.environ['PATH'],PYTHONPATH=str(root/'src')+':'+str(root)+':'+str(root/'tests/support/network_guard'),UV_CACHE_DIR='/workspace/uv-cache',TMPDIR='/workspace/task-a-tmp')
def run(name,args):
 start=time.time()
 with (out/(name+'.log')).open('w') as stream:r=subprocess.run([sys.executable,*map(str,args)],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=[sys.executable,*map(str,args)],cwd=str(root),exit_code=r.returncode,started_epoch=start,elapsed_seconds=time.time()-start));(out/'executions.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
args=['-m','pytest','-q','-c',root/'pyproject.toml','--rootdir='+str(root),'--confcutdir='+str(root),'-p','scripts.ci_journal',out/'test_independent_authorization.py','-o','addopts=','-o','junit_family=xunit1']
run('collection',[*args,'--collect-only'])
run('pytest',[*args,'--junitxml='+str(out/'junit.xml'),'--journal='+str(out/'journal.jsonl'),'--basetemp=/workspace/task-a-artifacts/source-auth/basetemp'])
review=root/'docs/implementation/evidence/adr0031-i6a/remediation-independent/originals'
for name in ('probe_originals','probe_invalid_carrier'):
 run(name,[review/(name+'.py'),out/(name+'.json')])
raise SystemExit(int(any(r['exit_code'] for r in records)))
