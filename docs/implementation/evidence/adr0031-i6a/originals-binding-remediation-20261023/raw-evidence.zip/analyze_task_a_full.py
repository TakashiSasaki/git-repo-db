"""Compare one Task A invocation with distinct #146 raw and combined baselines.

This analysis never merges test results into the current invocation. Classified
ownership from earlier diagnostic traces is explicitly marked as prior evidence.
"""
import argparse
import ast
from collections import Counter
from functools import lru_cache
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def save(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    path.write_bytes(gzip.compress(raw, mtime=0) if path.suffix == '.gz' else raw)


def command(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/workspace/git-repo-db'))
    parser.add_argument('--full', type=Path, default=Path('/workspace/task-a-artifacts/full'))
    parser.add_argument('--out', type=Path, default=Path('/workspace/task-a-artifacts/full-analysis'))
    parser.add_argument('--tested-head', default='f777d195bd219398a51d2a90553377f61fb39370')
    args = parser.parse_args()
    root, full, out = args.root.resolve(), args.full.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    spec = importlib.util.spec_from_file_location('task_a_classifier', root/'scripts/classify_i6a_regressions.py')
    classifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(classifier)
    review = root/'docs/implementation/evidence/adr0031-i6a/remediation-independent'
    current, receipt = classifier.run_index(full)
    assert receipt['source_binding_before']['head'] == args.tested_head
    assert receipt['checks']['source_bindings_complete_and_unchanged']
    expected_tree = command(root, 'rev-parse', args.tested_head+'^{tree}').decode().strip()
    assert receipt['source_binding_before']['tree'] == expected_tree

    # Recheck every actual executable/test/script/config input against both its
    # recorded digest and frozen Git blob. This is not a full-sdist byte claim.
    input_checks = []
    for name, expected in sorted(receipt['source_binding_before']['inputs'].items()):
        current_hash = digest((root/name).read_bytes())
        git_hash = digest(command(root, 'show', args.tested_head+':'+name))
        input_checks.append({'path': name, 'recorded_sha256': expected, 'current_sha256': current_hash, 'frozen_git_sha256': git_hash, 'all_equal': current_hash == git_hash == expected})
    assert all(row['all_equal'] for row in input_checks)
    save(out/'tested-inputs.json', input_checks)
    save(out/'new-run-receipt.json', receipt)

    # Exercise actual compressed resolution without replacing the original run.
    compressed = out/'new-run-compressed-transport'
    compressed.mkdir(exist_ok=True)
    required = ['ordinary.selected.txt', 'ordinary.xml', 'ordinary.jsonl', 'ordinary.report-types.jsonl', 'ordinary.execution.json']
    for name in required:
        target = compressed/name
        if target.is_symlink() or target.exists():
            target.unlink()
        target.symlink_to(full/name)
    for name in ['binding-before.json', 'binding-after.json']:
        raw = classifier.read(full/name)
        (compressed/(name+'.gz')).write_bytes(gzip.compress(raw, mtime=0))
    compressed_index, compressed_receipt = classifier.run_index(compressed)
    assert compressed_index == current
    assert compressed_receipt['source_binding_before'] == receipt['source_binding_before']
    assert compressed_receipt['source_binding_after'] == receipt['source_binding_after']
    assert compressed_receipt['checks']['source_bindings_complete_and_unchanged']
    save(out/'new-run-compressed-receipt.json', compressed_receipt)

    archived = out/'pr146-raw-one-invocation'
    archived.mkdir(exist_ok=True)
    archive = review/'raw-local-evidence.zip'
    verified_members = []
    with zipfile.ZipFile(archive) as z:
        index = json.loads(z.read('receipt-index.json'))
        for name in required + ['binding-before.json', 'binding-after.json']:
            member = 'source-run/'+name
            raw = z.read(member)
            assert len(raw) == index[member]['bytes'] and digest(raw) == index[member]['sha256']
            (archived/name).write_bytes(raw)
            verified_members.append({'name': member, **index[member]})
    baseline_raw, baseline_receipt = classifier.run_index(archived)
    assert baseline_receipt['counts'] == {'passed':5656,'failed':276,'error':42}
    save(out/'pr146-raw-receipt.json', baseline_receipt)
    latest_rows = load(review/'failure-audit/full-latest-node-map.json.gz')
    baseline_latest = {row['nodeid']: row['latest'] for row in latest_rows}
    latest_map = {row['nodeid']: row for row in latest_rows}
    assert set(baseline_raw) == set(baseline_latest)
    assert Counter(row['outcome'] for row in baseline_latest.values()) == {'passed':5675,'failed':279,'error':20}
    # Ensure the published raw projections and actual archived raw invocation agree.
    for node, result in baseline_raw.items():
        projection = latest_map[node]['raw_full']
        assert all(result.get(key) == projection.get(key) for key in ['outcome','phase','message','trace_sha256'])
    save(out/'baseline-provenance.json', {'review_head':'274645e7dd451e24f324feb81b1591a64ba2a7ab','source_head':'08fbb956c2e470e245146b0dbae747ed0690ea40','raw_archive_sha256':digest(archive.read_bytes()),'verified_raw_members':verified_members,'combined_latest_map_sha256':digest((review/'failure-audit/full-latest-node-map.json.gz').read_bytes()),'distinction':'Raw is one #146 invocation. Latest is a prior multi-invocation projection, separately compared and never represented as one full run.'})

    @lru_cache(maxsize=None)
    def source(sha, path):
        try:
            raw = command(root, 'show', sha+':'+path)
        except subprocess.CalledProcessError:
            return None, []
        text = raw.decode()
        return ast.parse(text), text.splitlines()

    def frames(result, sha):
        output = []
        for frame in result.get('frames', []):
            tree, lines = source(sha, frame['path'])
            candidates = [n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.lineno <= frame['line'] <= n.end_lineno] if tree else []
            function = min(candidates,key=lambda n:n.end_lineno-n.lineno).name if candidates else frame.get('function','')
            output.append({'path':frame['path'],'function':function,'line':frame['line'],'source':lines[frame['line']-1] if 0 < frame['line'] <= len(lines) else None})
        return output

    def normalized_message(message):
        # JUnit may abbreviate repr path lengths. Normalize only actual pytest
        # temporary-directory literals and retain complete raw messages alongside.
        return re.sub(r'/workspace/(?:review-source-run|review-clean743|review-full-cache-corrected|review-serial-timeout|task-a-artifacts/full)/basetemp/[^\s\'\",)]*', '<VOLATILE_TEST_PATH>', message)

    def compare(old, new):
        before_frames = frames(old, '08fbb956c2e470e245146b0dbae747ed0690ea40')
        after_frames = frames(new, args.tested_head)
        return {'same_outcome_phase':(old['outcome'],old['phase']) == (new['outcome'],new['phase']),'same_raw_message':old['message']==new['message'],'same_volatile_path_normalized_message':normalized_message(old['message'])==normalized_message(new['message']),'same_trace_sha256':old.get('trace_sha256')==new.get('trace_sha256'),'same_normalized_path_functions':[(f['path'],f['function']) for f in before_frames]==[(f['path'],f['function']) for f in after_frames],'before_frames_resolved':before_frames,'after_frames_resolved':after_frames}

    raw_xml = ET.fromstring(classifier.read(full/'ordinary.xml'))
    traces = {}
    for case in raw_xml.findall('.//testcase'):
        for tag in ('failure','error','skipped'):
            event = case.find(tag)
            if event is not None:
                traces[(case.get('classname'),case.get('name'))] = event.text or ''
                break
    rows=[]
    for node in sorted(set(baseline_raw)|set(current)):
        new=current.get(node)
        row={'nodeid':node,'new':new,'added_node':node not in baseline_raw,'removed_node':new is None}
        if new is None:
            rows.append(row);continue
        row['raw_baseline']=baseline_raw.get(node)
        row['latest_prior_baseline']=baseline_latest.get(node)
        if node in baseline_raw:
            row['versus_raw_one_invocation']=compare(baseline_raw[node],new)
            row['versus_prior_combined_latest']=compare(baseline_latest[node],new)
            row['prior_classification']=latest_map[node]['classification']
        if new['outcome']=='passed':
            row['classification']='PASS'
            row['reachability']='completed body; conditional assertion branches and child coverage not inferred'
        else:
            trace=traces.get(classifier.junit_key(node),'')
            row['new_trace_text_sha256']=digest(trace.encode())
            row['new_exception']=classifier.exception(new['message'])
            row['new_refusals']=sorted(set(re.findall(r'\b(?:PERMISSION_DENIED|INCOMPLETE_ORIGINAL_REPORT|I2_TRANSFER_UNSUPPORTED|I2_IDENTIFICATION_WIRE_UNSUPPORTED|CAPABILITY_EXPIRED|UNQUALIFIED_MAPPING)\b',new['message']+'\n'+trace)))
            direct=classifier.classify(new,root)
            row['shipped_classifier_result']=direct
            row['reachability']='test body unentered' if new['phase']=='setup' else 'call failed; only reached traceback/assertions established, later assertions unverified'
            resolved=frames(new,args.tested_head)
            row['reached_source_frames']=resolved
            if 'I2_TRANSFER_UNSUPPORTED' in new['message'] or ('i2_transfer_unsupported' in trace.lower() and 'sqlite3.IntegrityError' in new['message']):
                row['classification']='Transfer-stage'
                row['classification_basis']='actual current Transfer refusal/SQL fence text'
            elif direct[1]=='I6-C':
                row['classification']='I6-C'
                row['classification_basis']='actual current source-resolved Provider/Exchange guard'
            elif direct[1]=='I7':
                row['classification']='I7-composition'
                row['classification_basis']='actual current source-resolved Recovery missing authority'
            elif node in latest_map and row['versus_prior_combined_latest']['same_outcome_phase'] and row['versus_prior_combined_latest']['same_volatile_path_normalized_message'] and row['versus_prior_combined_latest']['same_normalized_path_functions']:
                row['classification']=latest_map[node]['classification']
                row['classification_basis']='current phase, normalized message and source function trace match prior diagnostic classification; prior internal caught-event traces are not current instrumentation'
                row['prior_diagnostic_support']=latest_map[node].get('diagnostic_support')
                row['prior_source_proof']=latest_map[node].get('source_proof')
            elif 'Permission denied' in trace and ('uv' in trace or 'cache' in trace):
                row['classification']='environment-cache-permission'
                row['classification_basis']='actual current traceback cache/uv permission refusal'
            else:
                row['classification']='UNRESOLVED_REQUIRES_REVIEW'
                row['classification_basis']='retained for direct traceback review; no inference from node name or historical cohort'
            if row['classification']=='UNRESOLVED_REQUIRES_REVIEW':
                row['new_trace']=trace
        rows.append(row)
    save(out/'node-comparison.json.gz',rows)
    inherited299={node for node,result in baseline_latest.items() if result['outcome']!='passed'}
    unsuccessful=[row for row in rows if row.get('new') and row['new']['outcome']!='passed']
    added=[row for row in rows if row['added_node']]
    changed_latest=[row for row in rows if 'versus_prior_combined_latest' in row and not row['versus_prior_combined_latest']['same_outcome_phase']]
    summary={'scope':'One actual Task A ordinary invocation; no supplemental outcomes combined. Prior #146 one-run and multi-run node projection are distinct comparison baselines. Not independent re-review or release acceptance.','tested_head':args.tested_head,'tested_tree':expected_tree,'input_count':len(input_checks),'all_inputs_match_binding_current_and_frozen_git':True,'new_run':{'counts':receipt['counts'],'selected':receipt['selected'],'exit_code':receipt['exit_code'],'subtest_count':receipt['subtest_count'],'subtest_outcomes':receipt['subtest_outcomes'],'checks':receipt['checks']},'compressed_binding_transport_recheck':compressed_receipt['checks']['source_bindings_complete_and_unchanged'],'pr146_raw_one_invocation':baseline_receipt['counts'],'pr146_prior_combined_latest_NOT_ONE_RUN':dict(Counter(result['outcome'] for result in baseline_latest.values())),'node_identity':{'removed':sorted(set(baseline_raw)-set(current)),'added_count':len(added),'added_outcomes':dict(Counter(row['new']['outcome'] for row in added))},'versus_pr146_raw':{'outcome_phase_differences':sum(not row['versus_raw_one_invocation']['same_outcome_phase'] for row in rows if 'versus_raw_one_invocation' in row)},'versus_pr146_prior_combined_latest':{'outcome_phase_differences':len(changed_latest),'changed_nodes':[row['nodeid'] for row in changed_latest]},'all_unsuccessful_classes':dict(Counter(row['classification'] for row in unsuccessful)),'inherited299':{'present':len(inherited299&set(current)),'outcomes':dict(Counter(current[node]['outcome'] for node in inherited299 if node in current)),'classifications':dict(Counter(row['classification'] for row in rows if row['nodeid'] in inherited299))},'unresolved_nodes':[row['nodeid'] for row in unsuccessful if row['classification']=='UNRESOLVED_REQUIRES_REVIEW'],'analysis_script_sha256':digest(Path(__file__).read_bytes())}
    save(out/'summary.json',summary)
    save(out/'unsuccessful-comparison.json.gz',unsuccessful)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
