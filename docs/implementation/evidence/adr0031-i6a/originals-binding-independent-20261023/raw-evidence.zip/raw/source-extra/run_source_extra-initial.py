"""Independent Task C source controls; distinct from the one full invocation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path('/workspace/git-repo-db');TOOLS=Path(__file__).resolve().parent;OUT=Path('/workspace/task-c/raw/source-extra');OUT.mkdir()
env=dict(os.environ,PATH=str(Path(sys.executable).parent)+os.pathsep+os.environ['PATH'],UV_CACHE_DIR='/workspace/task-c/cache',REPO_CATALOG_WHEELHOUSE='/workspace/task-c/wheelhouse',TMPDIR='/workspace/task-c/tmp',PYTHONPATH=str(ROOT/'src')+':'+str(ROOT)+':'+str(TOOLS)+':'+str(ROOT/'tests/support/network_guard'),TASK_C_OBSERVATIONS=str(OUT/'task-c-observations'))
for k in ['GH_TOKEN','GITHUB_TOKEN','PYTHONHOME']:env.pop(k,None)
records=[]
def run(name,command):
 t=time.time()
 with (OUT/(name+'.log')).open('w') as f:p=subprocess.run(list(map(str,command)),cwd=TOOLS,env=env,stdout=f,stderr=subprocess.STDOUT)
 r={'name':name,'command':list(map(str,command)),'cwd':str(TOOLS),'exit_code':p.returncode,'elapsed_seconds':time.time()-t}
 records.append(r);(OUT/'processes.json').write_text(json.dumps(records,indent=2)+'\n');return r
tracked=subprocess.check_output(['git','ls-files','src','tests','scripts','.github/workflows','pyproject.toml','uv.lock'],cwd=ROOT,text=True).splitlines()
def binding():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'inputs':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in tracked},'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()}
for name,target,count in [('authorization','reviewer_policy.py',27),('task-c','test_task_c_originals.py',132)]:
 d=OUT/name;d.mkdir();(d/'binding-before.json').write_text(json.dumps(binding()))
 args=[sys.executable,'-m','pytest','-q','-c',str(ROOT/'pyproject.toml'),'--confcutdir='+str(TOOLS),'--rootdir='+str(TOOLS),'-o','addopts=','-o','junit_family=xunit1','-p','scripts.ci_journal','-p','i6a_report_types',target]
 r=run(name+'-collect',args+['--collect-only']);assert not r['exit_code']
 nodes=[line for line in (OUT/(name+'-collect.log')).read_text().splitlines() if '.py::' in line and not line.startswith((' ', '<', '='))]
 assert len(nodes)==len(set(nodes))==count
 (d/'ordinary.selected.txt').write_text('\n'.join(nodes)+'\n')
 env['I6A_REPORTS_SIDECAR']=str(d/'ordinary.report-types.jsonl')
 r=run(name,args+['--junitxml='+str(d/'ordinary.xml'),'--journal='+str(d/'ordinary.jsonl'),'--basetemp='+str(d/'basetemp')])
 (d/'ordinary.execution.json').write_text(json.dumps(r,indent=2)+'\n');(d/'binding-after.json').write_text(json.dumps(binding()))
 if name=='authorization':
  (OUT/'authorization-sql-observations.json').write_bytes((TOOLS/'sql-observations.json').read_bytes())
review=ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-independent/originals'
for name in ['probe_originals','probe_invalid_carrier']:run(name,[sys.executable,review/(name+'.py'),OUT/(name+'.json')])
raise SystemExit(int(any(r['exit_code'] for r in records)))
