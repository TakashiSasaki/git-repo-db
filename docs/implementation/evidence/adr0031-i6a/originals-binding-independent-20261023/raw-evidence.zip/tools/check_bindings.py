"""Task C reproduces the saved gzip defect and independent actual-run controls."""
from pathlib import Path
import copy,gzip,hashlib,importlib.util,json,shutil,subprocess
ROOT=Path('/workspace/git-repo-db');OUT=Path('/workspace/task-c/raw/binding-controls');OUT.mkdir()
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
oldfile=OUT/'pr146_classifier.py';oldfile.write_bytes(subprocess.check_output(['git','show','274645e7dd451e24f324feb81b1591a64ba2a7ab:scripts/classify_i6a_regressions.py'],cwd=ROOT))
old=module('old',oldfile);new=module('new',ROOT/'scripts/classify_i6a_regressions.py')
records=[]
for name in ['before','after-final']:
 d=ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-20261023'/name
 _,o=old.run_index(d);_,n=new.run_index(d)
 assert o['consistent'] and o['source_binding_before'] is None and o['source_binding_after'] is None
 assert n['consistent'] and n['checks']['source_bindings_complete_and_unchanged']
 records.append({'saved_path':str(d.relative_to(ROOT)),'old':o,'new':n})
base=ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-20261023/after-final'
originals={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir() if p.is_file()}
bind=json.loads(new.read(base/'binding-before.json'))
for case in ['matching','missing-before','missing-after','missing-both','head','tree','inputs','status','empty-inputs','missing-head','missing-tree','missing-inputs','missing-status']:
 d=OUT/case;d.mkdir()
 for name in ['ordinary.selected.txt','ordinary.xml','ordinary.jsonl','ordinary.report-types.jsonl','ordinary.execution.json']:
  src=base/name
  if not src.exists():src=Path(str(src)+'.gz')
  (d/src.name).symlink_to(src)
 values=[copy.deepcopy(bind),copy.deepcopy(bind)]
 if case in ['head','tree']:values[1][case]='a'*40 if bind[case]!='a'*40 else 'b'*40
 if case=='inputs':values[1]['inputs'][next(iter(bind['inputs']))]='a'*64
 if case=='status':values[1]['status']=' M src/changed.py'
 if case=='empty-inputs':
  for b in values:b['inputs']={}
 if case.startswith('missing-') and case not in ['missing-before','missing-after','missing-both']:
  for b in values:b.pop(case[len('missing-'):])
 for which,b in zip(['before','after'],values):
  if case in ['missing-'+which,'missing-both']:continue
  (d/f'binding-{which}.json.gz').write_bytes(gzip.compress(json.dumps(b).encode(),mtime=0))
 try:
  _,receipt=new.run_index(d);accepted=receipt['consistent'];error=None
 except ValueError as e:
  assert '"source_bindings_complete_and_unchanged": false' in str(e)
  accepted=False;error=str(e)
 assert accepted==(case=='matching'),case
 records.append({'control':case,'accepted':accepted,'expected':case=='matching','error':error})
assert originals=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir() if p.is_file()}
(OUT/'summary.json').write_text(json.dumps({'saved_archives_unchanged':True,'new_controls':13,'records':records},indent=2)+'\n')
print('saved gzip bug reproduced twice; fixed parser accepts originals; 13 controls pass')
