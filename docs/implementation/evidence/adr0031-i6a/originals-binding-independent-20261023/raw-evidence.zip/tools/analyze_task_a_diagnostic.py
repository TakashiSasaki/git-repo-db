"""Reconcile actual Task A inherited743 assertion/admission trace diagnostic.

This is remediation-author evidence using attributed #146 helpers, not an
independent acceptance review. It never adds diagnostic outcomes to a full run.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess


def digest(raw): return hashlib.sha256(raw).hexdigest()
def load(path):
    raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)
def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    path.write_bytes(gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw)
def lines(path):return [json.loads(line) for line in path.read_bytes().splitlines() if line]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('/workspace/git-repo-db'))
    parser.add_argument('--run',type=Path,default=Path('/workspace/task-c/raw/diagnostic743'))
    parser.add_argument('--out',type=Path,default=Path('/workspace/task-c/raw/diagnostic-analysis'))
    parser.add_argument('--tested-head',default='268025f67841285d105737b5a0d7bd15b1a6f59c')
    args=parser.parse_args();root=args.root.resolve();run=args.run.resolve();out=args.out.resolve();out.mkdir(exist_ok=True,parents=True)
    review=root/'docs/implementation/evidence/adr0031-i6a/remediation-independent/failure-audit'
    audit=module('task_a_attributed_audit',review/'audit.py')
    classifier=module('task_a_fixed_classifier',root/'scripts/classify_i6a_regressions.py')
    actual,receipt=classifier.run_index(run,prefix='diagnostic')
    independently_parsed,second_receipt=audit.receipt(run,prefix='diagnostic')
    assert set(actual)==set(independently_parsed)
    assert all((r['outcome'],r['phase'])==(independently_parsed[n]['outcome'],independently_parsed[n]['phase']) for n,r in actual.items())
    baseline_rows=load(review/'clean743.json.gz');baseline={r['nodeid']:r for r in baseline_rows}
    assert set(actual)==set(baseline) and len(actual)==743
    bindings=[load(run/name) for name in ['binding-before.json','binding-after.json']]
    assert bindings[0]['head']==bindings[1]['head']==args.tested_head
    assert not bindings[0]['status'] and not bindings[1]['status']
    assert all(bindings[0][key]==bindings[1][key] for key in ['head','tree','inputs','status'])
    inputs=bindings[0]['inputs'];checks=[]
    for path,expected in sorted(inputs.items()):
        git_bytes=subprocess.check_output(['git','show',args.tested_head+':'+path],cwd=root)
        checks.append({'path':path,'sha256':expected,'git_sha256':digest(git_bytes),'current_sha256':digest((root/path).read_bytes())})
    assert all(r['sha256']==r['git_sha256']==r['current_sha256'] for r in checks)
    save(out/'input-hashes.json',checks)
    starts=Counter();finishes=Counter();observations={};sessions=[];origins=[];trace_hashes={}
    for path in sorted((run/'trace').glob('*.jsonl')):
        events=lines(path);trace_hashes[path.name]=digest(path.read_bytes())
        configured=[r for r in events if r['event']=='configure'];ended=[r for r in events if r['event']=='session_finish']
        origin_events=[r for r in events if r['event']=='product_origins']
        assert len(configured)==len(ended)==1 and configured[0]['optimization']==0
        assert configured[0]['source']==str(root) and ended[0]['exitstatus'] in (0,1)
        assert len(origin_events)==2 and {r['stage'] for r in origin_events}=={'configure','session_finish'}
        for event in origin_events:
            assert 'repo_catalog' in event['modules']
            for name,record in event['modules'].items():
                file=Path(record['path']).resolve();assert file.is_relative_to(root/'src')
                assert record['sha256']==inputs[str(file.relative_to(root))]
            origins.append({'worker':configured[0]['worker'],'stage':event['stage'],'module_count':len(event['modules'])})
        sessions.append({'file':path.name,'configured':configured[0],'ended':ended[0]})
        for event in events:
            node=event.get('nodeid')
            if event['event']=='start':starts[node]+=1
            if event['event']=='finish':finishes[node]+=1
            if node:observations.setdefault(node,[]).append(event)
    assert starts==finishes==Counter(actual.keys())
    rows=[]
    for node,result in sorted(actual.items()):
        observed=observations[node];stack=[]
        for event in observed:
            if event['event']=='admission_exception':
                for frame in event['stack']:
                    if frame['path'].startswith('src/'):
                        enriched=audit.sf(frame,commit=args.tested_head)
                        if enriched not in stack:stack.append(enriched)
        category,proof=audit.classify(independently_parsed[node],stack,commit=args.tested_head)
        static=audit.literal_assertions(node,args.tested_head)
        entered=sorted({event['line'] for event in observed if event['event']=='assertion_line' and event['phase']=='call' and event['path']==node.split('::')[0] and event['line'] in (static or [])})
        before=baseline[node];prior=before['actual_clean']
        rows.append({'nodeid':node,'historical79':before['historical79'],'new_diagnostic':result,'pr146_single_clean743':prior,'same_outcome_phase':(result['outcome'],result['phase'])==(prior['outcome'],prior['phase']),'classification':category,'prior_classification':before['classification'],'classification_source_proof':proof,'actual_admission_exception_frames':stack,'actual_admission_exception_event_count':sum(e['event']=='admission_exception' for e in observed),'static_literal_assertion_lines':static,'actual_local_assertion_lines_entered':entered,'pr146_actual_local_assertion_lines_entered':before['literal_assertion_lines_entered'],'same_local_assertion_entry_set':entered==before['literal_assertion_lines_entered'],'all_assertion_entry_events':[event for event in observed if event['event']=='assertion_line'],'actual_test_body_completed':result['outcome']=='passed','scope':'Actual statement entry covers main Python thread only; branch/subexpression/thread/child coverage not inferred.'})
    residual=[row for row in rows if row['pr146_single_clean743']['outcome']!='passed']
    assert len(residual)==299
    test_diff=subprocess.check_output(['git','diff','--name-status','274645e7dd451e24f324feb81b1591a64ba2a7ab',args.tested_head,'--','tests'],cwd=root,text=True).splitlines()
    summary={'scope':'One separate Task C diagnostic of original743. Counts remain separate. Attributed #146 audit/tracer helper; modified tracer additionally records typed stage codes.','tested_head':args.tested_head,'tested_tree':bindings[0]['tree'],'source_root':str(root),'tracked_status_before_after':[b['status'] for b in bindings],'full_status_before_after':[b.get('full_status_including_untracked') for b in bindings],'input_count':len(checks),'all_inputs_equal_recorded_frozen_git_current':True,'fixed_classifier_receipt':receipt,'attributed_second_parser_receipt':second_receipt,'trace_start_finish_node_multisets_exact':True,'trace_file_sha256':trace_hashes,'sessions':sessions,'in_pytest_origins':origins,'all743_classes':dict(Counter(r['classification'] for r in rows)),'inherited299_classes':dict(Counter(r['classification'] for r in residual)),'all743_same_outcome_phase_count':sum(r['same_outcome_phase'] for r in rows),'inherited299_same_outcome_phase_count':sum(r['same_outcome_phase'] for r in residual),'same_assertion_entry_set_count':sum(r['same_local_assertion_entry_set'] for r in rows),'inherited299_same_assertion_entry_set_count':sum(r['same_local_assertion_entry_set'] for r in residual),'actual_assertion_entry_nodes':sum(bool(r['actual_local_assertion_lines_entered']) for r in rows),'actual_resolved_passing_assertion_entry_nodes':sum(bool(r['actual_local_assertion_lines_entered']) for r in rows if r['classification']=='PASS'),'inherited299_actual_assertion_entry_nodes':sum(bool(r['actual_local_assertion_lines_entered']) for r in residual),'i7_nodes_with_current_caught_admission_frames':sum(r['classification']=='I7-composition' and bool(r['actual_admission_exception_frames']) for r in residual),'classification_differences':[r['nodeid'] for r in rows if r['classification']!=r['prior_classification']],'outcome_phase_differences':[r['nodeid'] for r in rows if not r['same_outcome_phase']],'assertion_entry_set_differences':[r['nodeid'] for r in rows if not r['same_local_assertion_entry_set']],'unresolved_nodes':[r['nodeid'] for r in rows if r['classification'].startswith('UNRESOLVED')],'test_diff_since_pr146':test_diff,'preexisting_test_files_unchanged':all(line.startswith('A\t') for line in test_diff),'analysis_script_sha256':digest(Path(__file__).read_bytes()),'attributed_audit_helper_sha256':digest((review/'audit.py').read_bytes()),'tracer_sha256':digest(Path('/workspace/task-c/tools/reviewer_trace.py').read_bytes()),'sidecar_plugin_sha256':digest(Path('/workspace/task-c/tools/i6a_report_types.py').read_bytes())}
    save(out/'node-comparison.json.gz',rows);save(out/'inherited299-comparison.json.gz',residual);save(out/'summary.json',summary)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
