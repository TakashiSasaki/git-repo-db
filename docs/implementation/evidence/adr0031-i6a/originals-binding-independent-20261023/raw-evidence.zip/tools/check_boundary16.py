"""Bind each moved refusal to actual typed raises, phase and assertion entry."""
from pathlib import Path
import gzip,json
ROOT=Path('/workspace/task-c/raw');d=ROOT/'diagnostic-analysis'
changes=json.loads((d/'first-boundary-changes.json').read_text())['rows'];assert len(changes)==16
rows={r['nodeid']:r for r in json.loads(gzip.decompress((d/'node-comparison.json.gz').read_bytes()))}
events={}
for p in (ROOT/'diagnostic743/trace').glob('*.jsonl'):
 for line in p.read_text().splitlines():
  e=json.loads(line)
  if e['event']=='admission_exception':events.setdefault(e['nodeid'],[]).append(e)
proof=[]
for change in changes:
 n=change['nodeid'];r=rows[n]
 typed=[e for e in events[n] if e.get('code')=='I2_TRANSFER_UNSUPPORTED' and e['exception_type']=='repo_catalog.domain.resource_stage.UnsupportedResourceStage' and any(f['path']=='src/repo_catalog/adapters/sqlite/context_admission.py' and f['function']=='call' for f in e['stack'])]
 assert typed and r['same_outcome_phase'] and r['same_local_assertion_entry_set']
 assert r['new_diagnostic']['phase']=='call' and r['new_diagnostic']['outcome']=='failed'
 proof.append({'nodeid':n,'reason':'I2_TRANSFER_UNSUPPORTED','exception_type':typed[0]['exception_type'],'phase':r['new_diagnostic']['phase'],'same_outcome_phase':True,'before_assertion_lines':r['pr146_actual_local_assertion_lines_entered'],'after_assertion_lines':r['actual_local_assertion_lines_entered'],'old_boundary':change['before_first_semantic_boundary'],'new_boundary':change['after_first_semantic_boundary'],'caught_raise_stack':typed[0]['stack'],'safety_controls':'normal schema/fence controls, full-rowset malformed/denied intake and commit/rollback observations execute separately in source and both installed forms; later statements in this failed test stay unproved'})
(ROOT/'boundary16-proof.json').write_text(json.dumps({'count':16,'proof':proof},indent=2)+'\n');print('16 typed code/phase/assertion-entry comparisons verified')
