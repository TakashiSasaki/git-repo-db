"""Package new review receipts, excluding scratch catalogs and referenced baselines."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('/workspace/task-c');RAW=ROOT/'raw';PUB=ROOT/'publication'
excluded={'basetemp','author-selected','pr146-one-run','__pycache__'}
rows={}
with zipfile.ZipFile(PUB/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(RAW.rglob('*')):
  rel=p.relative_to(RAW)
  if not p.is_file() or p.is_symlink() or set(rel.parts)&excluded or p.suffix=='.pyc':continue
  data=p.read_bytes();name='raw/'+rel.as_posix();z.writestr(name,data);rows[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 tools=['run_full.py','run_diagnostic.py','reviewer_trace.py','i6a_report_types.py','independent_receipt.py','compare_full.py','run_source_extra.py','reviewer_policy.py','test_task_c_originals.py','run_installed.py','audit_installed.py','check_bindings.py','test_task_c_foreign.py','run_foreign.py','audit_foreign.py','analyze_task_a_diagnostic.py','analyze_task_a_boundaries.py','check_boundary16.py','run_baseline_bound.py','run_baseline_bound_final.py','package_review.py']
 for name in tools:
  data=(ROOT/'tools'/name).read_bytes();member='tools/'+name;z.writestr(member,data);rows[member]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(PUB/'raw-index.json').write_text(json.dumps({'scope':'New Task C receipts and helpers; excludes temporary catalogs, binaries, venvs, wheelhouse, redundant copied historical receipts and symlink aliases. Referenced parent evidence remains immutable.','members':rows},indent=2)+'\n')
payloads={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(PUB.iterdir()) if p.is_file() and p.name!='artifact-index.json'}
(PUB/'artifact-index.json').write_text(json.dumps({'reviewed_head':'268025f67841285d105737b5a0d7bd15b1a6f59c','reviewed_tree':'e5fa0437f19f31fa414d488ec10f483ef68f03fa','payloads':payloads},indent=2)+'\n')
print(json.dumps({'raw_members':len(rows),'raw_zip_bytes':(PUB/'raw-evidence.zip').stat().st_size,'payloads':len(payloads)}))
