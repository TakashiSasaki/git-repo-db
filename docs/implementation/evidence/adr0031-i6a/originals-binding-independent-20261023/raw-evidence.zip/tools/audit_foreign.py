from pathlib import Path
from collections import Counter
import json,xml.etree.ElementTree as ET
from independent_receipt import key
OUT=Path('/workspace/task-c/raw/foreign-controls');summary={}
for form in ['source','direct','sdist']:
 d=OUT/form;nodes=(d/'ordinary.selected.txt').read_text().splitlines();km={key(n):n for n in nodes}
 assert len(nodes)==len(km)==4
 cases=list(ET.parse(d/'ordinary.xml').iter('testcase'));assert len(cases)==4
 assert Counter(km[c.get('classname'),c.get('name')] for c in cases)==Counter(nodes)
 assert all(c.find('error') is None and c.find('failure') is None and c.find('skipped') is None for c in cases)
 events=[json.loads(x) for x in (d/'ordinary.jsonl').read_text().splitlines()];typed=[json.loads(x) for x in (d/'ordinary.report-types.jsonl').read_text().splitlines()]
 assert Counter(x['nodeid'] for x in events if x['event']=='start')==Counter(nodes)
 assert Counter((x['nodeid'],x['phase'],x['outcome']) for x in typed)==Counter((n,p,'passed') for n in nodes for p in ['setup','call','teardown'])
 assert json.loads((d/'ordinary.execution.json').read_text())['exit_code']==0
 obs=list((d/'observations').glob('*.json'));assert len(obs)==4
 for p in obs:
  r=json.loads(p.read_text());assert r['actual']=='PERMISSION_DENIED' and r['foreign_policy_calls']==0 and r['before']==r['after'] and r['active_leases']==0 and not r['transaction_open']
 if form!='source':
  imports=json.loads((d/'imports.json').read_text());assert len(imports)==4
  assert all('/site-packages/repo_catalog' in r['origin'] and '/'+form+'-venv/' in r['origin'] for r in imports)
 summary[form]={'passed':4,'exact_nodes_and_phases':True,'zero_foreign_allow_all_policy_calls':True,'unchanged_full_rowsets':True,'installed_in_pytest_import_checks':0 if form=='source' else 4}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
