"""Task C independent installed evidence and artifact audit."""
from pathlib import Path
from collections import Counter
import base64,csv,gzip,hashlib,io,json,sys,tarfile,xml.etree.ElementTree as ET,zipfile
from independent_receipt import key
ROOT=Path('/workspace/git-repo-db');OUT=Path('/workspace/task-c/raw/installed-v3')
def load(p):return json.loads(Path(p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
b=load(OUT/'build-binding.json');members=[]
for form in ['direct-wheel','sdist-wheel']:
 p=Path(b[form]['path']);raw=p.read_bytes();assert sha(raw)==b[form]['sha256'] and len(raw)==b[form]['bytes']
 z=zipfile.ZipFile(io.BytesIO(raw));names=z.namelist();assert len(names)==len(set(names));files={n:z.read(n) for n in names}
 rec=next(n for n in names if n.endswith('.dist-info/RECORD'))
 rr=list(csv.reader(io.StringIO(files[rec].decode())));assert Counter(x[0] for x in rr)==Counter(names)
 for n,d,size in rr:
  if n==rec:assert d==size==''
  else:assert d=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(files[n]).digest()).decode().rstrip('=') and int(size)==len(files[n])
 members.append(files)
assert members[0]==members[1]
product={n.removeprefix('repo_catalog/'):sha(v) for n,v in members[0].items() if n.startswith('repo_catalog/')};assert len(product)==158
assert product=={str(p.relative_to(ROOT/'src/repo_catalog')):sha(p.read_bytes()) for p in (ROOT/'src/repo_catalog').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
summary={'reviewed_head':'268025f67841285d105737b5a0d7bd15b1a6f59c','reviewed_tree':'e5fa0437f19f31fa414d488ec10f483ef68f03fa','artifacts':b,'all_wheel_members_equal':True,'all_record_entries_verified':True,'product_file_count':len(product),'forms':{}}
allnodes={}
for form in ['direct','sdist']:
 runtime=[load(OUT/f'{form}-runtime-{which}.json') for which in ['before','after']]
 assert runtime[0]==runtime[1]
 rt=runtime[0];assert rt['installed_files']==product and rt['schema_matches_expected']
 assert rt['foreign_key_check']==[] and rt['integrity_check']==[['ok']]
 assert Path(rt['origin']).is_relative_to(Path(rt['prefix'])) and 'site-packages' in Path(rt['origin']).parts
 summary['forms'][form]={'sqlite':rt['sqlite'],'python':rt['python'],'prefix':rt['prefix'],'origin':rt['origin'],'fingerprint':rt['fingerprint'],'fences':rt['fences'],'runtime_before_after_equal':True,'lanes':{}}
 for lane,count in [('safety',626),('authorization',27),('task-c',132)]:
  label=form+'-'+lane;nodes=(OUT/(label+'-selected.txt')).read_text().splitlines();km={key(n):n for n in nodes};assert len(nodes)==len(set(nodes))==len(km)==count
  junit=[]
  for c in ET.parse(OUT/(label+'.xml')).iter('testcase'):
   assert c.find('failure') is None and c.find('error') is None and c.find('skipped') is None
   junit.append(km[c.get('classname'),c.get('name')])
  ev=[json.loads(x) for x in (OUT/(label+'.jsonl')).read_text().splitlines()]
  typed=[json.loads(x) for x in (OUT/(label+'-report-types.jsonl')).read_text().splitlines()]
  assert all(x.get('subtest_context') is None and x['outcome']=='passed' for x in typed)
  assert Counter(nodes)==Counter(junit)==Counter(x['nodeid'] for x in ev if x['event']=='start')
  assert Counter((x['nodeid'],x['phase']) for x in typed)==Counter((n,p) for n in nodes for p in ['setup','call','teardown'])
  pk=lambda x:(x['nodeid'],x['phase'],x['outcome'],round(x['duration'],6))
  assert Counter(map(pk,typed))==Counter(pk(x) for x in ev if x['event']=='phase')
  finish=[x for x in ev if x['event']=='finish'];assert len(finish)==1 and finish[0]['exitstatus']==0 and load(OUT/(label+'-execution.json'))['exit_code']==0
  im=load(OUT/(label+'-imports.json'));assert len(im)==4
  for record in im:
   assert record['installed_files']==product and record['prefix']==rt['prefix'] and record['origin']==rt['origin']
   assert record['context_schema_exact'] and record['sqlite']==rt['sqlite'] and record['fences']==rt['fences']
   assert all(Path(p).is_relative_to(Path(rt['origin'])) for p in record['product_modules'].values())
  allnodes[form,lane]=nodes
  summary['forms'][form]['lanes'][lane]={'selected':count,'passed':count,'exit':0,'selected_junit_journal_and_typed_phase_multisets_exact':True,'in_pytest_import_checks':len(im)}
  if lane=='safety':
   hist=gzip.decompress((ROOT/'docs/implementation/evidence/adr0031-i6a/author/distribution-v3/direct-selected.txt.gz').read_bytes()).decode().splitlines();hist=[n for n in hist if n.startswith('tests/') and '::' in n]
   assert len(hist)==551 and set(hist)<=set(nodes)
   cohorts={cohort:len([n for n in nodes if n.startswith(prefix)]) for cohort,prefix in [('i4','tests/integration/p3/test_transfer_sql.py::'),('i5','tests/integration/p3/test_transfer_admission.py::'),('new_originals','tests/integration/i6a/test_originals_revalidation.py::')]}
   assert cohorts=={'i4':217,'i5':29,'new_originals':75}
   summary['forms'][form]['lanes'][lane]['cohorts']=cohorts
 for probe in ['probe_originals','probe_invalid_carrier']:
  result=load(OUT/f'{form}-{probe}.json');imports=load(OUT/f'{form}-{probe}-imports.json')
  assert imports['origin']==rt['origin'] and imports['artifact_files']==product
  if probe=='probe_originals':assert result['failed']==0 and result['passed']==19
  else:assert result['invalid_original_refusals']==4 and result['normal_fence_controls']==2
  summary['forms'][form][probe]={k:v for k,v in result.items() if k!='observations' and k!='results'}
for lane in ['safety','authorization','task-c']:assert allnodes['direct',lane]==allnodes['sdist',lane]
source_manifest=load(OUT/'complete-build-source-manifest.json');sdist_manifest=load(OUT/'complete-sdist-member-manifest.json')
assert len(source_manifest['files'])==len({r['path'] for r in source_manifest['files']})
# Verify every measured build-source entry against frozen Git, without assuming a count.
import subprocess
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',summary['reviewed_head']],cwd=ROOT,text=True).splitlines()
assert set(tracked)=={r['path'] for r in source_manifest['files']}
for row in source_manifest['files']:
 assert sha(subprocess.check_output(['git','show',summary['reviewed_head']+':'+row['path']],cwd=ROOT))==row['sha256']
frozen=ROOT/'docs/implementation/evidence/adr0031-i6a/originals-binding-remediation-20261023/raw-evidence.zip'
with zipfile.ZipFile(frozen) as z:
 oldsource=json.loads(z.read('installed-v2/complete-build-source-manifest.json'));oldsdist=json.loads(z.read('installed-v2/complete-sdist-member-manifest.json'))
old={x['path']:x for x in oldsdist};new={x['path']:x for x in sdist_manifest}
summary['full_archive_comparison']={'current_source_entries':len(source_manifest['files']),'current_sdist_entries':len(sdist_manifest),'author_source_entries':len(oldsource['files']),'author_sdist_entries':len(oldsdist),'added_sdist_members':sorted(set(new)-set(old)),'removed_sdist_members':sorted(set(old)-set(new)),'changed_sdist_members':[n for n in old if n in new and old[n]!=new[n]],'full_archive_equal':oldsdist==sdist_manifest,'full_archive_difference_is_not_runtime_input_drift':True}
assert not summary['full_archive_comparison']['full_archive_equal']
(OUT/'independent-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'forms':{f:summary['forms'][f]['lanes'] for f in ['direct','sdist']},'archive_comparison':summary['full_archive_comparison']},indent=2))
