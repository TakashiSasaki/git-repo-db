"""Compare separately provenance-bound invocations with Task C's own parser."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,zipfile
from independent_receipt import audit
ROOT=Path('/workspace/git-repo-db');OUT=Path('/workspace/task-c/raw');BASE=ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-independent'
current,cm,cs=audit(OUT/'full');author,am,aus=audit(OUT/'author-selected/full')
assert current==author
old=OUT/'pr146-one-run';old.mkdir()
z=zipfile.ZipFile(BASE/'raw-local-evidence.zip');index=json.loads(z.read('receipt-index.json'))
for name in ['ordinary.selected.txt','ordinary.xml','ordinary.jsonl','ordinary.report-types.jsonl','ordinary.execution.json','binding-before.json','binding-after.json']:
 n='source-run/'+name;b=z.read(n);assert hashlib.sha256(b).hexdigest()==index[n]['sha256'] and len(b)==index[n]['bytes'];(old/name).write_bytes(b)
prior,pm,ps=audit(old)
latest_rows=json.loads(gzip.decompress((BASE/'failure-audit/full-latest-node-map.json.gz').read_bytes()))
latest={r['nodeid']:(r['latest']['outcome'],r['latest']['phase']) for r in latest_rows}
assert set(prior)==set(latest)
added=sorted(set(current)-set(prior));removed=sorted(set(prior)-set(current))
rawdiff=[{'nodeid':n,'old':prior[n],'current':current[n],'old_message':pm.get(n),'current_message':cm.get(n)} for n in prior if prior[n]!=current[n]]
latestdiff=[n for n in latest if latest[n]!=current[n]]
assert len(added)==102 and not removed and all(current[n]==('passed',None) for n in added)
summary={'single_task_c_invocation':cs,'separate_author_invocation':aus,'exact_outcomes_phases_equal_author':True,'pr146_single_raw_invocation':ps,'pr146_combined_latest_counts':dict(Counter(x[0] for x in latest.values())),'raw_outcome_phase_difference_count':len(rawdiff),'versus_combined_latest_outcome_phase_differences':latestdiff,'new_nodes':added,'all_new_nodes_pass':True,'removed_nodes':removed,'old_ids_preserved':len(prior),'method':'Independent stdlib parser; each actual invocation remains separate. No aggregation of reruns.'}
(OUT/'full-comparison.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'full-raw-differences.json').write_text(json.dumps(rawdiff,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['new_nodes']},indent=2))
