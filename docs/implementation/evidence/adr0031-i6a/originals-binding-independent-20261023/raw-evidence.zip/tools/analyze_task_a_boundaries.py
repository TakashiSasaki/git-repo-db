"""Distinguish real first-boundary changes from source line movement."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path('/workspace/git-repo-db')
OUT=Path('/workspace/task-c/raw/diagnostic-analysis')
prior_path=ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-independent/failure-audit/clean743.json.gz'
new_path=OUT/'node-comparison.json.gz'
prior={r['nodeid']:r for r in json.loads(gzip.decompress(prior_path.read_bytes()))}
current=json.loads(gzip.decompress(new_path.read_bytes()))

def identity(frame):
    if frame is None:return None
    return (frame['path'],frame.get('enclosing') or frame.get('function'),frame.get('source','').strip(), bool(frame.get('actual_failed_sql_call')))

rows=[]
for row in current:
    before=prior[row['nodeid']].get('first_semantic_boundary')
    after=next((f for f in row['classification_source_proof'] if f.get('actual_failed_sql_call') or 'raise AdmissionRefused' in f.get('source','') or 'raise UnsupportedResourceStage' in f.get('source','')),None)
    if identity(before)!=identity(after):
        rows.append({'nodeid':row['nodeid'],'classification':row['classification'],'before_first_semantic_boundary':before,'after_first_semantic_boundary':after,'reason':'The existing ordinary Transfer fence now raises in the admission wrapper after authorization/selection/current originals validation and before dependency lookup, rather than later in the Store. Both Python and SQL fences remain. The category/outcome/phase and actual assertion entry sets stay unchanged.' if row['classification']=='Transfer-stage' and after and after['path'].endswith('/context_admission.py') else 'Requires specific review; no equivalence is inferred from counts.'})
summary={'scope':'Actual743 diagnostic first semantic boundary comparison to #146 clean743. Ignore mere line-number movement but retain exact old/new coordinates and source.','changed_first_semantic_boundary_count':len(rows),'changed_classes':dict(Counter(r['classification'] for r in rows)),'rows':rows,'predecessor_inputs_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (prior_path,new_path)},'analysis_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'first-boundary-changes.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['changed_first_semantic_boundary_count','changed_classes']},indent=2))
