"""Fresh known-bad #146 saved counterexample with actual module-source binding."""
from pathlib import Path
import hashlib,json,runpy,sys
BASE=Path('/workspace/task-c/pr146-baseline-source');ROOT=Path('/workspace/git-repo-db');OUT=Path('/workspace/task-c/raw/pr146-bound-final');OUT.mkdir()
sys.path[:0]=[str(BASE/'src'),str(BASE)]
import repo_catalog
assert Path(repo_catalog.__file__).is_relative_to(BASE/'src')
probe=ROOT/'docs/implementation/evidence/adr0031-i6a/remediation-independent/originals/probe_invalid_carrier.py'
sys.path.insert(0,str(probe.parent));sys.argv=[str(probe),str(OUT/'pr146-saved-counterexample-bound.json')]
try:runpy.run_path(str(probe),run_name='__main__')
finally:
 modules={n:{'path':str(Path(m.__file__).resolve()),'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for n,m in sys.modules.items() if (n=='repo_catalog' or n.startswith('repo_catalog.')) and getattr(m,'__file__',None)}
 assert all(Path(r['path']).is_relative_to(BASE/'src') for r in modules.values())
 (OUT/'pr146-saved-counterexample-imports.json').write_text(json.dumps({'baseline':'274645e7dd451e24f324feb81b1591a64ba2a7ab','modules':modules},indent=2)+'\n')
