"""Task C four explicit foreign allow-all vectors, source and both installed forms."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/workspace/git-repo-db');TOOLS=Path(__file__).parent;WORK=Path('/workspace/task-c/installed-work-v3');OUT=Path('/workspace/task-c/raw/foreign-controls');OUT.mkdir()
shutil.copy2(TOOLS/'test_task_c_foreign.py',WORK/'outside/tests/review_task_c/test_task_c_foreign.py')
records=[]
def run(name,args,cwd,env):
 t=time.time()
 with (OUT/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':list(map(str,args)),'cwd':str(cwd),'exit_code':r.returncode,'elapsed_seconds':time.time()-t};records.append(row);(OUT/'processes.json').write_text(json.dumps(records,indent=2)+'\n');return row
for form in ['source','direct','sdist']:
 d=OUT/form;d.mkdir();python=Path(sys.executable) if form=='source' else WORK/(form+'-venv/bin/python');cwd=TOOLS if form=='source' else WORK/'outside'
 env=dict(os.environ,PATH=str(python.parent)+os.pathsep+os.environ['PATH'],PYTHONPATH=(str(ROOT/'src')+':'+str(ROOT)+':'+str(TOOLS)+':' if form=='source' else '')+str(ROOT/'tests/support/network_guard'),UV_CACHE_DIR='/workspace/task-c/cache',TASK_C_OBSERVATIONS=str(d/'observations'),REPO_CATALOG_IMPORT_RECEIPT=str(d/'imports.json'))
 for k in ['GH_TOKEN','GITHUB_TOKEN','PYTHONHOME']:env.pop(k,None)
 config=ROOT/'pyproject.toml' if form=='source' else cwd/'pytest.ini';target='test_task_c_foreign.py' if form=='source' else 'tests/review_task_c/test_task_c_foreign.py'
 args=[python,'-m','pytest','-q','-c',config,'--rootdir='+str(cwd),'--confcutdir='+str(cwd),'-o','addopts=','-o','junit_family=xunit1','-p','i6a_report_types',*(['-p','scripts.ci_journal'] if form=='source' else []),target]
 env['I6A_REPORTS_SIDECAR']=str(d/'collect-types.jsonl');r=run(form+'-collect',args+['--collect-only'],cwd,env);assert r['exit_code']==0
 nodes=[line for line in (OUT/(form+'-collect.log')).read_text().splitlines() if '.py::' in line and not line.startswith((' ','=','<'))];assert len(nodes)==len(set(nodes))==4
 (d/'ordinary.selected.txt').write_text('\n'.join(nodes)+'\n');env['I6A_REPORTS_SIDECAR']=str(d/'ordinary.report-types.jsonl')
 r=run(form,args+['--junitxml='+str(d/'ordinary.xml'),'--journal='+str(d/'ordinary.jsonl'),'--basetemp='+str(d/'basetemp')],cwd,env);(d/'ordinary.execution.json').write_text(json.dumps(r,indent=2)+'\n')
 assert r['exit_code']==0
raise SystemExit(0)
