"""Foreign allow-all issuer is never authority for the bound Store/facade."""
from contextlib import contextmanager
from pathlib import Path
import json,os
import pytest
from reviewer_policy import boundary,issue,write
from repo_catalog.adapters.sqlite.production_context import Context
from repo_catalog.domain.context_admission import AdmissionRefused,ContextAdmissionService

class ForeignAllowAll:
 def __init__(self):self.calls=0
 @contextmanager
 def lease(self,principal,operation,deps):
  self.calls+=1
  class Lease:
   def check_current(self):pass
  yield Lease()

def rows(db):
 return {n:sorted(db.execute('SELECT * FROM "'+n+'"').fetchall(),key=repr) for n, in db.execute("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name").fetchall()}

@pytest.mark.parametrize('route',['store','facade'])
@pytest.mark.parametrize('replay',[False,True])
def test_foreign_allow_all_handle_refused_before_any_policy_or_content(boundary,tmp_path,route,replay):
 db,store,service,policy,r=boundary
 if replay:assert write(store,issue(service),r)=='insert'
 grants=policy.grants;calls=len(policy.calls);before=rows(db);trace=[]
 principal=issue(service).principal;foreign_policy=ForeignAllowAll()
 foreign=ContextAdmissionService(foreign_policy,lambda _:principal)
 context=issue(foreign)
 try:
  with pytest.raises(AdmissionRefused) as caught:
   if route=='store':
    db.set_trace_callback(trace.append);write(store,context,r)
   else:
    with Context.owned_transaction(db,tmp_path,authorization=service,admission=context) as facade:
     db.set_trace_callback(trace.append);facade.admit_transfer_event(r,admission=context)
 finally:db.set_trace_callback(None)
 assert caught.value.code=='PERMISSION_DENIED'
 assert foreign_policy.calls==0 and len(policy.calls)==calls
 assert rows(db)==before and policy.grants==grants and policy.active==0 and not db.in_transaction
 assert not any(sql.lower().startswith(('select','insert','update','delete','replace')) for sql in trace)
 p=Path(os.environ['TASK_C_OBSERVATIONS']);p.mkdir(exist_ok=True)
 (p/f'foreign-{route}-{replay}.json').write_text(json.dumps({'expected':'PERMISSION_DENIED','actual':caught.value.code,'foreign_policy_calls':foreign_policy.calls,'trace':trace,'before':before,'after':rows(db),'transaction_open':db.in_transaction,'active_leases':policy.active},indent=2)+'\n')
