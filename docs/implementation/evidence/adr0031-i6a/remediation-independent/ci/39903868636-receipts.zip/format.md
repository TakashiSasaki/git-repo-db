### format: 0.16s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `f4ed9cb6b22fbd8305379fe534153a035d4ec45f`, tree `7072f952975a8537f74ced1bbc2a4a31d7aa3690`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `format-1792731966-4441fb7c`. Dirty tree: `False`.
Command wall time: 0.16s; Cumulative test duration: 0.16s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
