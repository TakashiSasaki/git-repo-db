from pathlib import Path
import json

def pytest_sessionstart(session):
    import repo_catalog
    import repo_catalog.adapters.sqlite.recovery_validation as validator
    expected=Path('/workspace/i4-independent/final-source/src').resolve()
    origins={'module':repo_catalog.__file__,'validator':validator.__file__,'config':str(session.config.inipath),'root':str(session.config.rootpath)}
    Path('/workspace/i4-independent/pytest-final-binding.json').write_text(json.dumps(origins,indent=2)+'\n')
    assert Path(validator.__file__).resolve().is_relative_to(expected), origins
    assert hasattr(validator,'StoredContextInvariantError'), origins
