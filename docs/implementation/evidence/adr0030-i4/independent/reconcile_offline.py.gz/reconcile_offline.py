from pathlib import Path
import base64,re,gzip,hashlib,json,io,zipfile,subprocess
p=Path('/workspace/git-repo-db/docs/implementation/evidence/adr0030-i4/raw'); sha=lambda b:hashlib.sha256(b).hexdigest()
s=gzip.decompress((p/'offline-job.log.gz').read_bytes()).decode()
begin=re.findall(r'^.*?Z CI_RECEIPTS_BEGIN_V1 ([0-9a-f]+) (\d+)$',s,re.M)
end=re.findall(r'^.*?Z CI_RECEIPTS_END_V1 ([0-9a-f]+)$',s,re.M)
parts=re.findall(r'^.*?Z CI_RECEIPTS_DATA_V1 ([A-Za-z0-9+/=]+)$',s,re.M)
assert len(begin)==len(end)==1
raw=base64.b64decode(''.join(parts),validate=True)
assert len(raw)==int(begin[0][1]) and sha(raw)==begin[0][0]==end[0]
assert raw==(p/'offline-receipt.zip').read_bytes()
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 idx=json.loads(z.read('receipt-index.json'))
 for name,meta in idx.items():
  b=z.read(name); assert len(b)==meta['bytes'] and sha(b)==meta['sha256']
 for name in ('receipt-binding.json','receipt-index.json','validation-manifest.json'):
  assert z.read(name)==(p/('offline-'+name)).read_bytes()
 manifest=json.loads(z.read('validation-manifest.json')); binding=json.loads(z.read('receipt-binding.json'))
 assert manifest['acceptance_status']=='development_checks_passed' and manifest['full_acceptance'] is False and manifest['coverage']['executed']==0
 assert binding['feature_sha']=='f948cc6c764689154734f6386a10f97db6923e7a' and binding['tree']=='0dd55440469be7bb1a2d341ef9c2bc6419f631b0'
inputs=json.loads((p/'inputs.json').read_text()); tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',binding['feature_sha']],cwd='/workspace/git-repo-db',text=True).splitlines()
expected={x for x in tracked if x.startswith(('src/','tests/','scripts/','.github/')) or x in ('pyproject.toml','uv.lock','.python-version')}
assert expected==set(inputs)
result={'receipt_zip_bytes':len(raw),'receipt_zip_sha256':sha(raw),'members_verified':len(idx),'binding':binding,'acceptance_status':manifest['acceptance_status'],'full_acceptance':manifest['full_acceptance'],'executed':manifest['coverage']['executed'],'input_inventory_complete_for_declared_paths':len(expected)}
Path('/workspace/i4-independent/offline-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
