from pathlib import Path,PurePosixPath
import json,zipfile,hashlib,re,io,tarfile,gzip,collections,xml.etree.ElementTree as E,subprocess
base=Path('/workspace/i4-evidence/source-f948cc6'); repo=Path('/workspace/git-repo-db'); evidence=repo/'docs/implementation/evidence/adr0030-i4'; rawdir=evidence/'raw'
sha=lambda b:hashlib.sha256(b).hexdigest(); data=(base/'hosted-artifact.zip').read_bytes(); log=(base/'hosted-job.log').read_text()
assert len(data)==40096272 and sha(data)=='5b7efc6094cb9cd29e17d519db15aae8fb79909c9d27cecb8b769e6c84202ca8'
assert re.search(r'^.*Z Uploaded bytes 40096272$',log,re.M)
assert re.search(r'^.*Z SHA256 digest of uploaded artifact is '+sha(data)+r'$',log,re.M)
assert re.search(r'^.*Z Artifact access-registry-verification has been successfully uploaded! Final size is 40096272 bytes. Artifact ID is 12205115448$',log,re.M)
inputs=json.loads((rawdir/'inputs.json').read_text())
with zipfile.ZipFile(io.BytesIO(data)) as z:
 names=z.namelist(); assert len(names)==len(set(names))==10
 assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
 source=json.loads(z.read('source-revision.json')); assert source['effective_tree']=='0dd55440469be7bb1a2d341ef9c2bc6419f631b0'
 assert source['checked_out_commit']=='10a85addb66f95d2fdaf6fcee4bfb55a7478c676'
 remote_merge=json.loads(Path('/workspace/i4-independent/hosted-merge-github.json').read_text()); assert remote_merge['sha']==source['checked_out_commit'] and remote_merge['tree']['sha']==source['effective_tree']; assert {p['sha'] for p in remote_merge['parents']}=={'8519056d5b9484eb0cc4dcf9f693285b4e65518a','f948cc6c764689154734f6386a10f97db6923e7a'}
 with tarfile.open(fileobj=io.BytesIO(z.read('source.tar.gz')),mode='r:gz') as t:
  members=t.getmembers(); regular={x.name:x for x in members if x.isfile()}
  assert len({m.name for m in members})==len(members)
  assert all(not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
  for path,digest in inputs.items(): assert sha(t.extractfile(regular[path]).read())==digest,path
 selected=[x.strip() for x in z.read('collected.txt').decode().splitlines() if x.startswith('tests/') and '::' in x]
 junit=E.fromstring(z.read('tests.xml'));cases=junit.findall('.//testcase')
 executed=[c.attrib['classname'].replace('.','/')+'.py::'+c.attrib['name'] for c in cases]
 assert collections.Counter(selected)==collections.Counter(executed) and len(selected)==len(set(selected))==2329
 assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
 assert all(s.attrib[k]=='0' for s in junit.findall('.//testsuite') for k in ('failures','errors','skipped'))
 local=E.fromstring(gzip.decompress((rawdir/'tests.xml.gz').read_bytes()))
 localnodes=[c.attrib['classname'].replace('.','/')+'.py::'+c.attrib['name'] for c in local.findall('.//testcase')]
 assert collections.Counter(executed)==collections.Counter(localnodes)
 runtime=z.read('runtime.txt').decode(); assert runtime.strip() in log
 assert 'Python: 3.12.15 SQLite: 3.51.3 source: 2026-03-13 10:38:09 737ae4a34738ffa0c3ff7f9bb18df914dd1cad163f28fd6b6e114a344fe6d618' in runtime
 assert re.search(r'^.*Z 2329 passed in [0-9.]+s ',log,re.M)
 dist=json.loads(z.read('distribution.json')); assert {d['artifact_kind'] for d in dist}=={'wheel','sdist-wheel'}
 for d in dist:
  assert d['sqlite']=='3.51.3' and d['sqlite_source_id'] in runtime and '/site-packages/' in d['module_origin'] and d['table_count']==19 and d['installed_i4_query_search_backup']=='passed' and d['installed_smoke']=='passed'
 acceptance=json.loads(z.read('acceptance.json'));assert acceptance['executed_nodes']==2329 and acceptance['node_set_matched']
 pairs={'acceptance.json':'hosted-acceptance.json','collected.txt':'hosted-collected.txt','distribution.json':'hosted-distribution.json','source-revision.json':'hosted-source-revision.json','runtime.txt':'hosted-runtime.txt'}
 for zn,fn in pairs.items(): assert z.read(zn)==(rawdir/fn).read_bytes(),fn
 assert z.read('tests.xml')==gzip.decompress((rawdir/'hosted-tests.xml.gz').read_bytes())
index=json.loads((evidence/'index.json').read_text())
for path,meta in index.items():
 b=(evidence/path).read_bytes();assert len(b)==meta['bytes'] and sha(b)==meta['sha256'],path
 if path.endswith('.gz'):
  d=gzip.decompress(b);assert len(d)==meta['uncompressed_bytes'] and sha(d)==meta['uncompressed_sha256'],path
result={'run_id':39285853860,'job_id':118171487893,'artifact_id':12205115448,'artifact_bytes':len(data),'artifact_sha256':sha(data),'source_revision':source,'source_inputs_verified':len(inputs),'selected':len(selected),'executed':len(executed),'result':{'passed':2329,'failed':0,'errors':0,'skips':0},'runtime':runtime.strip(),'distribution_artifacts':len(dist),'same_local_hosted_node_counter':True,'evidence_index_entries':len(index),'evidence_index_sha256':sha((evidence/'index.json').read_bytes()),'metadata_note':'Queued API metadata remains separate from verified completed job log/artifact.','receipt_reconciliation_only':True}
Path('/workspace/i4-independent/hosted-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
