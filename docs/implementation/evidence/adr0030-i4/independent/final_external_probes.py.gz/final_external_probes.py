import json
import pytest
from repo_catalog.adapters.sqlite.production_context import Context
from repo_catalog.adapters.sqlite.p1_schema import connect
from repo_catalog.application.production_query import ProductionQueryService
from repo_catalog.application.acquisition import ProviderAcquisition
from repo_catalog.domain.acquisition import ProviderIntakeBatch
from repo_catalog.domain.p1_context import FieldClock,MappingDisposition,MappingOperationEvidence,ProviderRepositoryScope,ProviderRepositoryRoleScope,ResourceKey,canonical
from repo_catalog.domain.production_context import ResourceRelation
from repo_catalog.domain.production_query import SearchQuery,QueryError
from tests.integration.i23.test_provider_exchange import producer,provenance


def role(ctx,key,provider,clock,tag):
    scope=ProviderRepositoryScope({'owning_repository':ProviderRepositoryRoleScope('owning_repository',clock,'explicit_null' if provider is None else 'unresolved_provider_only',provider,observed_at_us=100)})
    ctx.relation(ResourceRelation(key,'provider_repository_roles',() if provider is None else (ResourceKey(key.service_instance_uuidv4,'repository',provider),),provenance(tag),scope.encoded,100))


def test_current_null_dominates_historical_target_and_does_not_inherit(tmp_path):
    service,r1,r2,_=producer(tmp_path)
    key=ResourceKey(service,'issue','901')
    q=ProductionQueryService(tmp_path)
    with Context.transaction(tmp_path) as c:
        c.resource(key)
        role(c,key,'1',FieldClock('provider',100),'mapped')
    assert q.get_context_resource(key).repository_uuidv4 == r1
    with Context.transaction(tmp_path) as c:
        role(c,key,None,FieldClock('provider',101),'new-null')
    view=q.get_context_resource(key)
    assert view.repository_uuidv4 is None
    assert not view.matches_repository(r1)
    assert all(x.state=='explicit_null' for x in view.repository_roles)
    assert key not in {x.resource for x in q.list_paired_resources(repository_uuidv4=r1).items}


def test_equal_clock_null_alternative_blocks_convenience_without_hiding_mapping(tmp_path):
    service,r1,_,_=producer(tmp_path)
    key=ResourceKey(service,'issue','10')
    q=ProductionQueryService(tmp_path)
    orig=q.get_context_resource(key).repository_roles[0]
    with Context.transaction(tmp_path) as c:
        role(c,key,None,orig.scope.clock,'equal-null')
    view=q.get_context_resource(key)
    assert len(view.repository_roles)==2
    assert view.repository_uuidv4 is None and view.matches_repository(r1)
    assert {x.state for x in view.repository_roles} == {'explicit_null','single_candidate'}


def test_count_preserving_index_key_forgery_falls_back(tmp_path):
    producer(tmp_path)
    q=ProductionQueryService(tmp_path)
    spec=SearchQuery('repository',projection_kinds=('context_text',))
    q.rebuild_search(('context_text',))
    before=q.search(spec)
    with connect(tmp_path/'search.sqlite3','search') as db:
        row=db.execute("SELECT document_key_json FROM search_documents WHERE projection_kind='context_text' ORDER BY document_key_json LIMIT 1").fetchone()
        db.execute("UPDATE search_documents SET document_key_json=? WHERE document_key_json=?",(canonical(['forged','identity']),row[0]))
    after=q.search(spec)
    assert after.hits==before.hits and after.backend=='authority_scan'
    assert not (tmp_path/'p1-recovery-stop.json').exists()


def test_disposition_qualification_summary_recomputed_when_index_text_unchanged(tmp_path):
    service,_,_,claims=producer(tmp_path)
    disp=MappingDisposition(claims[0].claim_key,'withdraw',FieldClock('review',20),provenance('review-withdraw'),21)
    ProviderAcquisition(tmp_path).admit_batch(ProviderIntakeBatch(service,mapping_dispositions=(disp,)))
    plain=ProductionQueryService(tmp_path)
    checked=ProductionQueryService(tmp_path,mapping_evidence=MappingOperationEvidence(contradicted_disposition_keys=frozenset({disp.disposition_key})))
    plain.rebuild_search(('context_text',))
    spec=SearchQuery('owning_repository',projection_kinds=('context_text',),limit=1)
    first=plain.search(spec)
    with pytest.raises(QueryError) as exc:
        checked.search(SearchQuery('owning_repository',projection_kinds=('context_text',),cursor=first.next_cursor,limit=1))
    assert exc.value.code=='INVALID_CURSOR'
    p=plain.get_context_resource(ResourceKey(service,'issue','10')).repository_roles[0]
    c=checked.get_context_resource(ResourceKey(service,'issue','10')).repository_roles[0]
    assert p.state=='contested_candidate' and c.state=='evidence_contradictory'
    hits=checked.search(SearchQuery('owning_repository',projection_kinds=('context_text',))).hits
    own=[x for x in hits if x.authoritative_summary.get('kind')=='current_provider_repository_role' and x.authoritative_summary['resource']==list(c.resource.coordinates())]
    assert own and own[0].authoritative_summary['state']=='evidence_contradictory'
