from pathlib import Path
import json,gzip,hashlib,subprocess,collections,xml.etree.ElementTree as E,zipfile,io
repo=Path('/workspace/git-repo-db'); evidence=repo/'docs/implementation/evidence/adr0030-i4'; raw=evidence/'raw'; fixed='f948cc6c764689154734f6386a10f97db6923e7a'
sha=lambda x:hashlib.sha256(x).hexdigest()
index=json.loads((evidence/'index.json').read_text())
for path,meta in index.items():
 data=(evidence/path).read_bytes(); assert len(data)==meta['bytes'] and sha(data)==meta['sha256'],path
 if path.endswith('.gz'):
  plain=gzip.decompress(data); assert len(plain)==meta['uncompressed_bytes'] and sha(plain)==meta['uncompressed_sha256'],path
unindexed=sorted(str(p.relative_to(evidence)) for p in evidence.rglob('*') if p.is_file() and str(p.relative_to(evidence)) not in index and p.name!='index.json')
inputs=json.loads((raw/'inputs.json').read_text()); source=json.loads((raw/'source.json').read_text()); assert len(inputs)==422
assert source['head']==fixed and source['tree']==subprocess.check_output(['git','rev-parse',fixed+'^{tree}'],cwd=repo,text=True).strip()
assert sha((raw/'inputs.json').read_bytes())==source['inputs_sha256']
for path,digest in inputs.items():
 committed=subprocess.check_output(['git','show',fixed+':'+path],cwd=repo)
 assert sha(committed)==digest,('commit',path)
 assert sha((repo/path).read_bytes())==digest,('worktree',path)
collection=gzip.decompress((raw/'collection.log.gz').read_bytes()).decode()
selected=[line.strip() for line in collection.splitlines() if line.startswith('tests/') and '::' in line]
root=E.fromstring(gzip.decompress((raw/'tests.xml.gz').read_bytes()))
cases=root.findall('.//testcase')
normalize=lambda c:c.attrib['classname'].replace('.','/')+'.py::'+c.attrib['name']
executed=[normalize(c) for c in cases]
assert collections.Counter(selected)==collections.Counter(executed)
assert len(selected)==len(set(selected))==2329
assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
assert all(s.attrib[k]=='0' for s in root.findall('.//testsuite') for k in ('errors','failures','skipped'))
summary=json.loads((raw/'summary.json').read_text()); assert summary['selected']==summary['executed']==len(cases) and summary['counts']=={'passed':2329}
cohorts=collections.Counter('unit' if n.startswith('tests/unit/') else n.split('/')[2] for n in executed)
assert dict(cohorts)=={k:v['passed'] for k,v in summary['cohorts'].items()}
assert '2329 passed, 4 warnings' in gzip.decompress((raw/'expanded.log.gz').read_bytes()).decode()
baseline=E.fromstring(gzip.decompress((raw/'p6-baseline.xml.gz').read_bytes()))
before={normalize(c):'failed' if c.find('failure') is not None else 'passed' for c in baseline.findall('.//testcase')}
after={normalize(c):'passed' for c in cases}
resolution=json.loads((raw/'p6-resolution.json').read_text())
assert len(before)==50 and collections.Counter(before.values())=={'failed':27,'passed':23}
assert {n for n,v in before.items() if v=='failed'}=={x['node'] for x in resolution['resolved_nodes']}
assert all(after.get(n)=='passed' for n in before)
assert len(resolution['original_p5_exchange'])==5 and all(after[x['node']]=='passed' for x in resolution['original_p5_exchange'])
assert all(x['exit']==0 for x in json.loads((raw/'commands.json').read_text()))
audits=json.loads((raw/'audits.json').read_text()); assert len(audits)==7 and all(x['exit']==0 for x in audits)
for audit in audits: assert (raw/(audit['log']+'.gz')).exists()
distribution=json.loads((raw/'distribution.json').read_text()); assert {x['artifact_kind'] for x in distribution}=={'wheel','sdist-wheel'}
assert all(x['sqlite']=='3.51.3' and x['installed_i4_query_search_backup']=='passed' and x['table_count']==19 and '/site-packages/' in x['module_origin'] for x in distribution)
zipdata=(raw/'offline-receipt.zip').read_bytes()
with zipfile.ZipFile(io.BytesIO(zipdata)) as z:
 names=z.namelist(); receipt_idx=json.loads(z.read('receipt-index.json'))
 print('ZIP INDEX TYPE',type(receipt_idx).__name__,len(receipt_idx))
result={'reviewed_source':source,'index_entries_verified':len(index),'unindexed_files_excluding_index':unindexed,'inputs_compared_to_commit_and_worktree':len(inputs),'selected':len(selected),'executed':len(executed),'cohorts':dict(cohorts),'counts':{'passed':len(cases),'failed':0,'error':0,'skip':0},'p6':{'original_nodes':50,'resolved':27},'original_p5_exchange_passed':5,'distribution_artifacts':2,'audits_successful':len(audits),'receipt_reconciliation_only':True,'evidence_index_sha256':sha((evidence/'index.json').read_bytes())}
Path('/workspace/i4-independent/evidence-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
