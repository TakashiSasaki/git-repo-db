### format: 0.12s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `10a85addb66f95d2fdaf6fcee4bfb55a7478c676`, tree `0dd55440469be7bb1a2d341ef9c2bc6419f631b0`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `format-1792427389-d026ae24`. Dirty tree: `False`.
Command wall time: 0.12s; Cumulative test duration: 0.12s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
