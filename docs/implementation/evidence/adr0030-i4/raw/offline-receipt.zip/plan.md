## Validation plan

Mode: `development`; Effective SHA `10a85addb66f95d2fdaf6fcee4bfb55a7478c676`; full acceptance selected: False.
Acceptance input hash: `2aec8f64124eeaef047f66bd79609121fd84d9a52d188fd63db620e266c690d8`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 198.
Selected test files: 0.
Unexecuted acceptance files: 198. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.345s.

### Scope reasons
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
