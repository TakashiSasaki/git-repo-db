### doctor: 0.12s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `e0c60765bd0d99b8276a8d0528dabfa7f4d6971a`, tree `5ea93707d62b542c84632515392ac6a35c36cd65`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `doctor-1792724041-d8742f98`. Dirty tree: `False`.
Command wall time: 0.12s; Cumulative test duration: 0.12s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
