## Validation plan

Mode: `development`; Effective SHA `e0c60765bd0d99b8276a8d0528dabfa7f4d6971a`; full acceptance selected: False.
Acceptance input hash: `8413e49bbfd35224c6c864680809a8956a2eda4f1324b04c3247e792b32ebdaf`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 213.
Selected test files: 0.
Unexecuted acceptance files: 213. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.103s.

### Scope reasons
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/baseline-comparison.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/measurements.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/pax-calibration.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/raw-evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/raw-evidence.zip
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/verification-summary.json
