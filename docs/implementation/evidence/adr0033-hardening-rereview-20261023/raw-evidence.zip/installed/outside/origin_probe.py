import hashlib,json,sys,sqlite3,zipfile
from pathlib import Path
import repo_catalog
p=Path(repo_catalog.__file__).resolve().parent
assert p.is_relative_to(Path(sys.prefix).resolve()) and 'site-packages' in p.parts,p
assert not any(Path(x).resolve().is_relative_to(Path('/workspace/adr0033-review')) for x in sys.path if x),sys.path
with zipfile.ZipFile(sys.argv[1]) as z:
 expected={n.removeprefix('repo_catalog/'):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('repo_catalog/')}
actual={str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in p.rglob('*') if x.is_file() and x.suffix in {'.py','.sql','.json','.graphql'}}
assert expected==actual
db=sqlite3.connect(':memory:')
Path(sys.argv[2]).write_text(json.dumps({'origin':str(p),'executable':sys.executable,'sys_path':sys.path,'product_hashes':actual,'sqlite':db.execute('select sqlite_version(),sqlite_source_id()').fetchone()},indent=2)+'\n')
