from pathlib import Path
import json,zipfile,io,hashlib
from scripts.compare_i5_failures import index,compare
w=Path('/workspace/sdist-work')
with zipfile.ZipFile(w/'hosted-access-receipts.zip') as z:
 receipt_index=json.loads(z.read('receipt-index.json'))
 for n,r in receipt_index.items():
  raw=z.read(n);assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'],n
 binding=json.loads(z.read('receipt-binding.json'))
 assert binding['tree']=='b5bdcb3cf5361a339ecdcea496c9ee32d1ab61ce'
 assert binding['run_id']=='39872269603'
 source=json.loads(z.read('artifacts/access-registry/source-revision.json'))
 assert source['effective_tree']==binding['tree']
 with zipfile.ZipFile(w/'parent133-payload.zip') as outer:
  with zipfile.ZipFile(io.BytesIO(outer.read('hosted-f16e5b1/access-receipts.zip'))) as old:
   cases={}
   for label,path in [('focused','artifacts/access-registry/tests.xml'),('broad','artifacts/access-registry/i5/regressions.xml')]:
    comp=compare(index(old.read(path)),index(z.read(path)))
    assert comp['same_nodes'] and comp['additional']==0 and comp['resolved']==0
    assert all(r['same_phase'] and r['same_stage_refusal'] and r['same_trace_paths_functions'] for r in comp['comparison'])
    cases[label]={k:v for k,v in comp.items() if k!='comparison'}
    (w/('hosted-'+label+'-failure-comparison.json')).write_text(json.dumps(comp,indent=2)+'\n')
 sdist={}
 for label,path in [('access','artifacts/access-registry/sdist-contract.json'),('i5','artifacts/access-registry/i5-distribution/sdist-contract.json')]:
  contract=json.loads(z.read(path));assert contract['status']=='passed' and contract['product_files']==155
  assert contract['sha256']=='c72f86709f360b306daa1d39e2854e910f773e6acfce9f4bec7dae3396012e21'
  assert contract['wheel_equivalence']['status']=='passed'
  sdist[label]={k:contract[k] for k in ('status','sha256','compressed_bytes','unpacked_bytes','member_count','product_files')}
 result={'run_id':binding['run_id'],'source_commit':'03e1192f5228c9a1ca40dcef88271419c6828874','binding':binding,'source_revision':source,'receipt_sha256':hashlib.sha256((w/'hosted-access-receipts.zip').read_bytes()).hexdigest(),'receipt_bytes':(w/'hosted-access-receipts.zip').stat().st_size,'indexed_members_verified':len(receipt_index),'status':'failure_inherited','failure_comparisons':cases,'sdist_contracts':sdist,'full_acceptance':False}
 (w/'hosted-access-verification.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
