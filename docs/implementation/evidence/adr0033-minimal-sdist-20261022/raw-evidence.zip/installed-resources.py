import hashlib,json,sys,sqlite3,subprocess,os,runpy
from pathlib import Path
from uuid import uuid4
runpy.run_path(sys.argv[2])
import repo_catalog
from repo_catalog.adapters.sqlite import p1_schema,access_schema
from repo_catalog.adapters.sqlite.json_contracts import guard_sql
root=Path(repo_catalog.__file__).resolve().parent
assert root.is_relative_to(Path(sys.prefix).resolve())
access_schema.require_runtime();p1_schema._open(":memory:",fresh=True).close()
p1_schema.verify_declared()
assert (root/"resources/json_contracts.sql").read_text()==guard_sql()
for store in p1_schema.STORES:
 path=Path(store+".sqlite3")
 p1_schema.initialize(path,store,str(uuid4()),str(uuid4()))
 with p1_schema.connect(path,store) as db:
  assert db.execute("PRAGMA integrity_check").fetchone()[0]=="ok"
  assert not db.execute("PRAGMA foreign_key_check").fetchall()
product={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file() and p.suffix in (".py",".sql",".json",".graphql")}
commands=[]
for argv in ([str(Path(sys.prefix)/"bin/repo-catalog"),"--format","json","doctor"],[sys.executable,"-m","repo_catalog","--help"]):
 r=subprocess.run(argv,capture_output=True,text=True)
 commands.append({"argv":argv,"exit_code":r.returncode,"stdout":r.stdout,"stderr":r.stderr})
 assert r.returncode==0,r.stderr
with sqlite3.connect(":memory:") as db:
 runtime={"version":sqlite3.sqlite_version,"source_id":db.execute("SELECT sqlite_source_id()").fetchone()[0],"compile_options":db.execute("PRAGMA compile_options").fetchall()}
Path(sys.argv[1]).write_text(json.dumps({"python":sys.version,"executable":sys.executable,"module_origin":str(root),"sqlite":runtime,"product_files":product,"ddl_manifest":p1_schema.expected_ddl_manifest(),"json_guard_equal":True,"all_store_integrity":True,"commands":commands},indent=2)+"\n")
