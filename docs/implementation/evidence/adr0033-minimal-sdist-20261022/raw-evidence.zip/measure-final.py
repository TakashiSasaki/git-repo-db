import hashlib,json,tarfile,collections,subprocess,sys,os,zipfile
from pathlib import Path
sys.path.insert(0,'/workspace/git-repo-db')
from scripts.check_sdist_contract import compare_wheels,source_inventory
work=Path('/workspace/sdist-work');repo=Path('/workspace/git-repo-db')
old=next((work/'before-dist').glob('*.tar.gz'))
entries=[]
with tarfile.open(old) as tar:
 for m in tar:
  entries.append({'name':m.name,'bytes':m.size,'sha256':hashlib.sha256(tar.extractfile(m).read()).hexdigest() if m.isfile() else None})
breakdown=collections.Counter(e['name'].split('/')[1] if len(e['name'].split('/'))>1 else '.' for e in entries)
(work/'before-members.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'members':entries,'top_level_counts':dict(breakdown)},indent=2)+'\n')
contract=json.loads((work/'installed-i5/sdist-contract.json').read_text())
source=work/'installed-i5/source'
direct=next((source/'dist').glob('*.whl'))
derived=next((work/'installed-i5/from-sdist').glob('*/dist/*.whl'))
sdist=next((source/'dist').glob('*.tar.gz'))
previous=next((work/'before-dist').glob('*.whl'))
unchanged=compare_wheels(previous,direct)
assert source_inventory(work/'before')['src/repo_catalog/resources/json_contracts.sql']==contract['source_files']['src/repo_catalog/resources/json_contracts.sql']
subprocess.run(['uv','export','--locked','--no-dev','--no-emit-project','--format','requirements-txt','--output-file',str(work/'runtime-requirements.txt')],cwd=repo,check=True,capture_output=True)
probe=work/'installed-resources.py'
probe.write_text('''import hashlib,json,sys,sqlite3,subprocess,os,runpy
from pathlib import Path
from uuid import uuid4
runpy.run_path(sys.argv[2])
import repo_catalog
from repo_catalog.adapters.sqlite import p1_schema,access_schema
from repo_catalog.adapters.sqlite.json_contracts import guard_sql
root=Path(repo_catalog.__file__).resolve().parent
assert root.is_relative_to(Path(sys.prefix).resolve())
access_schema.require_runtime();p1_schema._open(":memory:",fresh=True).close()
p1_schema.verify_declared()
assert (root/"resources/json_contracts.sql").read_text()==guard_sql()
for store in p1_schema.STORES:
 path=Path(store+".sqlite3")
 p1_schema.initialize(path,store,str(uuid4()),str(uuid4()))
 with p1_schema.connect(path,store) as db:
  assert db.execute("PRAGMA integrity_check").fetchone()[0]=="ok"
  assert not db.execute("PRAGMA foreign_key_check").fetchall()
product={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file() and p.suffix in (".py",".sql",".json",".graphql")}
commands=[]
for argv in ([str(Path(sys.prefix)/"bin/repo-catalog"),"--format","json","doctor"],[sys.executable,"-m","repo_catalog","--help"]):
 r=subprocess.run(argv,capture_output=True,text=True)
 commands.append({"argv":argv,"exit_code":r.returncode,"stdout":r.stdout,"stderr":r.stderr})
 assert r.returncode==0,r.stderr
with sqlite3.connect(":memory:") as db:
 runtime={"version":sqlite3.sqlite_version,"source_id":db.execute("SELECT sqlite_source_id()").fetchone()[0],"compile_options":db.execute("PRAGMA compile_options").fetchall()}
Path(sys.argv[1]).write_text(json.dumps({"python":sys.version,"executable":sys.executable,"module_origin":str(root),"sqlite":runtime,"product_files":product,"ddl_manifest":p1_schema.expected_ddl_manifest(),"json_guard_equal":True,"all_store_integrity":True,"commands":commands},indent=2)+"\\n")
''')
from shutil import copyfile
outside=work/'cli-outside';outside.mkdir(exist_ok=True)
guard=outside/'network_guard';guard.mkdir(exist_ok=True)
copyfile(repo/'tests/support/network_guard/sitecustomize.py',guard/'sitecustomize.py')
results={}
for tag,wheel in [('direct',direct),('sdist',derived)]:
 envdir=work/('cli-'+tag+'-venv')
 subprocess.run(['uv','venv',str(envdir),'--python',sys.executable,'--offline'],check=True,capture_output=True)
 py=envdir/'bin/python'
 requirements=work/(tag+'-complete-requirements.txt')
 requirements.write_text((work/'runtime-requirements.txt').read_text()+f'\nrepo-catalog @ {wheel.as_uri()} --hash=sha256:{hashlib.sha256(wheel.read_bytes()).hexdigest()}\n')
 subprocess.run(['uv','pip','install','--python',str(py),'--offline','--no-index','--find-links',str(repo/'artifacts/wheelhouse'),'--require-hashes','-r',str(requirements)],check=True,capture_output=True)
 env=dict(os.environ,PYTHONPATH=str(guard),GIT_ALLOW_PROTOCOL='file',PATH=str(envdir/'bin')+os.pathsep+os.environ['PATH'])
 for key in ['GH_TOKEN','GITHUB_TOKEN','PYTHONHOME']:env.pop(key,None)
 cwd=outside/tag;cwd.mkdir(exist_ok=True)
 out=work/(tag+'-installed-resources.json')
 result=subprocess.run([str(py),'-I',str(probe),str(out),str(guard/'sitecustomize.py')],cwd=cwd,env=env,capture_output=True,text=True)
 (work/(tag+'-installed-resources.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0,(tag,result.stderr)
 measured=json.loads(out.read_text())
 expected={n.removeprefix('repo_catalog/'):item['sha256'] for n,item in contract['wheel_equivalence']['members'].items() if n.startswith('repo_catalog/')}
 assert measured['product_files']==expected
 results[tag]={'exit_code':0,'product_file_count':len(expected),'runtime':measured['sqlite'],'module_origin':measured['module_origin'],'python':measured['python']}
result={'execution_commit':'03e1192f5228c9a1ca40dcef88271419c6828874','execution_tree':'b5bdcb3cf5361a339ecdcea496c9ee32d1ab61ce','baseline_commit':'18ba867d1c2f33c7d17939b2722d22a67139363a','before':{'bytes':old.stat().st_size,'members':len(entries),'unpacked_bytes':sum(e['bytes'] for e in entries),'sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'top_level_counts':dict(breakdown)},'after':{k:v for k,v in contract.items() if k not in ['members','source_files','wheel_equivalence']},'reduction_percent':100*(1-sdist.stat().st_size/old.stat().st_size),'wheel_equivalence':{k:v for k,v in contract['wheel_equivalence'].items() if k!='members'},'before_after_wheel_contents_equal':unchanged['status']=='passed','installed':results}
(work/'measurements.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['installed','before','after']}))
