import importlib.util
import sys
from pathlib import Path

def pytest_collection_modifyitems(items):
    import scripts
    path = Path("/tmp/sdist-hardening/base/scripts/check_sdist_contract.py")
    spec = importlib.util.spec_from_file_location("scripts.check_sdist_contract", path)
    baseline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(baseline)
    sys.modules["scripts.check_sdist_contract"] = baseline
    scripts.check_sdist_contract = baseline
    for item in items:
        if item.module.__name__.endswith("test_sdist_hardening"):
            item.module.contract = baseline
            item.module.ROOT = path.parents[1]
