import collections,hashlib,json,xml.etree.ElementTree as ET
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd()))
from scripts import verify_i5_offline as v, compare_i5_failures as f
out=Path('/tmp/sdist-hardening'); ordinary=(out/'broad/ordinary-collection.nodes.txt').read_text().splitlines(); mapper={}
for node in ordinary:
 prefix,bracket,param=node.partition('[');parts=prefix.split('::');key=('.'.join([parts[0][:-3].replace('/','.'),*parts[1:-1]]),parts[-1]+bracket+param)
 assert key not in mapper;mapper[key]=node
executed=set();runs={}
for name in ('packaging','ci-focused','docs-tests'):
 xml=out/(name+'.xml');cases=ET.parse(xml).findall('.//testcase');nodes=[mapper[(c.get('classname'),c.get('name'))] for c in cases];executed.update(nodes)
 r={'outcomes':v.outcomes(xml),'reconciliation':v.reconciliation(nodes,xml,out/(name+'.jsonl'))};assert r['reconciliation']['consistent_node_execution'];runs[name]=r
executed.update((out/'broad/regressions.selected.txt').read_text().splitlines()); assert executed<=set(ordinary)
missing=sorted(set(ordinary)-executed);(out/'ordinary-not-executed-final.txt').write_text(''.join(n+'\n' for n in missing))
baseline=json.load(open(out/'baseline-comparison.json'));old={(x['class'],x['name']):x['baseline'] for x in baseline['comparison'] if x['class'].startswith('tests.packaging.')};p=f.compare(old,f.index((out/'packaging.xml').read_bytes()));(out/'packaging-baseline-comparison.json').write_text(json.dumps(p,indent=2)+'\n');assert p['same_nodes'] and all(x['same_phase'] and x['same_stage_refusal'] and x['same_trace_paths_functions'] for x in p['comparison'])
source=json.load(open(out/'broad/input-binding.json'));assert v.input_hashes()==source['inputs']
summary={'source_head':source['head'],'source_tree':source['tree'],'runtime_inputs_unchanged':True,'runtime_input_inventory_sha256':hashlib.sha256(json.dumps(source['inputs'],sort_keys=True).encode()).hexdigest(),'source_acceptance_input_hash':json.load(open(out/'author-plan.json'))['acceptance_input_hash'],'ordinary_collected':len(ordinary),'executed_unique_ordinary':len(executed),'unexecuted_ordinary':len(missing),'live_not_run':1,'benchmark_not_run':1,'runs':runs,'broad':json.load(open(out/'broad/summary.json')),'baseline_non_successes':79,'current_non_successes':79,'additional_non_successes':baseline['additional'],'resolved_non_successes':baseline['resolved'],'message_differences':sum(not x['same_message'] for x in baseline['comparison']),'independent_review_acceptance':'not performed','full_release_acceptance':False}
(out/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('runs','broad')},indent=2))
