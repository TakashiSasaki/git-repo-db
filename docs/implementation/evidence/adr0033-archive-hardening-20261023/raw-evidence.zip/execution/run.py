import datetime,json,os,subprocess,sys,time
from pathlib import Path
name,output,*cmd=sys.argv[1:]; out=Path(output); out.mkdir(parents=True,exist_ok=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
with (out/(name+'.log')).open('w') as log:
 p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
r={'command':cmd,'cwd':os.getcwd(),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.monotonic()-clock,'exit_code':p.returncode}
(out/(name+'.execution.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(p.returncode)
