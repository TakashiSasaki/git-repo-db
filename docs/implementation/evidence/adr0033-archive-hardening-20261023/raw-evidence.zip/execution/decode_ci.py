import base64,hashlib,io,json,re,sys,zipfile
from pathlib import Path
src,out,expected_head,expected_tree=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3],sys.argv[4]
out.mkdir(parents=True,exist_ok=True); result={'log_zip_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'receipts':[]}
with zipfile.ZipFile(src) as z:
 for name in z.namelist():
  if '/' in name or not name.endswith('.txt'):continue
  log=z.read(name).decode();(out/(Path(name).stem+'.log')).write_text('\n'.join(x for x in log.splitlines() if 'CI_RECEIPTS_DATA_V1' not in x)+'\n')
  starts=list(re.finditer(r'^.*?CI_RECEIPTS_BEGIN_V1 ([0-9a-f]{64}) (\d+)\s*$',log,re.M))
  for i,start in enumerate(starts):
   sha,length=start.group(1),int(start.group(2));end=re.search(r'^.*?CI_RECEIPTS_END_V1 ([0-9a-f]{64})\s*$',log[start.end():],re.M);assert end and end.group(1)==sha
   body=log[start.end():start.end()+end.start()];data=base64.b64decode(''.join(re.findall(r'CI_RECEIPTS_DATA_V1 ([A-Za-z0-9+/=]+)',body)),validate=True);assert len(data)==length and hashlib.sha256(data).hexdigest()==sha
   with zipfile.ZipFile(io.BytesIO(data)) as receipts:
    assert len(receipts.namelist())==len(set(receipts.namelist()))
    index=json.loads(receipts.read('receipt-index.json'))
    for p,entry in index.items():
     raw=receipts.read(p);assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
    binding=json.loads(receipts.read('receipt-binding.json')); assert binding['head']==expected_head and binding['tree']==expected_tree
    for p in ('receipt-binding.json','validation-manifest.json','plan.json','sdist-members.json'):
     if p in receipts.namelist():(out/p).write_bytes(receipts.read(p))
    result['receipts'].append({'bytes':length,'sha256':sha,'indexed_members_verified':len(index),'binding':binding})
   (out/f'receipts-{i}.zip').write_bytes(data)
assert len(result['receipts'])==1
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
