### dependency-setup: 0.30s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `6d649500319f404da210a92151a88f37bbd60fc2`, tree `43f0c017d5f922f7e1caf7e4a1605ec4ae7ace1c`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `dependency-setup-1792721075-a5e17ccd`. Dirty tree: `False`.
Command wall time: 0.30s; Cumulative test duration: 0.30s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
