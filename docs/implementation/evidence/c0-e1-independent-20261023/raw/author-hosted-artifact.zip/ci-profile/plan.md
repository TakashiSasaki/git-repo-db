## Validation plan

Mode: `development`; Effective SHA `6d649500319f404da210a92151a88f37bbd60fc2`; full acceptance selected: False.
Acceptance input hash: `adf24af45466e6a4cd592a85938f4d1389b74405e4c39149ff7fc0d5c18453b3`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 212.
Selected test files: 0.
Unexecuted acceptance files: 212. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.145s.

### Scope reasons
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/artifact-index.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/baseline.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/baseline.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/before-unittest.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/before.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-0.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-1.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-2.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-3.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-4.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-5.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/checks.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/collection.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/fixed.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/fixed.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/input-hashes.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/reconciliation.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/regression-journal.jsonl.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/regression.xml.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/verify.py
Shared/executable input: scripts/emit_ci_evidence.py
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
