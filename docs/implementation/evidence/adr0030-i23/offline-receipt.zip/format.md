### format: 0.23s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `02804e9359ab8e1e0d0f496b76e573e4d97c327d`, tree `476ee24311a78efa3048b301ea598f22fb13bc45`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `format-1792424658-547b300a`. Dirty tree: `False`.
Command wall time: 0.23s; Cumulative test duration: 0.23s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
