## Validation plan

Mode: `development`; Effective SHA `02804e9359ab8e1e0d0f496b76e573e4d97c327d`; full acceptance selected: False.
Acceptance input hash: `31dc65a257b50a5bc1c49db341499329ead23d09d33fe048e5ed97399c2b04cf`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 197.
Selected test files: 0.
Unexecuted acceptance files: 197. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.334s.

### Scope reasons
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
