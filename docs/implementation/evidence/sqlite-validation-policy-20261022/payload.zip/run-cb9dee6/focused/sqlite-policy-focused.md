### sqlite-policy-focused: 0.43s command wall time (exit 1)

Mode `sequential`, workers 1, SHA `cb9dee62077a25560f8ac03cc39c3ca5f97e2cfc`, tree `cb725bb06c0bf3a4ccea9f4f3c2aba51d0c5bd08`, Python 3.12.14, SQLite 3.53.1.
Invocation ID: `focused-1792678718-fe7a78`. Dirty tree: `False`.
Command wall time: 0.43s; Cumulative test duration: 0.43s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|

Measurement error: Missing or malformed JUnit
