### report-validation: 0.52s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `142f45ceae01603fe4a939399dffcb7ed4c1254c`, tree `b5bdcb3cf5361a339ecdcea496c9ee32d1ab61ce`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `report-validation-1792711860-f72df0f8`. Dirty tree: `False`.
Command wall time: 0.52s; Cumulative test duration: 0.52s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
