## Validation plan

Mode: `development`; Effective SHA `142f45ceae01603fe4a939399dffcb7ed4c1254c`; full acceptance selected: False.
Acceptance input hash: `99a1f8ef32a375631a6b24f5a0c40257215ba932ecc63d445723fbfc23b0ddb4`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 212.
Selected test files: 0.
Unexecuted acceptance files: 212. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.263s.

### Scope reasons
Shared/executable input: .github/workflows/access-registry.yml
Shared/executable input: .github/workflows/tests.yml
Shared/executable input: pyproject.toml
Shared/executable input: scripts/check_sdist_contract.py
Shared/executable input: scripts/ci_dependencies.json
Shared/executable input: scripts/ci_execute.py
Shared/executable input: scripts/ci_plan.py
Shared/executable input: scripts/verify_access_distribution.py
Shared/executable input: scripts/verify_i4_distribution.py
Shared/executable input: scripts/verify_i5_distribution.py
Shared/executable input: tests/support/distributions.py
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
