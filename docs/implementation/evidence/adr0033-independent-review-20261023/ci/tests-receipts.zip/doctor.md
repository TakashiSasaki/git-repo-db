### doctor: 0.12s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `18f1a890c18a8aee5b4b52238b520d7444c5776f`, tree `0f42e9d0e498e249bc2cc02f6b96df9ef87106a0`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `doctor-1792712608-75d9b92e`. Dirty tree: `False`.
Command wall time: 0.12s; Cumulative test duration: 0.12s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
