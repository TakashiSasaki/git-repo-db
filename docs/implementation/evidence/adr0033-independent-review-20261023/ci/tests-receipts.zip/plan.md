## Validation plan

Mode: `development`; Effective SHA `18f1a890c18a8aee5b4b52238b520d7444c5776f`; full acceptance selected: False.
Acceptance input hash: `ad2ff2e0ee0dd6b9965c9ba2bac9018e7a1c5286d149da5aec108ca6ea738c31`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 212.
Selected test files: 0.
Unexecuted acceptance files: 212. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.094s.

### Scope reasons
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/artifact-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/coverage.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/executions.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/measurements.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/raw-evidence.zip
