import os,subprocess,json,time,pathlib
root=pathlib.Path('/workspace/adr0033-execution'); out=pathlib.Path('/workspace/adr0033-results'); py=str(root/'.venv/bin/python')
env=dict(os.environ,UV_CACHE_DIR='/workspace/.uv-cache',REPO_CATALOG_WHEELHOUSE='/workspace/adr0033-wheelhouse',TMPDIR='/workspace/adr0033-tmp',PATH=str(root/'.venv/bin')+os.pathsep+os.environ['PATH'])
pathlib.Path(env['TMPDIR']).mkdir(exist_ok=True)
commands=[('focused',[py,'-m','pytest','tests/unit/test_ci_plan.py','tests/unit/test_test_efficiency.py','tests/integration/test_ci_execution.py','tests/unit/test_distribution_cache.py','-q','--junitxml='+str(out/'focused.xml'),'--journal='+str(out/'focused.jsonl')]),('packaging',[py,'-m','pytest','tests/packaging','-q','--junitxml='+str(out/'packaging.xml'),'--journal='+str(out/'packaging.jsonl')]),('broad',[py,'scripts/verify_i5.py','--output',str(out/'broad'),'--workers','2']),('installed',[py,'scripts/verify_i5_distribution.py','--output',str(out/'installed')]),('docs-unit',[py,'-m','pytest','tests/unit/test_docs_build.py','-q','--junitxml='+str(out/'docs-unit.xml'),'--journal='+str(out/'docs-unit.jsonl')])]
for name,cmd in commands:
 print('START '+name,flush=True); start=time.time()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt=dict(command=cmd,cwd=str(root),exit_code=p.returncode,elapsed_seconds=time.time()-start)
 (out/(name+'.execution.json')).write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(dict(name=name,**receipt)),flush=True)
