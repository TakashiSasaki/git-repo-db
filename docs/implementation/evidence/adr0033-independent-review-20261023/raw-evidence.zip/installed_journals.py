import os,json,subprocess,shutil,sys
from pathlib import Path
source=Path('/workspace/adr0033-execution');out=Path('/workspace/adr0033-results');installed=out/'installed';outside=installed/'outside'
shutil.copyfile(source/'scripts/ci_journal.py',outside/'ci_journal.py')
records=[]
for tag in ('direct','sdist'):
 py=installed/(tag+'-venv')/'bin/python';env={**os.environ,'PYTHONPATH':str(outside/'network_guard')+os.pathsep+str(outside),'PATH':str(py.parent)+os.pathsep+os.environ['PATH'],'GIT_ALLOW_PROTOCOL':'file'}
 for key in ('GH_TOKEN','GITHUB_TOKEN','PYTHONHOME'):env.pop(key,None)
 for name,args in [('collect',['--collect-only','-q']),('execute',['-q','--junitxml='+str(out/(tag+'-installed-journal.xml')),'--journal='+str(out/(tag+'-installed-journal.jsonl'))])]:
  cmd=[str(py),'-m','pytest','-p','ci_journal','--confcutdir='+str(outside),'test_installed_i4.py','test_installed_i5.py',*args]
  with (out/(tag+'-installed-'+name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=outside,env=env,stdout=f,stderr=subprocess.STDOUT)
  records.append({'name':tag+'-'+name,'command':cmd,'cwd':str(outside),'exit_code':p.returncode});print(tag,name,p.returncode,flush=True)
(out/'installed-journals.execution.json').write_text(json.dumps(records,indent=2)+'\n')
