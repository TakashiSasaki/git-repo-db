from pathlib import Path
import json,zipfile,hashlib,subprocess
repo=Path('/workspace/git-repo-db');e=repo/'docs/implementation/evidence/adr0033-independent-review-20261023';r=Path('/workspace/adr0033-results')
# Select only receipts, manifests, commands and diagnostics. Never package disposable DBs or environments.
selected=[]
for p in r.iterdir():
 if p.is_file() and p.suffix in {'.json','.xml','.jsonl','.log','.py','.txt'}: selected.append(p)
for directory in ('broad','installed','measurement','measurement-corrected','backend-isolation'):
 for p in (r/directory).iterdir():
  if p.is_file() and p.suffix in {'.json','.xml','.jsonl','.log','.txt'}: selected.append(p)
with zipfile.ZipFile(r/'baseline133.zip') as z:
 for name in ('local-i5/regressions.xml','local-i5/regressions.execution.json'):
  p=r/('baseline-'+Path(name).name);p.write_bytes(z.read(name));selected.append(p)
index={}
with zipfile.ZipFile(e/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(selected)):
  raw=p.read_bytes();name=p.relative_to(r).as_posix();z.writestr(name,raw);index[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 z.writestr('payload-index.json',json.dumps(index,indent=2)+'\n')
(e/'raw-evidence-index.json').write_text(json.dumps({'archive':'raw-evidence.zip','bytes':(e/'raw-evidence.zip').stat().st_size,'sha256':hashlib.sha256((e/'raw-evidence.zip').read_bytes()).hexdigest(),'payload_members':len(index),'members':index},indent=2)+'\n')
# Convenient machine-readable summaries are copies of frozen execution evidence.
for name in ('reviewed-input-hashes.json','local-execution-summary.json','installed-journal-reconciliation.json','baseline-comparison-confirmed.json','message-frame-differences.json'):
 (e/name).write_bytes((r/name).read_bytes())
(e/'measurements.json').write_bytes((r/'measurement-corrected/measurements.json').read_bytes())
findings=json.loads((e/'archive/findings.json').read_text())+json.loads((e/'ci/findings.json').read_text())
(e/'findings.json').write_text(json.dumps({'result':'FAIL','reviewed_head':'8cd89a3d25c811ee32d117ec32fe76a6022e6d94','reviewed_tree':'0f42e9d0e498e249bc2cc02f6b96df9ef87106a0','counts':{'Critical':0,'High':0,'Medium':2,'Low':2},'findings':findings},indent=2)+'\n')
print('raw payloads',len(index),'zip bytes',(e/'raw-evidence.zip').stat().st_size)
