import os,sys,time,json,subprocess
from pathlib import Path
root=Path('/workspace/adr0033-execution');out=Path('/workspace/adr0033-results');py=str(root/'.venv/bin/python')
env=dict(os.environ,PATH=str(root/'.venv/bin')+os.pathsep+os.environ['PATH'],UV_CACHE_DIR='/workspace/.uv-cache',REPO_CATALOG_WHEELHOUSE='/workspace/adr0033-wheelhouse',TMPDIR='/workspace/adr0033-tmp')
commands=[('focused-corrected',[py,'-m','pytest','tests/unit/test_ci_plan.py','tests/unit/test_test_efficiency.py','tests/integration/test_ci_execution.py','-q','--junitxml='+str(out/'focused-corrected.xml'),'--journal='+str(out/'focused-corrected.jsonl')]),('docs-unit-corrected',[py,'-m','pytest','tests/unit/test_build_docs_site.py','-q','--junitxml='+str(out/'docs-unit-corrected.xml'),'--journal='+str(out/'docs-unit-corrected.jsonl')]),('docs-build',[py,'scripts/build_docs_site.py','--no-mermaid','--staging-dir',str(out/'docs-staging'),'--output-dir',str(out/'docs-site')]),('lint',[str(root/'.venv/bin/ruff'),'check','src','tests','scripts']),('format',[str(root/'.venv/bin/ruff'),'format','--check','src','tests','scripts']),('sqlite-policy',[py,'scripts/check_sqlite_validation_policy.py'])]
for name,cmd in commands:
 t=time.time()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 record=dict(command=cmd,cwd=str(root),exit_code=p.returncode,elapsed_seconds=time.time()-t)
 (out/(name+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,p.returncode,flush=True)
