"""Read-only C0 verification of previously executed #133, no code execution from ZIPs."""
import base64
from collections import Counter
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/c0-source-check')
BASE = 'a022dd3efb9c8116cf9dc0abc13ab1d5bbc88e37'
HEAD = 'f16e5b1713bde9a2f18263a25397c4b450fd5773'
TREE = '6bfa580baafa9f6a117b7a0b610c4e65cd031b86'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def j(raw):
    return json.loads(raw)

def verify_index(files, index):
    assert len(files) == len(index) + 1
    for name, entry in index.items():
        assert len(files[name]) == entry['bytes'], name
        assert digest(files[name]) == entry['sha256'], name

def unzip(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert len(set(z.namelist())) == len(z.namelist())
        return {name: z.read(name) for name in z.namelist()}

def receipt(log):
    start = re.search(r'^.*?CI_RECEIPTS_BEGIN_V1 ([a-f0-9]{64}) (\d+)\s*$', log, re.M)
    assert start
    tail = log[start.end():]
    stop = re.search(r'^.*?CI_RECEIPTS_END_V1 ([a-f0-9]{64})\s*$', tail, re.M)
    assert stop and stop[1] == start[1]
    chunks = re.findall(r'^.*?CI_RECEIPTS_DATA_V1 ([A-Za-z0-9+/=]+)\s*$', tail[:stop.start()], re.M)
    raw = base64.b64decode(''.join(chunks), validate=True)
    assert len(raw) == int(start[2]) and digest(raw) == start[1]
    files = unzip(raw)
    verify_index(files, j(files['receipt-index.json']))
    return raw, files

def xml_nodes(raw):
    result = {}
    for case in ET.fromstring(raw).iter('testcase'):
        key = (case.attrib['classname'], case.attrib['name'])
        assert key not in result, key
        bad = case.find('failure')
        phase = 'call'
        if bad is None:
            bad = case.find('error')
            phase = 'setup'
        skip = case.find('skipped')
        result[key] = {'status': 'failed' if bad is not None else 'skipped' if skip is not None else 'passed',
                       'phase': phase if bad is not None else None,
                       'message': bad.attrib.get('message', '') if bad is not None else '',
                       'trace': bad.text or '' if bad is not None else ''}
    return result

def frames(text):
    return re.findall(r'((?:src|tests)/[^\s:]+\.py):(\d+):([^\n]*)', text)

def outcomes(rows):
    return {'passed':sum(v['status']=='passed' for v in rows.values()),
            'failures':sum(v['status']=='failed' and v['phase']=='call' for v in rows.values()),
            'setup_errors':sum(v['status']=='failed' and v['phase']=='setup' for v in rows.values()),
            'skipped':sum(v['status']=='skipped' for v in rows.values())}

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])

def main():
    outer_raw = (ROOT/'published-payload.zip').read_bytes()
    outer = unzip(outer_raw)
    outer_index = j((ROOT/'published-artifact-index.json').read_bytes())
    assert len(outer_raw) == outer_index['payload']['bytes']
    assert digest(outer_raw) == outer_index['payload']['sha256']
    assert len(outer) == len(outer_index['members'])
    for name, entry in outer_index['members'].items():
        assert len(outer[name]) == entry['bytes'] and digest(outer[name]) == entry['sha256'], name
    summaries = {}
    for name in ['baseline/tests-receipts.zip', 'hosted-f16e5b1/tests-receipts.zip', 'hosted-f16e5b1/access-receipts.zip']:
        files = unzip(outer[name]); verify_index(files,j(files['receipt-index.json']))
        summaries[name] = {'bytes':len(outer[name]), 'sha256':digest(outer[name]), 'members':len(files),
                           'binding':j(files['receipt-binding.json'])}
    live_access = unzip((ROOT/'fixed-access-run-logs.zip').read_bytes())['0_registry-runtime.txt'].decode()
    live_baseline = unzip((ROOT/'baseline-run-logs.zip').read_bytes())['0_registry-runtime.txt'].decode()
    live_tests = unzip((ROOT/'fixed-tests-run-logs.zip').read_bytes())['1_offline.txt'].decode()
    for name, log, old in [('access',live_access,'hosted-f16e5b1/access-receipts.zip'),('tests',live_tests,'hosted-f16e5b1/tests-receipts.zip')]:
        raw, files = receipt(log)
        assert raw == outer[old], name
        (ROOT/f'live-{name}-receipts.zip').write_bytes(raw)
    assert '3.45.1' in live_baseline and 'SQLITE_RUNTIME' in live_baseline
    assert 'SQLite >=3.51.3' in live_baseline or '3.51.3' in live_baseline
    (ROOT/'baseline-access-job.log').write_text(live_baseline)
    (ROOT/'fixed-access-job.log').write_text(live_access)
    a = unzip(outer['hosted-f16e5b1/access-receipts.zip'])
    binding = j(a['receipt-binding.json'])
    assert binding['tree']==TREE and binding['run_id']=='39799299209'
    runtime_names = [name for name in a if name.endswith('.json') and (
        name.startswith('artifacts/runtime/') or name.endswith(('direct-runtime-binding.json','sdist-runtime-binding.json')))]
    selected = j(a['artifacts/runtime/selected.json'])
    runtime_fields = ['base_executable','sqlite_version','sqlite_source_id','sqlite_module','sqlite_module_sha256','compile_options','sqlite_mappings']
    runtimes = {}
    for name in runtime_names:
        data=j(a[name]); assert data['product_safety_and_capabilities']=='passed',name
        assert not any(data['loader_environment'].values()),name
        for field in runtime_fields:
            assert data[field]==selected[field],(name,field)
        runtimes[name] = data
    assert len(runtimes)==8
    build = j(a['artifacts/access-registry/i5-distribution/build-binding.json'])
    assert build['tree']==TREE and build['head']==binding['head']
    inputs = j(a['artifacts/access-registry/i5/input-binding.json'])
    for name, expected in inputs['inputs'].items():
        assert digest(git('show',HEAD+':'+name))==expected,name
    assert git('diff','--name-only',BASE,HEAD,'--','src','pyproject.toml','uv.lock','.python-version')==b''
    original=xml_nodes(a['artifacts/access-registry/tests.xml'])
    broad=xml_nodes(a['artifacts/access-registry/i5/regressions.xml'])
    old=unzip((ROOT/'pr132-payload.zip').read_bytes())
    baseline=xml_nodes(old['run-3594f47/i5/regressions.xml'])
    old_bad={k:v for k,v in baseline.items() if v['status']=='failed'}
    new_bad={k:v for k,v in broad.items() if v['status']=='failed'}
    assert old_bad.keys()==new_bad.keys() and len(new_bad)==79
    table=[]
    for key,value in sorted(new_bad.items()):
        before=old_bad[key]
        # Installed-artifact assertion messages embed different per-run temp paths.
        # Preserve the raw difference; compare actual stage refusal and full source frames.
        refusal=lambda x: re.search(r'I2_(?:TRANSFER|IDENTIFICATION_WIRE)_UNSUPPORTED(?:: [^\n\\]*)?',x).group()
        assert value['phase']==before['phase'] and refusal(value['message'])==refusal(before['message']),key
        assert frames(value['trace'])==frames(before['trace']),key
        table.append({'class':key[0],'name':key[1],'phase':value['phase'],'message':value['message'],
                      'raw_message_identical':value['message']==before['message'],
                      'same_stage_refusal':True,'same_frames_including_lines':True,'additional':False,'resolved':False})
    with (ROOT/'failure-comparison.tsv').open('w') as out:
        writer=csv.DictWriter(out,fieldnames=list(table[0]),delimiter='\t');writer.writeheader();writer.writerows(table)
    cohorts={}
    for lane,expected in [('transfer-admission',29),('transfer-sql',217),('regressions',3137)]:
        prefix='artifacts/access-registry/i5/'+lane
        nodes=[n for n in a[prefix+'.selected.txt'].decode().splitlines() if n]
        rows=xml_nodes(a[prefix+'.xml']); events=[j(line) for line in a[prefix+'.jsonl'].decode().splitlines()]
        assert len(nodes)==len(set(nodes))==len(rows)==expected
        starts=Counter(e['nodeid'] for e in events if e['event']=='start')
        assert starts==Counter(nodes)
        # Exact XML identity handles both ordinary and class-owned nodes.
        xml_expected=set()
        for n in nodes:
            node_prefix,bracket,parameters=n.partition('[')
            parts=node_prefix.split('::')
            # Parameter IDs may contain IPv6 addresses or ext:: transport text.
            classname=parts[0].removesuffix('.py').replace('/','.')
            if len(parts)>2:
                classname+='.'+'.'.join(parts[1:-1])
            xml_expected.add((classname,parts[-1]+bracket+parameters))
        assert xml_expected==rows.keys()
        phases=Counter((e['nodeid'],e['phase']) for e in events if e['event']=='phase')
        for node in nodes:
            assert phases[node,'setup']==phases[node,'teardown']==1
            setup=next(e for e in events if e.get('nodeid')==node and e.get('phase')=='setup')
            assert phases[node,'call']==int(setup['outcome']=='passed')
        finishes=[e for e in events if e['event']=='finish']; execution=j(a[prefix+'.execution.json'])
        assert len(finishes)==1 and finishes[0]['exitstatus']==execution['exit_code']
        cohorts[lane]={'nodes':expected,'status_counts':outcomes(rows),
                       'exit_code':execution['exit_code'],'selected_junit_journal_match':True}
    installed={}
    for label in ['direct','sdist']:
        installed[label]={}
        for lane,expected in [('i4',217),('i5',29)]:
            rows=xml_nodes(a[f'artifacts/access-registry/i5-distribution/{label}-{lane}.xml'])
            assert len(rows)==expected and all(v['status']=='passed' for v in rows.values())
            installed[label][lane]={'passed':expected}
    processes=j(a['artifacts/access-registry/i5-distribution/processes.json'])
    for label in ['direct','sdist']:
        found=[p for p in processes if p['name']==label+'-access'];assert len(found)==1 and found[0]['exit_code']==1
    original_smokes=j(a['artifacts/access-registry/distribution.json'])
    assert len(original_smokes)==2
    for s in original_smokes:
        assert s['exit_code']==1 and 'I2_TRANSFER_UNSUPPORTED' in s['stderr']
        assert s['sqlite']=='3.53.1' and '/site-packages/' in s['module_origin']
    result={'kind':'read_only_C0_duplicate_remediation_audit','baseline':BASE,'head':HEAD,'tree':TREE,
            'new_commits_or_PRs':False,'outer_payload':outer_index['payload'],'outer_members_verified':len(outer),
            'nested_receipts':summaries,'live_log_receipts_match_published':True,
            'verified_input_sha256_count':len(inputs['inputs']),'product_source_unchanged':True,
            'hosted_original':outcomes(original),
            'hosted_cohorts':cohorts,'inherited_failure_comparison':{'retained':79,'added':0,'resolved':0,'full_frames_including_lines':True,
                'raw_message_differences_due_to_temporary_paths':sum(not r['raw_message_identical'] for r in table)},
            'runtime_receipts':runtimes,'artifacts':build,'installed':installed,'original_smokes':original_smokes,
            'new_followup_finding':{'id':'C0-E1','severity':'Low','summary':'Receipt emitter permits 4 MiB; ADR 0001 VAL-07 specifies 2 MiB',
                'target':'scripts/emit_ci_evidence.py:63','actual_receipt_within_2MiB':True,'runtime_resolution_affected':False,
                'recommendation':'Restore the 2 MiB cap; test exact/+1 compressed bytes and preserve uploaded-artifact fallback.'}}
    (ROOT/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'runtime-facts.json').write_text(json.dumps(runtimes,indent=2)+'\n')
    (ROOT/'artifact-hashes.json').write_text(json.dumps(build,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['outer_members_verified','verified_input_sha256_count','hosted_original','hosted_cohorts','inherited_failure_comparison','new_followup_finding']},indent=2))

if __name__=='__main__':
    main()
