import json
import uuid

from repo_catalog.domain.models import CatalogError, Waiting
from repo_catalog.domain.time import now_us, validate_epoch_us


class JobService:
    def __init__(self, store, *, clock_us=now_us):
        """Use an injectable wall clock returning integer Unix epoch microseconds."""
        self.store = getattr(store, "operational", store)
        self.clock_us = clock_us

    def create(self, kind, request):
        job = str(uuid.uuid4())
        timestamp = validate_epoch_us(self.clock_us())
        with self.store.transaction():
            self.store.execute(
                "INSERT INTO jobs(job_id,kind,request,current_attempt,created_at_us) VALUES(?,?,?,1,?)",
                (job, kind, json.dumps(request), timestamp),
            )
            self.store.execute(
                "INSERT INTO job_attempts(job_id,attempt,state,created_at_us,updated_at_us,not_before_us,checkpoint,reason) VALUES(?,1,'running',?,?,NULL,'{}',NULL)",
                (job, timestamp, timestamp),
            )
        return job

    def resume(self, job):
        row = self.store.one(
            "SELECT j.*,a.state,a.not_before_us FROM jobs j JOIN job_attempts a ON a.job_id=j.job_id AND a.attempt=j.current_attempt WHERE j.job_id=?",
            (job,),
        )
        if not row:
            raise CatalogError("NOT_FOUND", "Job not found")
        if row["kind"] == "legacy":
            raise CatalogError(
                "INVALID_ARGUMENT",
                "Imported historical jobs are evidence, not resumable processes; start a new sync",
            )
        if row["state"] in ("complete", "cancelled"):
            raise CatalogError("INVALID_ARGUMENT", "Job is not resumable")
        timestamp = validate_epoch_us(self.clock_us())
        if row["not_before_us"] is not None and row["not_before_us"] > timestamp:
            raise Waiting(
                "NOT_BEFORE",
                "Job is waiting for its scheduled retry",
                {"not_before_us": row["not_before_us"]},
                True,
            )
        attempt = row["current_attempt"] + 1
        with self.store.transaction():
            if row["state"] == "running":
                self.store.execute(
                    "UPDATE job_attempts SET state='interrupted',updated_at_us=?,reason='process_restart' WHERE job_id=? AND attempt=?",
                    (timestamp, job, row["current_attempt"]),
                )
            self.store.execute(
                "INSERT INTO job_attempts(job_id,attempt,state,created_at_us,updated_at_us,not_before_us,checkpoint,reason) VALUES(?,?,'running',?,?,NULL,'{}',NULL)",
                (job, attempt, timestamp, timestamp),
            )
            self.store.execute("DELETE FROM cache_leases WHERE job_id=?", (job,))
            self.store.execute("DELETE FROM space_reservations WHERE job_id=?", (job,))
            self.store.execute(
                "UPDATE jobs SET current_attempt=? WHERE job_id=?", (attempt, job)
            )
        return row["kind"], json.loads(row["request"])

    def update(self, job, state, reason=None, not_before_us=None, *, result=None):
        if not_before_us is not None:
            validate_epoch_us(not_before_us)
        timestamp = validate_epoch_us(self.clock_us())
        with self.store.transaction():
            self.store.execute(
                "UPDATE job_attempts SET state=?,reason=?,not_before_us=?,updated_at_us=? WHERE job_id=? AND attempt=(SELECT current_attempt FROM jobs WHERE job_id=?)",
                (state, reason, not_before_us, timestamp, job, job),
            )
            if result is not None:
                self.store.execute(
                    "UPDATE job_attempts SET checkpoint=json_set(checkpoint,'$.result',json(?)) "
                    "WHERE job_id=? AND attempt=(SELECT current_attempt FROM jobs WHERE job_id=?)",
                    (json.dumps(result, allow_nan=False), job, job),
                )

    def cancel(self, job):
        row = self.store.one(
            "SELECT a.state FROM jobs j JOIN job_attempts a ON a.job_id=j.job_id AND a.attempt=j.current_attempt WHERE j.job_id=?",
            (job,),
        )
        if not row:
            raise CatalogError("NOT_FOUND", "Job not found")
        if row[0] == "running":
            raise CatalogError("JOB_RUNNING", "Use SIGINT on the foreground process")
        if row[0] not in ("queued", "waiting", "failed", "interrupted"):
            raise CatalogError("INVALID_ARGUMENT", "Job cannot be cancelled")
        self.update(job, "cancelled")
