"""P3 Context interfaces; every mutation participates in caller transaction.

No method commits, fetches Git closure or rewrites original source provenance.
Standalone Context is durable without Core. Dependent links use coordination.
"""

from collections.abc import Callable, Iterable
from typing import Protocol

from repo_catalog.domain.context_admission import AdmissionContext
from repo_catalog.domain.p1_context import (
    CoverageClaim,
    CoverageProjection,
    CoverageScope,
    FieldCandidate,
    MappingClaimKey,
    MappingDisposition,
    MappingOperationEvidence,
    QualifiedMappingEvaluation,
    QualifiedProviderRepositoryRole,
    RelationKind,
    ResolvedRepositoryRelation,
    ResourceKey,
    ResourceRepositoryRelation,
    TransferEventReport,
)
from repo_catalog.domain.resource_identification import ResourceIdentification


class ContextAdmission(Protocol):
    def text(self, text_value: str, *, admission: AdmissionContext) -> str: ...
    def scope(self, scope: CoverageScope, *, admission: AdmissionContext) -> None: ...
    def resource(
        self,
        key: ResourceKey,
        repository_uuidv4: str | None = None,
        *,
        identification: ResourceIdentification | None = None,
        admission: AdmissionContext,
    ) -> None: ...
    def identification(self, key: ResourceKey) -> ResourceIdentification: ...
    def admit_repository_relation(
        self,
        relation: ResourceRepositoryRelation,
        *,
        require_support: bool = False,
        admission: AdmissionContext,
    ) -> str: ...
    def admit_transfer_event(
        self, report: TransferEventReport, *, admission: AdmissionContext
    ) -> str: ...
    def admit_mapping_disposition(
        self, disposition: MappingDisposition, *, admission: AdmissionContext
    ) -> str: ...
    def repository_relations(
        self,
        resource: ResourceKey,
        relation_kind: RelationKind | None = None,
        *,
        evidence: MappingOperationEvidence | None = None,
    ) -> tuple[ResolvedRepositoryRelation, ...]: ...
    def relations_for_repository(
        self,
        repository_uuidv4: str,
        relation_kind: RelationKind | None = None,
        *,
        evidence: MappingOperationEvidence | None = None,
    ) -> tuple[ResolvedRepositoryRelation, ...]: ...
    def relations_for_provider_repository(
        self,
        service_instance_uuidv4: str,
        provider_repository_id: str,
        relation_kind: RelationKind | None = None,
        *,
        evidence: MappingOperationEvidence | None = None,
    ) -> tuple[ResolvedRepositoryRelation, ...]: ...
    def evaluate_provider_repository(
        self,
        provider_repository: ResourceKey,
        *,
        evidence: MappingOperationEvidence | None = None,
    ) -> QualifiedMappingEvaluation: ...
    def mapping_dispositions(
        self, subject: MappingClaimKey | ResourceKey | None = None
    ) -> tuple[MappingDisposition, ...]: ...
    def provider_repository_roles(
        self, resource: ResourceKey, *, evidence: MappingOperationEvidence | None = None
    ) -> tuple[QualifiedProviderRepositoryRole, ...]: ...
    def transfer_event_reports(
        self,
        resource: ResourceKey | None = None,
        *,
        repository_uuidv4: str | None = None,
        selected_repositories: Iterable[str] | None = None,
    ) -> tuple[TransferEventReport, ...]: ...
    def admit_field(
        self, candidate: FieldCandidate, *, admission: AdmissionContext
    ) -> str: ...
    def candidates(
        self, resource: ResourceKey, field_name: str
    ) -> tuple[FieldCandidate, ...]: ...
    def admit_coverage(
        self, claim: CoverageClaim, *, admission: AdmissionContext
    ) -> str: ...
    def coverage(self, scope: CoverageScope) -> CoverageProjection: ...
    def link_core(
        self,
        resource: ResourceKey,
        role: str,
        object_format: str,
        full_oid: str,
        provenance_json: str,
        validate: Callable[[str, str], bool],
        *,
        admission: AdmissionContext,
    ) -> None: ...
