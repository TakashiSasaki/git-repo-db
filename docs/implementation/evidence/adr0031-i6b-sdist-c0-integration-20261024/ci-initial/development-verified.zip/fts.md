### fts: 0.02s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `c915fc731bd60339e681a6af8f86a470058a5e06`, tree `d2010275a90ae6b6cb728344d5708057a79110cd`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `fts-1792779777-7d5e9584`. Dirty tree: `False`.
Command wall time: 0.02s; Cumulative test duration: 0.02s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
