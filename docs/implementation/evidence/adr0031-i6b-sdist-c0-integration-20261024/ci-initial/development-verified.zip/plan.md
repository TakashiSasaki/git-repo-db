## Validation plan

Mode: `development`; Effective SHA `c915fc731bd60339e681a6af8f86a470058a5e06`; full acceptance selected: False.
Acceptance input hash: `106d274117017ca99caafb07b20c36eed6a9995dfa752f6bebfcfbe047618a67`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 232.
Selected test files: 0.
Unexecuted acceptance files: 232. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.286s.

### Scope reasons
Shared/executable input: .github/workflows/access-registry.yml
Shared/executable input: .github/workflows/tests.yml
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/baseline-comparison.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/measurements.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/pax-calibration.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/raw-evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/raw-evidence.zip
Unknown dependency path: docs/implementation/evidence/adr0033-archive-hardening-20261023/verification-summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/after-members.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/baseline-comparison-summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/before-members.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__distribution.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__failure-comparison.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__i5-distribution__build-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__i5-distribution__sdist-contract.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__i5-distribution__summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__i5__input-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__i5__summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__offline-inventory__selection.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__offline-inventory__summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__sdist-contract.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-artifacts__access-registry__source-revision.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-jobs.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-receipt-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-receipts.zip
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-registry.log.gz
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-run-live.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/access-unexecuted-ordinary-nodeids.txt
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt1.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt1.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt2.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt2.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt3.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt3.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt4.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-attempt4.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-compressed.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit-compressed.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/audit_receipts.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/command-records.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/commit-workflow-runs.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/feature-commit-live.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/findings.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/independent-audit.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/independent-inherited-failure-comparison.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/operations.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/probe_readme_binding.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/probe_readme_sdist_inventory.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/raw-log-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/readme-binding-result.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/readme-sdist-inventory-result.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/receipt-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/runtime-identity-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/sanitization-check.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/test-merge-commit-live.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-jobs.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-offline.log.gz
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-plan.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-policy.log.gz
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-receipt-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-receipts.zip
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-run-live.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/ci/tests-validation-manifest.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/findings.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/historical-evidence-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/bounded-memory-results.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/bounded-memory.exit
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/bounded-memory.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/bounded-memory.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/findings.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/initial-probe.exit
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/initial-probe.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/initial-probe.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/initial-results.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/probe.exit
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/probe.stderr
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/probe.stdout
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/probe_bounded_memory.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/probe_independent.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/independent-audit/results.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/measurements.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/raw-evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/raw-evidence.zip
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/compare.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/package_evidence.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/prepare_evidence.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/run.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/stage2.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/stage3.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/reproduce/summarize.py
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/sanitization-check.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/sdist-contract.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/setup-failures.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/startup/live-0.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/startup/live-1.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/startup/live-2.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/startup/live-3.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/startup/live-4.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/trace-difference-audit.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/verification-summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-hardening-rereview-20261023/verified-input-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/concatenated.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/corrupt-gzip-crc.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/malformed-second-gzip-member.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/metadata1.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/metadata2.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/missing-gzip-trailer.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/pax-hidden-log.tar.gz
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/source/.gitignore
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/source/pyproject.toml
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/source/src/repo_catalog/__init__.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/source/src/repo_catalog/contract.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/source/src/repo_catalog/query.graphql
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/counterexamples/source/src/repo_catalog/schema.sql
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/final-results.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/findings.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/probe_archive.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/results.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/archive/specimen-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/baseline-comparison-confirmed.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/access-jobs.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/access-receipt-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/access-receipts.zip
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/author-evidence-index-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/check-runs.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/execution-environment.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/findings.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/hosted-log-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/hosted-log-views-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/hosted-log-views.zip
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/initial-tests-log-verification.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/initial-tests-plan.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/initial-tests-receipt-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/initial-tests-receipts.zip
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/initial-tests-sdist-members.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/initial-tests-validation-manifest.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/inspect_hosted_logs.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/pages-unchanged-inputs.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/pr138.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/probe_readme_binding.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/readme-binding-result.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/reviews.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/sanitization-check.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/tests-jobs.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/tests-plan.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/tests-receipt-binding.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/tests-receipts.zip
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/ci/tests-validation-manifest.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/findings.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/installed-journal-reconciliation.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/local-execution-summary.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/measurements.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/message-frame-differences.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/raw-evidence-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/raw-evidence.zip
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/reproduce/check_backend_isolation.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/reproduce/installed_probe.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/reproduce/measure_distributions.py
Unknown dependency path: docs/implementation/evidence/adr0033-independent-review-20261023/reviewed-input-hashes.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/artifact-index.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/coverage.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/executions.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/measurements.json
Unknown dependency path: docs/implementation/evidence/adr0033-minimal-sdist-20261022/raw-evidence.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/artifact-index.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/findings.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/artifact-download-result.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/audit-pr136.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-artifact.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-artifacts.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-jobs.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-offline.log.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-run.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-sqlite-policy.log.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-verified.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/author-hosted-verified.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries/fixed-2097151.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries/fixed-2097152.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries/fixed-2097153.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries/fixed-2323560.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries/fixed-expanded-over-limit.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundaries/measurements.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/boundary-executions.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/calibration-attempt2.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/calibration-attempt2.py.txt
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/check-runner.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/checks.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/collection.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/dependencies.txt
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/execution.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/exploratory-boundaries.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/exploratory-boundaries/fixed-2097151.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/exploratory-boundaries/fixed-2097152.zip
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/exploratory-verify-boundaries.py.txt
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/final-checks.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/final-review-format.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/final-review-lint.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/github-initial.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/github-prepublication.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/initial-whitespace-check.log.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/input-hashes.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/journal.jsonl
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/local-runtime-final.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/local-runtime.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/log-preservation.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/packaging-checks.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/packaging-format.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/packaging-lint.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/packaging-reports.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/pytest.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/reconciliation.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/reports.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/review-format.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/review-lint.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/ruff-format.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/ruff-lint.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/runtime-final.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/sqlite-policy.log
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/tests.xml
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/raw/workflow-review.json
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/reconcile.py
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/run_checks.py
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/verify_boundaries.py
Unknown dependency path: docs/implementation/evidence/c0-e1-independent-20261023/verify_hosted.py
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/artifact-index.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/baseline.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/baseline.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/before-unittest.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/before.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-0.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-1.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-2.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-3.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-4.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/check-5.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/checks.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/collection.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/fixed.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/fixed.log
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/input-hashes.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/reconciliation.json
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/regression-journal.jsonl.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/regression.xml.gz
Unknown dependency path: docs/implementation/evidence/c0-e1-receipt-limit-20261023/verify.py
Unknown dependency path: docs/implementation/evidence/c0-hosted-runtime-audit-20261022/artifact-index.json
Unknown dependency path: docs/implementation/evidence/c0-hosted-runtime-audit-20261022/audit-evidence.zip
Unknown dependency path: docs/implementation/evidence/c0-hosted-runtime-audit-20261022/audit.json
Unknown dependency path: docs/implementation/evidence/c0-hosted-runtime-audit-20261022/failure-comparison.json
Unknown dependency path: docs/implementation/evidence/c0-hosted-runtime-audit-20261022/findings.json
Unknown dependency path: docs/implementation/evidence/c0-hosted-runtime-audit-20261022/handoff.txt
Shared/executable input: pyproject.toml
Shared/executable input: scripts/check_sdist_contract.py
Shared/executable input: scripts/ci_dependencies.json
Shared/executable input: scripts/ci_execute.py
Shared/executable input: scripts/ci_plan.py
Shared/executable input: scripts/emit_ci_evidence.py
Shared/executable input: scripts/verify_access_distribution.py
Shared/executable input: scripts/verify_i4_distribution.py
Shared/executable input: scripts/verify_i5_distribution.py
Shared/executable input: tests/support/distributions.py
Dynamic test dependency requires full selection: tests/integration/i3/test_selective_exchange.py
