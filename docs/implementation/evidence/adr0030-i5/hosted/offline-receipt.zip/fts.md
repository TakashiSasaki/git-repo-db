### fts: 0.02s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `320fe9aa955a97975affb25713b8cfe32c0a58f6`, tree `cc2eafaaeb8e3305270c17e74ae69edc42c0a50b`, Python 3.12.15, SQLite 3.45.1.
Invocation ID: `fts-1792428115-69fa7ce7`. Dirty tree: `False`.
Command wall time: 0.02s; Cumulative test duration: 0.02s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
