## Validation plan

Mode: `development`; Effective SHA `320fe9aa955a97975affb25713b8cfe32c0a58f6`; full acceptance selected: False.
Acceptance input hash: `520215b6d13ef8c49174eab814207ca9217f5c38a089c9c01d7d6c27df99106a`.

| Lane | Disposition | Test files |
|---|---|---:|
| static | selected | 0 |
| tests | not_applicable | 0 |
| packaging | not_applicable | 0 |
| smoke | selected | 0 |

Required test files: 198.
Selected test files: 0.
Unexecuted acceptance files: 198. Earlier test results are never claimed as fresh execution.
Files outside current acceptance: 0; listed in plan.json.

Planner: 0.061s.

### Scope reasons
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/distribution.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/evidence-reconciliation.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final-audits.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final-changed-inputs.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final-distribution.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final-focused.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final-runtime.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final2-focused.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final2-focused.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final3-focused.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final3-focused.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/final_external_probes.py.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/focused.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/focused.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/hosted-merge-github.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/hosted-reconciliation.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/hosted-reconciliation.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/offline-reconciliation.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/probes-initial-harness-errors.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/pytest-final-binding.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/reconcile_evidence.py.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/reconcile_hosted.py.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/reconcile_offline.py.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/review-summary.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/independent/review_binding_plugin.py.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/index.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/acceptance.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/acceptance.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-0.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-1.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-2.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-3.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-4.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-5.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audit-6.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/audits.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/collection.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/commands.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/distribution-stderr.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/distribution.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/distribution.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/end-refs.txt
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/expanded.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-acceptance.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-collected.txt
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-distribution.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-download.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-job.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-jobs.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-log-unavailable.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-reconciliation.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-runtime.txt
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-source-revision.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-status-snapshot.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/hosted-tests.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-final-precommit.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-first.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-freeze.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-freeze2.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-second.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-source.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-source.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/i4-third.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/implementation-files.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/inputs.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-job.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-jobs.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-receipt-binding.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-receipt-index.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-receipt.zip
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-status-snapshot.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/offline-validation-manifest.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/p6-baseline.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/p6-baseline.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/p6-first.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/p6-resolution.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/read_offline.py.txt.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/reconcile_p6.py.txt.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/run_expanded.py.txt.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/runtime-build.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/runtime.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/source.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/start-refs.txt.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/stop-fix.log.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/stop-fix.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/summary.json
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/superseded-ci-cancellation.json.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/tests.xml.gz
Unknown dependency path: docs/implementation/evidence/adr0030-i4/raw/verify_hosted.py.txt.gz
