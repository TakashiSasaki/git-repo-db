"""Deterministic sanitized Task F artifact assembly; never edits existing files."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import zipfile

src=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path(sys.argv[1])
dest=repo/'docs/implementation/evidence/adr0031-i2-f1-task-f'
dest.mkdir(exist_ok=False)
def digest(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files={}
for n in ('build_runtimes.py','review_sql.py','run_review.py','audit_evidence.py',
          'package_evidence.py','README.md','REPORT.md','initial-github-observations.json',
          'prepublication-github.json','remote-heads.txt','remote-heads-process.json',
          'evidence-audit.json','final-launcher.json','attempt-1-launcher.json',
          'runtime/provenance.json'):
    files[n]=(src/n).read_bytes()
for root in ('final-run','attempt-1'):
    for p in (src/root).rglob('*'):
        if p.is_file(): files[str(p.relative_to(src))]=p.read_bytes()

# Recover and verify the exact initial harness, which lacked the 21 later controls.
current=(src/'review_sql.py').read_text()
start=current.index('# Even the correct native I7 Parent report')
end=current.index('# Same-key replay:',start)
initial=current[:start]+current[end:]
initial_hash=hashlib.sha256(initial.encode()).hexdigest()
assert initial_hash==json.loads((src/'attempt-1/input-binding.json').read_text())['harness_inputs']['review_sql.py']
files['attempt-1/review_sql.py']=initial.encode()
files['runtime/compiler.txt']=subprocess.check_output(['cc','--version'])

original=repo/'docs/implementation/evidence/adr0031-i2-independent-review/F1-reproduction.sql'
shutil.copyfile(original,dest/'F1-reproduction.sql')
receipt=json.loads((src/'final-run/3510300/receipt.json').read_text())
chosen=['report/ignore/dependencies-0','correct-I7-parent/report/upsert_noop',
        'generic-upsert-update/report','multirow/INSERT OR FAIL',
        'insert-select-returning/INSERT OR IGNORE']
text=['-- Independently executed Task F examples. Install reviewed after.sql and UDFs first.',
      '-- Each block uses a savepoint and rolls back to a fresh empty candidate.',
      '-- Expected SQL failures must not terminate your diagnostic driver early.','']
for name in chosen:
    case=next(c for c in receipt['cases'] if c['name']==name)
    text.extend(['-- '+name,'-- Expected extended SQL code '+str(case['expected']),
                 'SAVEPOINT independent_example;',
                 "INSERT INTO providers VALUES('22222222-2222-4222-8222-222222222222','task-f','{}');"])
    def sqlvalue(v):
        if v is None:return 'NULL'
        if isinstance(v,int):return str(v)
        return "'"+v.replace("'","''")+"'"
    before=case['before']
    for row in before['resources']:
        text.append('INSERT INTO resources(service_instance_uuidv4,resource_kind,provider_resource_id,identifier_namespace_kind,identifier_namespace_id,document_kind,provider_document_id) VALUES('+','.join(sqlvalue(v) for v in row[:7])+');')
    for row in before['resource_relations']:
        text.append('INSERT INTO resource_relations VALUES('+','.join(sqlvalue(v) for v in row)+');')
    # Trace is SQLite's concrete expanded text, not a homemade parameter encoder.
    stmt=case['trace'][0]
    text.extend([stmt+';', 'ROLLBACK TO independent_example;','RELEASE independent_example;',''])
(dest/'counterexamples.sql').write_text('\n'.join(text).rstrip()+'\n')
files['counterexamples.sql']=(dest/'counterexamples.sql').read_bytes()
files['F1-reproduction.sql']=original.read_bytes()
index={'scope':'Independent Task F execution and design review; no product acceptance',
       'files':{n:digest(b) for n,b in sorted(files.items())}}
archive=dest/'task-f-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,b in sorted(files.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,b)
    z.writestr('artifact-index.json',json.dumps(index,indent=2)+'\n')
for n in ('build_runtimes.py','review_sql.py','run_review.py','audit_evidence.py','README.md','REPORT.md'):
    shutil.copyfile(src/n,dest/n)
for lane,name in (('3510300','minimum-summary.json'),('3530100','newer-summary.json')):
    shutil.copyfile(src/'final-run'/lane/'summary.json',dest/name)
with zipfile.ZipFile(archive) as z:
    for name,metadata in index['files'].items():assert digest(z.read(name))==metadata
external={'reviewed_commit':'2199a882d79c9c707fffcba3a8327ef96a3fc384',
          'reviewed_tree':'b1595725bce322d04baf0f3b9b340cfdc71552a0',
          'archive_indexed_members':len(files),
          'files':{p.name:digest(p.read_bytes()) for p in sorted(dest.iterdir())}}
(dest/'artifact-index.json').write_text(json.dumps(external,indent=2)+'\n')
print(json.dumps({'directory':str(dest),'files':len(external['files'])+1,'archive':digest(archive.read_bytes()),
                  'archive_indexed_members':len(files),'initial_harness_hash_verified':initial_hash},indent=2))
