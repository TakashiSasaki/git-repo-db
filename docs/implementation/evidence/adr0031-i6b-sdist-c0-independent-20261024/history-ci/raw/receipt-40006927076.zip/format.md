### format: 0.14s command wall time (exit 0)

Mode `sequential`, workers 1, SHA `90e222635a01e89f095e9a256ac69ecfc759ec4e`, tree `ace7e44cd89194d189a30a0aa6cf513a45b3b87c`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `format-1792781591-43e5b92a`. Dirty tree: `False`.
Command wall time: 0.14s; Cumulative test duration: 0.14s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
