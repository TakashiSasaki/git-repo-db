import pathlib,runpy,sys
target=str(pathlib.Path(sys.argv[1]).resolve())
observed=pathlib.Path(sys.argv[2])
def trace(frame,event,arg):
    if event=="line" and frame.f_code.co_filename==target and "body" in frame.f_locals:
        observed.write_bytes(frame.f_locals["body"])
        sys.settrace(None)
        return None
    return trace
sys.settrace(trace)
runpy.run_path(target,run_name="__main__")
