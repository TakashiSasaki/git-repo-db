import ast,json,pathlib,runpy,sys
target=pathlib.Path(sys.argv[1]).resolve()
statements=sorted(n.lineno for n in ast.walk(ast.parse(target.read_text())) if isinstance(n,ast.Assert))
reached=set()
def observe(frame,event,arg):
    if event=="line" and frame.f_code.co_filename==str(target) and frame.f_lineno in statements:reached.add(frame.f_lineno)
    return observe
try:
    sys.settrace(observe)
    runpy.run_path(str(target),run_name="__main__")
finally:
    sys.settrace(None)
    pathlib.Path(sys.argv[2]).write_text(json.dumps({"assertion_statement_lines":statements,"reached_lines":sorted(reached),"unreached_lines":sorted(set(statements)-reached),"scope":"line entry only; not successful assertion or subexpression coverage"},indent=2)+"\n")
