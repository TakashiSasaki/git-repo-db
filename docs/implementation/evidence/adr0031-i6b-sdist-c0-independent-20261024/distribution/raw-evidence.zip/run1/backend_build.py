import hatchling.build,sys; print(hatchling.build.build_wheel(sys.argv[1]))
