import pathlib,hashlib,json,zipfile,io,datetime,sys
R=pathlib.Path('/workspace/git-repo-db/docs/implementation/evidence/parallel-stack-task-b-20261023');O=pathlib.Path('/workspace/task-b-archive-review');source=R/'raw-evidence.zip';index_path=R/'raw-evidence-index.json';index=json.loads(index_path.read_text());body=source.read_bytes();expected='100838da2f7a10e6dc646d172eec7aa276ad03ea2a9c4d9fb6096150a40ebcf6'
assert len(body)==2190227 and hashlib.sha256(body).hexdigest()==expected;assert index['archive']=={'bytes':len(body),'sha256':expected};archives=[];indices=[]
def verify_index(mapping,files,prefix,label):
 assert isinstance(mapping,dict) and mapping
 names=[]
 for name,meta in mapping.items():
  assert isinstance(meta,dict) and set(meta)>={'bytes','sha256'},(label,name)
  target=prefix+name
  if target not in files:
   candidates=[n for n in files if n.startswith(prefix) and '/' not in n[len(prefix):] and n.endswith('.zip')]
   alternatives=[]
   for n in candidates:
    with zipfile.ZipFile(io.BytesIO(files[n])) as child:
     if name in child.namelist():alternatives.append((n,child.read(name)))
   assert len(alternatives)==1,(label,target,[(n,len(b)) for n,b in alternatives])
   target,raw=alternatives[0]
  else:raw=files[target]
  assert len(raw)==meta['bytes'] and hashlib.sha256(raw).hexdigest()==meta['sha256'],(label,name)
  names.append(name)
 indices.append({'index':label,'entries_verified':len(names),'prefix':prefix})
def inspect(data,label,outer=None):
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  infos=z.infolist();names=[x.filename for x in infos];assert len(names)==len(set(names));assert len(names)<10000;assert sum(x.file_size for x in infos)<512*1024*1024
  assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts and '\\' not in n for n in names)
  assert not z.testzip();files={n:z.read(n) for n in names if not n.endswith('/')}
  archives.append({'archive':label,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'members':len(infos),'unpacked_bytes':sum(x.file_size for x in infos),'unique_safe_member_names_and_crc':True})
  if outer is not None:
   assert set(outer['members'])==set(files) and len(files)==295;verify_index(outer['members'],files,'',label+'::external-index')
  for name,raw in files.items():
   if pathlib.PurePosixPath(name).name in ['artifact-index.json','deliverable-index.json','receipt-index.json','raw-evidence-index.json']:
    obj=json.loads(raw);mapping=obj['members'] if 'members' in obj and isinstance(obj['members'],dict) else obj;prefix=name.rsplit('/',1)[0]+'/' if '/' in name else '';verify_index(mapping,files,prefix,label+'::'+name)
   if name.endswith('.zip'):inspect(raw,label+'::'+name)
  return files
files=inspect(body,'raw-evidence.zip',index)
# The author's archived independent payload is byte-identical to the frozen reviewer directory.
ind=pathlib.Path('/workspace/task-b-independent');frozen=json.loads((ind/'artifact-index.json').read_text());assert hashlib.sha256((ind/'artifact-index.json').read_bytes()).hexdigest()=='85bbfbc102f17b29850b2e58cbdb3d378c3fd8089dc8187b5028181d309b5388'
for n,m in frozen.items():assert files['independent/'+n]==(ind/n).read_bytes()
assert files['independent/artifact-index.json']==(ind/'artifact-index.json').read_bytes()
# Exact conflict patches survived transport into the indexed ZIP.
patches=[]
for n in files:
 if n.startswith('merge-patches/') and n.endswith('.patch'):
  patches.append(n);original=pathlib.Path('/workspace/git-repo-db/docs/implementation/evidence/parallel-stack-task-b-20261023/raw')/n.split('/')[-1]
  # Original files were intentionally moved from staged loose evidence; reconstruct equality from saved resolution-command output.
  commands=json.loads((R/'raw/resolution-commands.json').read_text());matches=[c['stdout'].encode() for c in commands if c['argv']==['git','diff','--binary'] and c.get('cwd','').endswith(n.rsplit('/',1)[1].removeprefix('resolution-').removesuffix('.patch'))]
  assert len(matches)==1 and matches[0]==files[n],n
assert len(patches)==6
assert len(indices)>=4
out={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'PASS','outer_archive':archives[0],'external_index_sha256':hashlib.sha256(index_path.read_bytes()).hexdigest(),'archives':archives,'indices':indices,'frozen_independent_payload_files_verified':len(frozen)+1,'exact_resolution_patches_verified':patches,'scope':'Read-only indexed evidence integrity and transport audit; no product tests, GitHub writes or Release acceptance.'}
(O/'archive-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
