#!/usr/bin/env python3
"""Read-only source/review binding audit; no product tests or SQLite setup."""

import datetime
import collections
import hashlib
import json
import pathlib
import subprocess
import sys

REPO = pathlib.Path('/workspace/git-repo-db')
OUT = pathlib.Path(__file__).resolve().parent
FROZEN = {
    '149': ('ea43a21fca1dbf8fa6dd1c254b28a96d5dd28d00', 'e7ca7e361b8b766f1976a12fc84d5cc50ac32232'),
    '144': ('ededcd83eb2d99a602ba18c8fe3c177125c825ac', '2c721a0e8a58ebe8d1f795da821ea4e317b73e7e'),
    '147': ('e7762952e18061de8c8235beaeddf42f20ad9f5a', '9c220c6606703aa36606896eb52d0a8966914a36'),
}
COMMANDS = []


def run(args, expected=0):
    p = subprocess.run(args, cwd=REPO, capture_output=True)
    row = {'command': args, 'cwd': str(REPO), 'exit_code': p.returncode,
           'stdout_bytes': len(p.stdout), 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
           'stderr': p.stderr.decode()}
    if args[:2] == ['gh', 'api'] and p.returncode == 0:
        api = json.loads(p.stdout)
        row['public_metadata_projection'] = {
            'number': api['number'], 'title': api['title'], 'state': api['state'],
            'draft': api['draft'], 'url': api['html_url'], 'updated_at': api['updated_at'],
            'base': {k: api['base'][k] for k in ['ref', 'sha']},
            'head': {k: api['head'][k] for k in ['ref', 'sha']},
        }
    elif args[:2] != ['git', 'show']:
        row['stdout'] = p.stdout.decode()
    COMMANDS.append(row)
    if p.returncode != expected:
        raise RuntimeError(f'unexpected command exit: {args}: {p.returncode}')
    return p.stdout


def git(*args):
    return run(['git', *args]).decode().strip()


def input_hash(ref, path):
    body = run(['git', 'show', f'{ref}:{path}'])
    return {'source_head': ref, 'source_tree': git('rev-parse', f'{ref}^{{tree}}'),
            'path': path, 'git_blob': git('rev-parse', f'{ref}:{path}'),
            'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def main():
    result = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'kind': 'read_only_source_and_review_audit',
              'product_tests_executed': 0, 'junit': None, 'pytest_journal': None,
              'junit_reason': 'No pytest invocation; Git/API/contract inspection only.',
              'python': sys.version, 'executable': sys.executable,
              'reviews': {}, 'inputs': [], 'comparisons': {}}
    for number, (head, tree) in FROZEN.items():
        api = json.loads(run(['gh', 'api', f'repos/TakashiSasaki/git-repo-db/pulls/{number}']))
        assert api['head']['sha'] == head
        assert git('rev-parse', f'{head}^{{tree}}') == tree
        reviewed = api['base']['sha']
        changed = git('diff', '--name-status', reviewed, head).splitlines()
        assert changed and all(v.startswith('A\tdocs/implementation/evidence/') for v in changed)
        src_equal = git('rev-parse', f'{reviewed}:src') == git('rev-parse', f'{head}:src')
        assert src_equal
        protected_changed = git('diff', '--name-only', reviewed, head, '--',
                                'src', 'tests', 'scripts', '.github', 'pyproject.toml',
                                'uv.lock', 'docs/adr', '.agents')
        assert not protected_changed
        result['reviews'][number] = {
            'url': api['html_url'], 'open': api['state'] == 'open', 'draft': api['draft'],
            'review_publication_head': head, 'review_publication_tree': tree,
            'reviewed_source_head': reviewed,
            'reviewed_source_tree': git('rev-parse', f'{reviewed}^{{tree}}'),
            'base_branch': api['base']['ref'], 'head_branch': api['head']['ref'],
            'publication_diff': changed, 'source_tree_equal': src_equal,
            'protected_inputs_unchanged': True,
        }
        product_paths = git('ls-tree', '-r', '--name-only', head, 'src/repo_catalog').splitlines()
        result['reviews'][number]['product_inventory'] = {
            'paths': product_paths, 'count': len(product_paths),
            'suffix_counts': dict(collections.Counter(path.rsplit('.', 1)[-1] for path in product_paths)),
        }
    # The old I1 review is a sibling of the current implementation lineage, while
    # the preparation report is a sibling of accepted sdist work, not its review.
    for n in ['119', '137']:
        api = json.loads(run(['gh', 'api', f'repos/TakashiSasaki/git-repo-db/pulls/{n}']))
        head = api['head']['sha']
        result['reviews'][n] = {
            'url': api['html_url'], 'review_publication_head': head,
            'review_publication_tree': git('rev-parse', f'{head}^{{tree}}'),
            'base_branch': api['base']['ref'], 'base_sha_api': api['base']['sha'],
            'head_branch': api['head']['ref'],
        }
        for target, (fixed, _) in FROZEN.items():
            p = subprocess.run(['git', 'merge-base', '--is-ancestor', head, fixed], cwd=REPO)
            assert p.returncode in (0, 1)
            COMMANDS.append({'command': ['git', 'merge-base', '--is-ancestor', head, fixed],
                             'cwd': str(REPO), 'exit_code': p.returncode,
                             'stdout': '', 'stderr': ''})
            result['comparisons'][f'{n}_ancestor_of_{target}'] = p.returncode == 0
            result['comparisons'][f'{n}_{target}_merge_base'] = git('merge-base', head, fixed)
    i6 = FROZEN['149'][0]
    for path in ['AGENTS.md', 'docs/adr/README.md', 'docs/adr/0031-generalized-context-resources.md',
                 'docs/adr/0032-environment-sqlite-validation.md',
                 'docs/implementation/context-resource-design-handoff.md',
                 'docs/implementation/adr0031-i6-change-map-and-handoff.md',
                 'docs/implementation/adr0031-i6-wire-admission-exchange.md',
                 'docs/implementation/adr0031-i6-vectors-and-tests.md',
                 'docs/implementation/evidence/adr0031-i6a/originals-binding-independent-20261023/REPORT.md',
                 'docs/implementation/evidence/adr0031-i6a/originals-binding-independent-20261023/findings.json']:
        result['inputs'].append(input_hash(i6, path))
    for path in ['docs/adr/0033-minimal-product-sdist.md',
                 'docs/implementation/evidence/adr0033-hardening-rereview-20261023/REPORT.md',
                 'docs/implementation/evidence/adr0033-hardening-rereview-20261023/findings.json']:
        result['inputs'].append(input_hash(FROZEN['144'][0], path))
    for path in ['docs/implementation/evidence/c0-e1-independent-20261023/REPORT.md',
                 'docs/implementation/evidence/c0-e1-independent-20261023/findings.json']:
        result['inputs'].append(input_hash(FROZEN['147'][0], path))
    for n, path in [('119', 'docs/implementation/evidence/adr0031-i1b-independent-review/REPORT.md'),
                    ('137', 'docs/implementation/evidence/sdist-review-readiness-20261022/README.md')]:
        result['inputs'].append(input_hash(result['reviews'][n]['review_publication_head'], path))
    result['passed_checks'] = ['fresh_fixed_head_api_equality', 'git_tree_equality',
                               'evidence_only_review_diffs', 'review_product_source_tree_equality',
                               'review_protected_input_equality', 'historical_ancestry_recomputed']
    result['exit_code'] = 0
    (OUT / 'binding-results.json').write_text(json.dumps(result, indent=2) + '\n')


try:
    main()
finally:
    (OUT / 'commands.json').write_text(json.dumps(COMMANDS, indent=2) + '\n')
