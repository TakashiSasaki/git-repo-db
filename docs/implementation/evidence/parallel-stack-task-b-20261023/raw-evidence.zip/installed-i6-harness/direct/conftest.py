"""Installed artifact binding for the external pytest process itself."""
import hashlib
import json
import os
import sys
from pathlib import Path

import repo_catalog


def verify_imports(phase, session):
    harness_root = Path(__file__).parent
    assert session.config.inipath == harness_root / "pytest.ini"
    assert session.config.rootpath == harness_root
    root = Path(repo_catalog.__file__).resolve().parent
    assert root.is_relative_to(Path(sys.prefix).resolve()), root
    expected = json.loads((Path(__file__).parent / "artifact-files.json").read_text())
    actual = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in root.rglob("*") if p.is_file() and p.suffix in (".py", ".sql", ".json", ".graphql")}
    assert actual == expected, "installed product files differ from the wheel"
    modules = {name: str(Path(module.__file__).resolve())
               for name, module in sys.modules.items()
               if (name == "repo_catalog" or name.startswith("repo_catalog."))
               and getattr(module, "__file__", None)}
    assert all(Path(path).is_relative_to(root) for path in modules.values()), modules
    support = {name: str(Path(module.__file__).resolve())
               for name, module in sys.modules.items()
               if (name == "tests" or name.startswith("tests.support"))
               and getattr(module, "__file__", None)}
    assert all(Path(path).is_relative_to(harness_root / "tests")
               for path in support.values()), support
    receipt = Path(os.environ["REPO_CATALOG_IMPORT_RECEIPT"])
    records = json.loads(receipt.read_text()) if receipt.exists() else []
    records.append({"phase": phase, "prefix": sys.prefix, "origin": str(root),
                    "product_modules": modules, "installed_files": actual,
                    "test_support_modules": support,
                    "pytest_config": str(session.config.inipath),
                    "pytest_root": str(session.config.rootpath)})
    receipt.write_text(json.dumps(records, indent=2) + "\n")


def pytest_sessionstart(session):
    verify_imports("sessionstart", session)


def pytest_sessionfinish(session, exitstatus):
    verify_imports("sessionfinish", session)
