import sys,os,pathlib,importlib.util,importlib.metadata,json,sqlite3,runpy
source=pathlib.Path.cwd()
assert all(not (source/n).exists() for n in ('.git','docs','tests','scripts'))
assert importlib.util.find_spec('repo_catalog') is None
blocked=[pathlib.Path('/workspace/git-repo-db')]+list(pathlib.Path('/workspace').glob('task-b-sim-*'))+[pathlib.Path('/workspace/task-b-build-i6a'),pathlib.Path('/workspace/task-b-build-sdist')]
def audit(event,args):
 if event in ('open','os.listdir','os.scandir') and args and isinstance(args[0],(str,bytes,os.PathLike)):
  p=pathlib.Path(os.fsdecode(args[0])).absolute()
  if any(p==r or p.is_relative_to(r) for r in blocked):raise RuntimeError('backend attempted original checkout access: '+str(p))
 if event=='subprocess.Popen':raise RuntimeError('backend attempted external process: '+str(args[0]))
sys.addaudithook(audit)
print(json.dumps({'python':sys.executable,'sqlite':sqlite3.sqlite_version,'source_id':sqlite3.connect(':memory:').execute('select sqlite_source_id()').fetchone()[0],'packages':sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions()),'source':str(source),'blocked_checkouts':[str(p) for p in blocked],'git_on_path':False,'product_installed':False}))
sys.argv=['hatchling','build','-t','wheel','-d',sys.argv[1]]
runpy.run_module('hatchling',run_name='__main__')
