import subprocess,json,pathlib,hashlib,datetime,itertools
R=pathlib.Path('/workspace/git-repo-db'); O=R/'docs/implementation/evidence/parallel-stack-task-b-20261023/raw'
commands=[]
def run(args,check=True):
 p=subprocess.run(args,cwd=R,text=True,capture_output=True)
 commands.append({'argv':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 if check and p.returncode: raise RuntimeError(commands[-1])
 return p
pr=json.load(open('/tmp/task-b-pr-pages.json'))
def record(v):
 return {k:v.get(k) for k in ['number','title','state','draft','html_url','created_at','updated_at','closed_at','merged_at']}|{'base':{k:v['base'].get(k) for k in ['ref','sha']},'head':{k:v['head'].get(k) for k in ['ref','sha']}}
snap={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_pull_request_count':len(pr),'all_open':[record(v) for v in pr if v['state']=='open'],'recent_closed_100_plus':[record(v) for v in pr if v['state']=='closed' and v['number']>=100]}
(O/'github-start.json').write_text(json.dumps(snap,indent=2)+'\n')
fixed={133:'f16e5b1713bde9a2f18263a25397c4b450fd5773',149:'ea43a21fca1dbf8fa6dd1c254b28a96d5dd28d00',144:'ededcd83eb2d99a602ba18c8fe3c177125c825ac',147:'e7762952e18061de8c8235beaeddf42f20ad9f5a'}
expected={149:'e7ca7e361b8b766f1976a12fc84d5cc50ac32232',144:'2c721a0e8a58ebe8d1f795da821ea4e317b73e7e',147:'9c220c6606703aa36606896eb52d0a8966914a36'}
allnodes=snap['all_open']+snap['recent_closed_100_plus']
for n in allnodes:
 sha=n['head']['sha']
 if run(['git','cat-file','-e',sha],False).returncode: run(['git','fetch','origin',sha])
 n['head']['tree']=run(['git','rev-parse',sha+'^{tree}']).stdout.strip()
 n['actual_merge_base']=run(['git','merge-base',n['base']['sha'],sha]).stdout.strip()
 n['base_is_ancestor']=run(['git','merge-base','--is-ancestor',n['base']['sha'],sha],False).returncode==0
 n['parents']=run(['git','show','-s','--format=%P',sha]).stdout.strip().split()
 if n['number'] in fixed:
  assert sha==fixed[n['number']],n
  if n['number'] in expected: assert n['head']['tree']==expected[n['number']],n
anc={}
for a,b in itertools.permutations(allnodes,2):
 anc[a['number'],b['number']]=run(['git','merge-base','--is-ancestor',a['head']['sha'],b['head']['sha']],False).returncode==0
edges=[]
for (a,b),yes in anc.items():
 if yes and not any(anc.get((a,c['number'])) and anc.get((c['number'],b)) for c in allnodes if c['number'] not in [a,b]): edges.append([a,b])
snap['actual_ancestry_reduced_edges']=edges
base=fixed[133]; delta={}
for n in [149,144,147]: delta[n]=set(run(['git','diff','--name-only',base,fixed[n]]).stdout.splitlines())
shared={f'{a}-{b}':sorted(delta[a]&delta[b]) for a,b in itertools.combinations(delta,2)}
union=sorted({p for files in shared.values() for p in files})
summary={'fixed':{str(n):{'head':s,'tree':run(['git','rev-parse',s+'^{tree}']).stdout.strip()} for n,s in fixed.items()},'pair_merge_bases':{f'{a}-{b}':run(['git','merge-base',fixed[a],fixed[b]]).stdout.strip() for a,b in itertools.combinations(fixed,2)},'delta_files':{str(n):sorted(v) for n,v in delta.items()},'shared_files_by_pair':shared,'shared_union':union,'shared_union_count':len(union),'all_three_shared':sorted(set.intersection(*delta.values()))}
(O/'github-start.json').write_text(json.dumps(snap,indent=2)+'\n')
(O/'fixed-overlap.json').write_text(json.dumps(summary,indent=2)+'\n')
(O/'graph-commands.json').write_text(json.dumps({'started_snapshot_sha256':hashlib.sha256(pathlib.Path('/tmp/task-b-pr-pages.json').read_bytes()).hexdigest(),'commands':commands},indent=2)+'\n')
print(json.dumps({'open':len(snap['all_open']),'recent_closed':len(snap['recent_closed_100_plus']),'edges':edges,'fixed':summary['fixed'],'merge_bases':summary['pair_merge_bases'],'shared':shared,'union_count':len(union)},indent=2))
