import subprocess,pathlib,json,sys,hashlib,tarfile,os,importlib.util
R=pathlib.Path('/workspace/git-repo-db');out=pathlib.Path('/workspace/task-b-builds');out.mkdir(exist_ok=True)
candidate=pathlib.Path('/workspace/task-b-sim-i6a-sdist-c0');py=str(candidate/'.venv/bin/python')
mod=importlib.util.spec_from_file_location('contract',candidate/'scripts/check_sdist_contract.py');contract=importlib.util.module_from_spec(mod);mod.loader.exec_module(contract)
records=[];results={}
def run(label,args,cwd):
 p=subprocess.run(args,cwd=cwd,text=True,capture_output=True,env=os.environ|{'UV_CACHE_DIR':'/workspace/task-b-uv-cache','UV_PYTHON_DOWNLOADS':'never'})
 (out/(label+'.log')).write_text(p.stdout+p.stderr);records.append({'name':label,'argv':args,'cwd':str(cwd),'exit_code':p.returncode});(out/'processes.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0,p.stderr
for label,head in [('i6a','ea43a21fca1dbf8fa6dd1c254b28a96d5dd28d00'),('sdist','ededcd83eb2d99a602ba18c8fe3c177125c825ac'),('combined','a7825249e0722053a66919d47ad92662854c856c')]:
 w=pathlib.Path('/workspace/task-b-build-'+label) if label!='combined' else candidate
 if label!='combined':run(label+'-worktree',['git','worktree','add','--detach',str(w),head],R)
 build=out/label;build.mkdir()
 run(label+'-build',[py,'-m','hatchling','build','-t','sdist','-t','wheel','-d',str(build)],w)
 archive=next(build.glob('*.tar.gz'));wheel=next(build.glob('*.whl'))
 with tarfile.open(archive) as t:members=[m for m in t.getmembers() if m.isfile()]
 info={'source_head':head,'source_tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=R,text=True).strip(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'compressed_bytes':archive.stat().st_size,'file_count':len(members),'unpacked_file_bytes':sum(m.size for m in members),'top_level_counts':{}}
 for m in members:
  p=m.name.split('/')[1];info['top_level_counts'][p]=info['top_level_counts'].get(p,0)+1
 (out/(label+'-members.json')).write_text(json.dumps([{'name':m.name,'bytes':m.size} for m in members],indent=2)+'\n')
 if label in ('sdist','combined'):
  result=contract.check_sdist(archive,w); (out/(label+'-contract.json')).write_text(json.dumps(result,indent=2)+'\n');info['contract']={k:v for k,v in result.items() if k not in ('members','source_files')}
  if label=='combined':
   extract=out/'from-sdist';extract.mkdir()
   with tarfile.open(archive) as t:t.extractall(extract,filter='data')
   source=next(extract.iterdir());derived=out/'derived';derived.mkdir()
   run('combined-derived-build',[py,'-m','hatchling','build','-t','wheel','-d',str(derived)],source)
   eq=contract.compare_wheels(wheel,next(derived.glob('*.whl')),sdist_metadata=result['members']['PKG-INFO']['sha256']);(out/'combined-equivalence.json').write_text(json.dumps(eq,indent=2)+'\n')
   info['wheel_equivalence']={k:v for k,v in eq.items() if k!='members'}
 results[label]=info;(out/'measurements.json').write_text(json.dumps(results,indent=2)+'\n')
 print(label,json.dumps(info),flush=True)
