import sys,pathlib,subprocess,json,hashlib,datetime,os,time
cwd=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);label=sys.argv[3];args=sys.argv[4:]
out.mkdir(parents=True,exist_ok=True)
def git(*a):return subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
paths=subprocess.check_output(['git','ls-files','-z','--','src','tests','scripts','.github','pyproject.toml','uv.lock'],cwd=cwd).decode().split('\0')[:-1]
inputs={p:hashlib.sha256((cwd/p).read_bytes()).hexdigest() for p in paths if (cwd/p).is_file()}
manifest=json.dumps(inputs,sort_keys=True,separators=(',',':')).encode(); (out/(label+'.inputs.json')).write_bytes(manifest+b'\n')
meta={'cwd':str(cwd),'argv':args,'source_head':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),'source_status':git('status','--porcelain'),'input_sha256':hashlib.sha256(manifest).hexdigest(),'runner_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
env=os.environ.copy()
# All validation uses the selected Python, with credentials absent from children.
for k in ['GH_TOKEN','GITHUB_TOKEN']:env.pop(k,None)
t=time.monotonic()
with (out/(label+'.log')).open('wb') as f:p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
meta|={'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log_sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()}
(out/(label+'.execution.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta)); print((out/(label+'.log')).read_text()[-4000:]);sys.exit(p.returncode)
