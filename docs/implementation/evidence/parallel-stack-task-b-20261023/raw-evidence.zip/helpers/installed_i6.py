import pathlib,subprocess,json,sys,os,shutil,hashlib,zipfile,importlib.util
src=pathlib.Path('/workspace/task-b-sim-i6a-sdist-c0');out=pathlib.Path('/workspace/task-b-installed-i6-final');out.mkdir(exist_ok=False)
sys.path.insert(0,str(src));from scripts.installed_test_harness import IMPORT_CONTRACT
records=[]
def run(name,args,cwd,env):
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit_code':p.returncode});(out/'processes.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode
selected=['tests/unit/'+n+'.py' for n in ['test_context_admission','test_context_admission_bounds_i6a','test_context_capability_preflight','test_context_coordinator_admission','test_context_fences_i6a','test_context_oid_admission_i6a','test_context_refusal_order_i6a','test_transfer_originals']]+['tests/integration/i6a']
wheel=next(pathlib.Path('/workspace/task-b-builds/combined').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:expected={n.removeprefix('repo_catalog/'):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('repo_catalog/') and pathlib.Path(n).suffix in ('.py','.sql','.json','.graphql')}
assert len(expected)==158
for label in ['direct','sdist']:
 w=out/(label+'-outside');w.mkdir();shutil.copytree(src/'tests',w/'tests',ignore=shutil.ignore_patterns('__pycache__','*.pyc'));(w/'scripts').mkdir()
 (w/'scripts/__init__.py').write_text('')
 shutil.copyfile(src/'scripts/ci_journal.py',w/'scripts/ci_journal.py')
 binding={str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()};(out/(label+'-test-support.json')).write_text(json.dumps(binding,indent=2)+'\n')
 (w/'pytest.ini').write_text('[pytest]\naddopts = --strict-markers\npythonpath =\n')
 (w/'artifact-files.json').write_text(json.dumps(expected,indent=2)+'\n')
 probe=IMPORT_CONTRACT.replace('(".py", ".sql", ".json")','(".py", ".sql", ".json", ".graphql")')
 assert probe!=IMPORT_CONTRACT
 (w/'conftest.py').write_text(probe)
 py=pathlib.Path('/workspace/task-b-installed-i5')/(label+'-venv')/'bin/python'
 env=os.environ|{'UV_CACHE_DIR':'/workspace/task-b-uv-cache','UV_PYTHON_DOWNLOADS':'never','PATH':str(py.parent)+os.pathsep+os.environ['PATH'],'REPO_CATALOG_IMPORT_RECEIPT':str(out/(label+'-imports.json')),'GIT_ALLOW_PROTOCOL':'file'}
 for n in ['GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME']:env.pop(n,None)
 args=[py,'-m','pytest',*selected,'-q','-c',w/'pytest.ini','--rootdir='+str(w),'--confcutdir='+str(w)]
 assert run(label+'-collect',args+['--collect-only'],w,env)==0
 assert run(label+'-i6',args+['-o','junit_family=xunit1','--junitxml='+str(out/(label+'.xml')),'--journal='+str(out/(label+'.jsonl'))],w,env)==0
 assert run(label+'-runtime',[py,src/'scripts/ci_python_runtime.py','probe',out/(label+'-runtime.json')],w,env)==0
 print(label,'I6-focused installed PASS',flush=True)
