import sys,pathlib,json,subprocess,os,hashlib,zipfile
src=pathlib.Path('/workspace/task-b-sim-i6a-sdist-c0');out=pathlib.Path('/workspace/task-b-backend-only');out.mkdir(exist_ok=False);venv=out/'venv';records=[]
def run(label,args,cwd,env=None):
 p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,text=True,capture_output=True);(out/(label+'.log')).write_text(p.stdout+p.stderr);records.append({'name':label,'argv':list(map(str,args)),'cwd':str(cwd),'exit_code':p.returncode});(out/'processes.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0,p.stderr
run('venv',[sys.executable,'-m','venv','--without-pip',venv],out)
m=json.load(open('/workspace/task-b-wheelhouse/manifest.json'));names={'hatchling','packaging','pathspec','pluggy','trove-classifiers'};entries=[p for p in m['wheels'] if p['name'] in names];assert len(entries)==5
req=out/'requirements.txt';req.write_text('\n'.join('/workspace/task-b-wheelhouse/'+p['file']+' --hash=sha256:'+p['sha256'] for p in entries)+'\n')
run('install',['uv','pip','install','--python',venv/'bin/python','--offline','--no-index','--no-deps','--require-hashes','-r',req],out,os.environ|{'UV_CACHE_DIR':'/workspace/task-b-uv-cache','UV_PYTHON_DOWNLOADS':'never'})
probe=out/'probe.py';probe.write_text('''import sys,os,pathlib,importlib.util,importlib.metadata,json,sqlite3,runpy
source=pathlib.Path.cwd()
assert all(not (source/n).exists() for n in ('.git','docs','tests','scripts'))
assert importlib.util.find_spec('repo_catalog') is None
blocked=[pathlib.Path('/workspace/git-repo-db')]+list(pathlib.Path('/workspace').glob('task-b-sim-*'))+[pathlib.Path('/workspace/task-b-build-i6a'),pathlib.Path('/workspace/task-b-build-sdist')]
def audit(event,args):
 if event in ('open','os.listdir','os.scandir') and args and isinstance(args[0],(str,bytes,os.PathLike)):
  p=pathlib.Path(os.fsdecode(args[0])).absolute()
  if any(p==r or p.is_relative_to(r) for r in blocked):raise RuntimeError('backend attempted original checkout access: '+str(p))
 if event=='subprocess.Popen':raise RuntimeError('backend attempted external process: '+str(args[0]))
sys.addaudithook(audit)
print(json.dumps({'python':sys.executable,'sqlite':sqlite3.sqlite_version,'source_id':sqlite3.connect(':memory:').execute('select sqlite_source_id()').fetchone()[0],'packages':sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions()),'source':str(source),'blocked_checkouts':[str(p) for p in blocked],'git_on_path':False,'product_installed':False}))
sys.argv=['hatchling','build','-t','wheel','-d',sys.argv[1]]
runpy.run_module('hatchling',run_name='__main__')
''')
source=next(pathlib.Path('/workspace/task-b-builds/from-sdist').iterdir());built=out/'built';built.mkdir()
env={k:v for k,v in os.environ.items() if k not in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME')};env['PATH']=str(venv/'bin')
run('backend-isolated-build',[venv/'bin/python','-I',probe,built],source,env)
sys.path.insert(0,str(src));from scripts.check_sdist_contract import compare_wheels
result=compare_wheels(next(pathlib.Path('/workspace/task-b-builds/combined').glob('*.whl')),next(built.glob('*.whl')));(out/'equivalence.json').write_text(json.dumps(result,indent=2)+'\n');print('backend-only isolated build and full wheel/RECORD equality PASS')
