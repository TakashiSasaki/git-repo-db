import subprocess,pathlib,json,itertools,os,hashlib
R=pathlib.Path('/workspace/git-repo-db'); O=R/'docs/implementation/evidence/parallel-stack-task-b-20261023/raw'
heads={'i6a':'ea43a21fca1dbf8fa6dd1c254b28a96d5dd28d00','sdist':'ededcd83eb2d99a602ba18c8fe3c177125c825ac','c0':'e7762952e18061de8c8235beaeddf42f20ad9f5a'}
base='f16e5b1713bde9a2f18263a25397c4b450fd5773'
env=os.environ|{'GIT_AUTHOR_NAME':'Audit simulation','GIT_AUTHOR_EMAIL':'audit@example.invalid','GIT_COMMITTER_NAME':'Audit simulation','GIT_COMMITTER_EMAIL':'audit@example.invalid','GIT_AUTHOR_DATE':'2026-10-23T11:00:00+0000','GIT_COMMITTER_DATE':'2026-10-23T11:00:00+0000'}
cmds=[]
def run(args,cwd=R,input=None):
 p=subprocess.run(args,cwd=cwd,input=input,text=True,capture_output=True,env=env)
 cmds.append({'argv':args,'cwd':str(cwd),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 return p
results=[]
for order in itertools.permutations(heads):
 current=base; steps=[]
 for label in order:
  h=heads[label]; mb=run(['git','merge-base',current,h]).stdout.strip()
  p=run(['git','merge-tree','--write-tree',current,h]); tree=p.stdout.splitlines()[0]
  step={'target':current,'feature':h,'merge_base':mb,'exit_code':p.returncode,'unresolved_tree':tree,'output':p.stdout}
  if p.returncode not in (0,1): raise RuntimeError(p.stderr)
  if p.returncode==1:
   # materialize conflict tree as forensic scratch, never publish this commit/ref
   scratch=pathlib.Path('/workspace/task-b-sim-'+ '-'.join(order))
   synthetic=run(['git','commit-tree',tree,'-p',current,'-p',h],input='Unresolved audit simulation only\n').stdout.strip()
   assert run(['git','worktree','add','--detach',str(scratch),synthetic]).returncode==0
   names=[line.split('\t')[-1] for line in p.stdout.splitlines()[1:] if '\t' in line and line.split()[0].isdigit()==False and line.startswith('100')]
   conflicts=[]
   for line in p.stdout.splitlines():
    if line.startswith('CONFLICT'):
     conflicts.append(line)
   step['conflicts']=conflicts
   step['scratch']=str(scratch)
   step['synthetic_unresolved_commit']=synthetic
   steps.append(step); break
  current=run(['git','commit-tree',tree,'-p',current,'-p',h],input='Clean audit simulation only\n').stdout.strip()
  step['candidate_commit']=current;step['candidate_tree']=tree
  steps.append(step)
 results.append({'order':order,'steps':steps,'completed':len(steps)==3 and steps[-1]['exit_code']==0})
(O/'merge-simulations.json').write_text(json.dumps(results,indent=2)+'\n')
(O/'merge-commands.json').write_text(json.dumps(cmds,indent=2)+'\n')
for r in results:
 print(r['order'],[(s['exit_code'],s.get('candidate_tree'),s.get('conflicts')) for s in r['steps']])
