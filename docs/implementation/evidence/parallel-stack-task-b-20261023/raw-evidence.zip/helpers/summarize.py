import pathlib,json,subprocess,collections,hashlib
r=pathlib.Path('/workspace/task-b-validation'); allnodes=[s for s in (r/'complete-inventory.log').read_text().splitlines() if s.startswith('tests/') and '::' in s];assert len(allnodes)==len(set(allnodes))==6231
special={'tests/live/test_smoke.py::test_selected_repository','tests/e2e/test_github_sync.py::test_nested_pagination_stress_workload'};assert special<=set(allnodes)
executed=set((r/'focused.nodes.txt').read_text().splitlines());checks={}
# Reconcile both installed I6 and the directly affected shared packaging file.
for label in ['direct','sdist']:
 p=pathlib.Path('/workspace/task-b-installed-i6-final');nodes=[s for s in (p/(label+'-collect.log')).read_text().splitlines() if s.startswith('tests/') and '::' in s];(p/(label+'.nodes.txt')).write_text('\n'.join(nodes)+'\n')
 checks[label]={'nodes':len(nodes),'matches_source_selected_subset':set(nodes)<=executed};assert len(nodes)==290 and checks[label]['matches_source_selected_subset']
 meta=json.loads((r/'installed-i6-final.execution.json').read_text());(p/(label+'.execution.json')).write_text(json.dumps(meta|{'head':meta['source_head'],'tree':meta['source_tree'],'exit_code':0,'binding':'Parent wrapper and per-stage processes.json both confirm successful test/collection/runtime exits.'},indent=2)+'\n')
 args=['python','.agents/skills/efficient-repository-investigation/scripts/summarize_pytest.py','--nodes',str(p/(label+'.nodes.txt')),'--junit',str(p/(label+'.xml')),'--journal',str(p/(label+'.jsonl')),'--execution',str(p/(label+'.execution.json'))]
 v=subprocess.run(args,capture_output=True,text=True);(p/(label+'-reconciliation.json')).write_text(v.stdout);assert v.returncode==0,(v.stdout,v.stderr)
p=r;nodes=['tests/packaging/test_p1_distribution.py::test_p1_packaged_ddl_outside_checkout[wheel]','tests/packaging/test_p1_distribution.py::test_p1_packaged_ddl_outside_checkout[sdist-wheel]'];(p/'shared-p1.nodes.txt').write_text('\n'.join(nodes)+'\n');executed.update(nodes)
args=['python','.agents/skills/efficient-repository-investigation/scripts/summarize_pytest.py','--nodes',str(p/'shared-p1.nodes.txt'),'--junit',str(p/'shared-p1.xml'),'--journal',str(p/'shared-p1.jsonl'),'--execution',str(p/'shared-p1-packaging.execution.json')]
v=subprocess.run(args,capture_output=True,text=True);(p/'shared-p1-reconciliation.json').write_text(v.stdout);assert v.returncode==0,(v.stdout,v.stderr)
ordinary=set(allnodes)-special;unexecuted=ordinary-executed
(r/'complete.nodes.txt').write_text('\n'.join(allnodes)+'\n');(r/'source-unexecuted.nodes.txt').write_text('\n'.join(sorted(unexecuted))+'\n')
summary={'source_head':'a7825249e0722053a66919d47ad92662854c856c','source_tree':'2c61c7d79bf9a95c4f04ccdbda8fae1fe15d5491','all_nodes':len(allnodes),'ordinary_nodes':len(ordinary),'source_executed_passed':len(executed),'source_unexecuted_ordinary':len(unexecuted),'special_unexecuted':sorted(special),'source_tests_by_file':dict(collections.Counter(n.split('::')[0] for n in executed)),'installed_each':{'I6_focused':290,'I4':217,'I5':29,'original_Access_smoke_exit':1,'original_Access_smoke_first_refusal':'PERMISSION_DENIED'},'installed_I6_subset_of_source_focus':checks,'no_full_release_acceptance':True,'note':'Installed repeats overlap source focus. I4/I5 copied-module names remain separate and are not aggregated as unique source coverage.'}
(r/'coverage.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
