"""Frozen-tree CI routing probes; disposable commits are never pushed."""
import base64,datetime,hashlib,importlib.util,io,json,os,re,sqlite3,subprocess,sys,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
import yaml
ROOT=Path('/workspace/task-b-ci-combined'); SRC=Path('/workspace/task-b-ci-combined-source'); log=[]; journal=[]; cases=[]
SNAPSHOTS={'combined':'a7825249e0722053a66919d47ad92662854c856c'}
PATHS=['src/repo_catalog/domain/context_admission.py','src/repo_catalog/adapters/sqlite/context_admission.py','tests/integration/i6a/test_admission.py','tests/integration/i6a/test_originals_revalidation.py','tests/unit/test_context_admission.py','tests/unit/test_context_admission_bounds_i6a.py','tests/unit/test_context_fences_i6a.py','tests/unit/test_context_oid_admission_i6a.py','tests/unit/test_context_refusal_order_i6a.py','tests/unit/test_i6a_regression_bindings.py','tests/support/context_admission.py','tests/support/i6a.py','src/repo_catalog/adapters/sqlite/access_schema.py','tests/integration/i5/test_admission.py','README.md']
def command(*args,input=None,env=None):
 p=subprocess.run(args,cwd=SRC,input=input,capture_output=True,env=env); log.append({'argv':list(args),'stdin_sha256':hashlib.sha256(input).hexdigest() if input else None,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}); p.check_returncode(); return p.stdout.decode().strip()
def sha(b): return hashlib.sha256(b).hexdigest()
def match(pat,path):
 # GitHub path patterns used here: literal, *, **. No negations or classes.
 assert not any(c in pat for c in '!?+[]')
 result=''; i=0
 while i<len(pat):
  if pat[i:i+3]=='**/': result+='(?:.*/)?'; i+=3
  elif pat[i:i+2]=='**': result+='.*'; i+=2
  elif pat[i]=='*': result+='[^/]*'; i+=1
  else: result+=re.escape(pat[i]); i+=1
 return re.fullmatch(result,path) is not None
def workflows(path):
 result={}
 for f in sorted((SRC/'.github/workflows').glob('*.yml')):
  content=yaml.load(f.read_text(),Loader=yaml.BaseLoader); events=content['on']; pr=events.get('pull_request','ABSENT')
  result[f.name]={'pull_request_selected':pr!='ABSENT' and (not pr or 'paths' not in pr or any(match(p,path) for p in pr['paths'])),'patterns':[] if not pr or pr=='ABSENT' else pr.get('paths',[])}
 return result
for pr,source in SNAPSHOTS.items():
 command('git','checkout','--detach',source)
 spec=importlib.util.spec_from_file_location('ci_plan_'+pr,SRC/'scripts/ci_plan.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
 for path in PATHS:
  if not (SRC/path).exists():
   cases.append({'snapshot_pr':pr,'source_head':source,'source_tree':command('git','rev-parse',source+'^{tree}'),'path':path,'status':'not_applicable_path_absent'}); continue
  started=time.monotonic(); node=f'ci-routing::{pr}::{path}'; journal.append({'event':'start','nodeid':node})
  data=(SRC/path).read_bytes(); updated=data+b'\n'+(b'CI routing audit single-file prose probe.\n' if path.endswith('.md') else b'# CI routing audit single-file probe.\n')
  index=ROOT/'probe-index'; index.unlink(missing_ok=True); env=dict(os.environ,GIT_INDEX_FILE=str(index))
  command('git','read-tree',source,env=env); blob=command('git','hash-object','-w','--stdin',input=updated); command('git','update-index','--add','--cacheinfo','100644,'+blob+','+path,env=env); tree=command('git','write-tree',env=env); candidate=command('git','commit-tree',tree,'-p',source,input=b'Disposable CI single-file routing probe\n')
  command('git','checkout','--detach',candidate)
  record={'snapshot_pr':pr,'source_head':source,'source_tree':command('git','rev-parse',source+'^{tree}'),'path':path,'original_sha256':sha(data),'mutated_sha256':sha(updated),'candidate_head':candidate,'candidate_tree':tree,'workflows':workflows(path),'status':'running','plans':{}}
  try:
   assert command('git','diff','--name-only',source,candidate)==path
   for mode in ['development','release']:
    context={'event':'pull_request','base_sha':source,'feature_sha':candidate,'tested_sha':candidate,'mode':mode,'full':mode=='release'}
    p=module.make_plan(context,root=SRC)
    (ROOT/f'plan-{pr}-{len(cases):02d}-{mode}.json').write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
    record['plans'][mode]={'acceptance_input_hash':p['acceptance_input_hash'],'acceptance_files_count':len(p['acceptance_files']),'required_files_count':len(p['required_files']),'required_target':path in p['required_files'],'selected_files_count':len(p['selected_files']),'target_selected':path in p['selected_files'],'full':p['full'],'lanes':{k:v['disposition'] for k,v in p['lanes'].items()},'fallback_reasons':p['fallback_reasons'],'preparation':p['preparation']}
    assert record['workflows']['tests.yml']['pull_request_selected']
    if mode=='release':
     assert p['full'] and set(p['selected_files'])==set(p['acceptance_files']) and not p['unexecuted_files']
    else:
     assert not p['full'] and not p['selected_files']
     if path!='README.md': assert p['lanes']['static']['disposition']=='selected'
    if path.startswith('src/') or path.startswith('tests/support/'):
     assert p['required_files']==p['acceptance_files']
    if path.startswith('tests/unit/') or path.startswith('tests/integration/'):
     assert path in p['required_files']
   record['status']='passed'
  except Exception as exc:
   record['status']='failed'; record['error']=traceback.format_exc()
  record['seconds']=time.monotonic()-started; cases.append(record); journal.append({'event':'finish','nodeid':node,'status':record['status']})
  command('git','checkout','--detach',source)

(ROOT/'commands.json').write_text(json.dumps(log,indent=2)+'\n')
(ROOT/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(ROOT/'journal.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in journal))
executed=[c for c in cases if c['status']!='not_applicable_path_absent'];failed=[c for c in executed if c['status']!='passed']
suite=ET.Element('testsuite',name='combined_ci_routing',tests=str(len(executed)),failures=str(len(failed)),errors='0',skipped='0')
for c in executed:
 case=ET.SubElement(suite,'testcase',classname='ci_routing.combined',name=c['path'])
 if c['status']!='passed':ET.SubElement(case,'failure').text=c['error']
ET.ElementTree(suite).write(ROOT/'junit.xml',encoding='utf-8',xml_declaration=True)
print(json.dumps({'executed':len(executed),'failed':len(failed),'not_applicable':len(cases)-len(executed)}));sys.exit(bool(failed))
