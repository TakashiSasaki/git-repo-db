exec(open('/workspace/task-b-tools/simulate.py').read().split('results=[]')[0])
results=json.loads((O/'merge-simulations.json').read_text()); resolved=[]
def split_block(raw):
 pre,rest=raw.split('<<<<<<< ',1); _,rest=rest.split('\n',1); a,rest=rest.split('=======\n',1); b,rest=rest.split('>>>>>>> ',1); _,post=rest.split('\n',1)
 return pre,a,b,post
for r in results:
 last=r['steps'][-1]; w=pathlib.Path(last['scratch'])
 for rel in ['tests/packaging/test_p1_distribution.py','.agents/skills/ci-final-tree-verification/SKILL.md']:
  path=w/rel;pre,a,b,post=split_block(path.read_text())
  if rel.endswith('.py'):
   replacement='from scripts.check_sdist_contract import check_sdist, compare_wheels, save\nfrom scripts.installed_test_harness import stage_support\n'
  else:
   i6=a if '## Pytest subtest' in a else b; sd=b if i6==a else a
   replacement=i6+'\n'+sd
  path.write_text(pre+replacement+post)
  assert '<<<<<<<' not in path.read_text()
 run(['git','diff','--binary'],cwd=w)
 patch=cmds[-1]['stdout']; (O/('resolution-'+ '-'.join(r['order'])+'.patch')).write_text(patch)
 assert run(['git','add','--','tests/packaging/test_p1_distribution.py','.agents/skills/ci-final-tree-verification/SKILL.md'],cwd=w).returncode==0
 tree=run(['git','write-tree'],cwd=w).stdout.strip()
 current=run(['git','commit-tree',tree,'-p',last['target'],'-p',last['feature']],input='Audit-only union resolution; preserve both parent changes\n').stdout.strip()
 for label in r['order'][len(r['steps']):]:
  h=heads[label];p=run(['git','merge-tree','--write-tree',current,h]); assert p.returncode==0,p.stdout
  tree=p.stdout.splitlines()[0];current=run(['git','commit-tree',tree,'-p',current,'-p',h],input='Audit-only clean subsequent merge\n').stdout.strip()
 # detached scratch checkout makes materialized and tested tree coherent
 assert run(['git','checkout','--detach',current],cwd=w).returncode==0
 assert run(['git','status','--porcelain'],cwd=w).stdout==''
 resolved.append({'order':r['order'],'hypothesis':'union both imports and append both independent skill lessons; preserve all other auto-merged hunks','candidate_commit':current,'candidate_tree':tree,'scratch':str(w),'product_delta_vs_i6a':run(['git','diff','--name-only',heads['i6a'],current,'--','src']).stdout.splitlines()})
(O/'resolved-candidates.json').write_text(json.dumps(resolved,indent=2)+'\n')
(O/'resolution-commands.json').write_text(json.dumps(cmds,indent=2)+'\n')
print(json.dumps(resolved,indent=2))
