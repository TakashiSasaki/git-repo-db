from pathlib import Path
import json,zipfile,hashlib,shutil
R=Path('/workspace/git-repo-db');E=R/'docs/implementation/evidence/parallel-stack-task-b-20261023';files={}
def add(base,label,exclude=()):
 base=Path(base)
 for p in base.rglob('*'):
  rel=p.relative_to(base)
  if not p.is_file() or any(part in exclude for part in rel.parts):continue
  if p.suffix in {'.pyc','.whl','.tar','.gz','.sqlite3','.db'}:continue
  if any(part.endswith('-venv') or part=='venv' for part in rel.parts):continue
  name=label+'/'+str(rel)
  assert name not in files
  files[name]=p.read_bytes()
for p in (E/'raw').glob('resolution-*.patch'):files['merge-patches/'+p.name]=p.read_bytes()
add('/workspace/task-b-tools','helpers',exclude=('__pycache__',))
add('/workspace/task-b-validation','validation')
add('/workspace/task-b-document-checks','document-checks')
add('/workspace/task-b-installed-i5','installed-i5',exclude=('source','from-sdist','outside','__pycache__'))
add('/workspace/task-b-installed-i6-final','installed-i6-final',exclude=('direct-outside','sdist-outside','__pycache__'))
for label in ['direct','sdist']:
 root=Path('/workspace/task-b-installed-i6-final')/(label+'-outside')
 for n in ['conftest.py','pytest.ini','artifact-files.json']:
  p=root/n;files['installed-i6-harness/'+label+'/'+n]=p.read_bytes()
add('/workspace/task-b-installed-i6-corrected','installed-i6-missing-dependency',exclude=('direct-outside','sdist-outside','__pycache__'))
add('/workspace/task-b-backend-only','backend-only',exclude=('venv','built','__pycache__'))
add('/workspace/task-b-ci-combined','combined-routing')
# Original subaudit archive/index retained intact; original helper code is inside.
for n in ['raw-evidence.zip','artifact-index.json']:
 files['ci-subaudit/'+n]=(Path('/workspace/task-b-ci')/n).read_bytes()
for n in json.loads(Path('/workspace/task-b-design/deliverable-index.json').read_text()):files['design-subaudit/'+n]=(Path('/workspace/task-b-design')/n).read_bytes()
files['design-subaudit/deliverable-index.json']=Path('/workspace/task-b-design/deliverable-index.json').read_bytes()
add('/workspace/task-b-independent','independent',exclude=('__pycache__',))
# Keep historical proof compressed member and decompressed observed log distinct.
files['wheelhouse/manifest.json']=Path('/workspace/task-b-wheelhouse/manifest.json').read_bytes()
for p in Path('/workspace/task-b-builds').glob('*'):
 if p.is_file() and p.suffix in ('.json','.log'):files['builds/'+p.name]=p.read_bytes()
index={'format':'task-b-raw-evidence-v1','members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in sorted(files.items())},'omitted':'Product wheels, source tarballs/trees, venvs, temporary databases/caches are intentionally not published. Their hashes/rosters and original frozen Git inputs remain in the receipts.'}
with zipfile.ZipFile(E/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,v in sorted(files.items()):
  i=zipfile.ZipInfo(n,date_time=(2026,10,23,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,v)
index['archive']={'bytes':(E/'raw-evidence.zip').stat().st_size,'sha256':hashlib.sha256((E/'raw-evidence.zip').read_bytes()).hexdigest()}
(E/'raw-evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(E/'raw-evidence.zip') as z:
 assert set(z.namelist())==set(index['members'])
 for n,m in index['members'].items():assert len(z.read(n))==m['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
print(json.dumps({'members':len(files),'archive':index['archive']}))
