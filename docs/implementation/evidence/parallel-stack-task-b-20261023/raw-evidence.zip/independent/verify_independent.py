import subprocess,pathlib,json,hashlib,itertools,os,sys,sqlite3,datetime,collections,xml.etree.ElementTree as ET
R=pathlib.Path('/workspace/git-repo-db');O=pathlib.Path('/workspace/task-b-independent');raw=R/'docs/implementation/evidence/parallel-stack-task-b-20261023/raw';commands=[];checks={}
env=os.environ|{'GIT_AUTHOR_NAME':'Independent audit','GIT_AUTHOR_EMAIL':'audit@example.invalid','GIT_COMMITTER_NAME':'Independent audit','GIT_COMMITTER_EMAIL':'audit@example.invalid','GIT_AUTHOR_DATE':'2026-10-23T12:00:00+0000','GIT_COMMITTER_DATE':'2026-10-23T12:00:00+0000'}
def run(args,*,text=True,data=None,index=None):
 e=env.copy()
 if index:e['GIT_INDEX_FILE']=str(index)
 p=subprocess.run(args,cwd=R,env=e,input=data,capture_output=True,text=text)
 def present(v):return v if isinstance(v,str) else {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
 commands.append({'argv':args,'exit_code':p.returncode,'stdout':present(p.stdout),'stderr':present(p.stderr)})
 return p
def git(*args,**kwargs):
 p=run(['git',*args],**kwargs);assert p.returncode==0,commands[-1];return p.stdout.strip()
base='f16e5b1713bde9a2f18263a25397c4b450fd5773';heads={'i6a':'ea43a21fca1dbf8fa6dd1c254b28a96d5dd28d00','sdist':'ededcd83eb2d99a602ba18c8fe3c177125c825ac','c0':'e7762952e18061de8c8235beaeddf42f20ad9f5a'};trees={'i6a':'e7ca7e361b8b766f1976a12fc84d5cc50ac32232','sdist':'2c721a0e8a58ebe8d1f795da821ea4e317b73e7e','c0':'9c220c6606703aa36606896eb52d0a8966914a36'}
for label,sha in heads.items():assert git('rev-parse',sha+'^{tree}')==trees[label]
checks['fixed_git_trees_match']=True
for a,b in itertools.combinations([base,*heads.values()],2):assert git('merge-base',a,b)==base
checks['all_pair_merge_bases_equal_fixed_133']=True
files={label:set(git('diff','--name-only',base,sha).splitlines()) for label,sha in heads.items()}
shared={f'{a}-{b}':sorted(files[a]&files[b]) for a,b in itertools.combinations(heads,2)}
assert len(shared['i6a-sdist'])==6 and shared['i6a-c0']==[] and shared['sdist-c0']==[]
checks['six_shared_files_recomputed']=True
recon=[]
for i,order in enumerate(itertools.permutations(heads)):
 current=base; conflicts=[];steps=[]
 for label in order:
  p=run(['git','merge-tree','--write-tree',current,heads[label]]);assert p.returncode in (0,1);tree=p.stdout.splitlines()[0];paths=[]
  if p.returncode:
   for line in p.stdout.splitlines():
    if line.startswith('CONFLICT (content): Merge conflict in '):paths.append(line.split('Merge conflict in ',1)[1])
   assert set(paths)=={'.agents/skills/ci-final-tree-verification/SKILL.md','tests/packaging/test_p1_distribution.py'},paths
   conflicts.extend(paths);index=O/f'index-{i}'
   if index.exists():index.unlink()
   git('read-tree',tree,index=index)
   for path in paths:
    text=run(['git','show',tree+':'+path]).stdout;lines=text.splitlines(keepends=True);start=next(j for j,x in enumerate(lines) if x.startswith('<<<<<<< '));middle=next(j for j,x in enumerate(lines) if x.startswith('======='));end=next(j for j,x in enumerate(lines) if x.startswith('>>>>>>> '));left=''.join(lines[start+1:middle]);right=''.join(lines[middle+1:end]);
    if path.endswith('.py'):body='from scripts.check_sdist_contract import check_sdist, compare_wheels, save\nfrom scripts.installed_test_harness import stage_support\n'
    else:
     pieces=[left,right];pieces.sort(key=lambda x:0 if '## Pytest subtest' in x else 1);body=pieces[0]+'\n'+pieces[1]
    fixed=''.join(lines[:start])+body+''.join(lines[end+1:]);oid=git('hash-object','-w','--stdin',data=fixed)
    git('update-index','--cacheinfo','100644',oid,path,index=index)
   tree=git('write-tree',index=index);index.unlink()
  current=git('commit-tree',tree,'-p',current,'-p',heads[label],data='Independent local reconstruction only\n');steps.append({'feature':heads[label],'tree':tree,'commit':current,'conflicts':paths})
 assert tree=='2c61c7d79bf9a95c4f04ccdbda8fae1fe15d5491',(order,tree)
 assert git('rev-parse',current+':src')==git('rev-parse',heads['i6a']+':src')
 recon.append({'order':order,'tree':tree,'head':current,'steps':steps})
checks['all_six_independent_reconstructions_same_expected_tree']=True
candidate=recon[0]['head']
patterns={
'scripts/verify_access_distribution.py':['fixture_service','fixture_context','check_sdist(archive, ROOT)','contract["wheel_equivalence"] = compare_wheels','REPO_CATALOG_SMOKE_AUTHORITY'],
'scripts/verify_i4_distribution.py':['harness.stage_support','harness.execute_tests','check_sdist(sdist, source)','sdist_metadata=contract["members"]["PKG-INFO"]["sha256"]'],
'scripts/verify_i5_distribution.py':['harness.stage_support','harness.execute_tests','check_sdist(sdist, source)','sdist_metadata=contract["members"]["PKG-INFO"]["sha256"]'],
 'tests/packaging/test_p1_distribution.py':['stage_support(ROOT, outside)','contract = check_sdist(sdist, ROOT)','contract["wheel_equivalence"] = compare_wheels']}
for path,terms in patterns.items():
 t=git('show',candidate+':'+path)
 for term in terms:assert term in t,(path,term)
checks['both_parent_verifier_fixture_and_contract_hunks_preserved']=True
for path,source in [('scripts/ci_plan.py','sdist'),('scripts/ci_dependencies.json','sdist'),('scripts/ci_execute.py','sdist'),('scripts/check_sdist_contract.py','sdist'),('scripts/emit_ci_evidence.py','c0')]:assert git('rev-parse',candidate+':'+path)==git('rev-parse',heads[source]+':'+path)
checks['planner_checker_emitter_exact_sibling_blobs']=True
assert git('rev-parse',candidate+':src')==git('rev-parse',heads['i6a']+':src');checks['src_subtree_exact_i6a']=True
V=pathlib.Path('/workspace/task-b-validation');meta=json.loads((V/'focused.execution.json').read_text());assert meta['exit_code']==0 and meta['source_tree']=='2c61c7d79bf9a95c4f04ccdbda8fae1fe15d5491'
inputs=json.loads((V/'focused.inputs.json').read_text());wanted=hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert wanted==meta['input_sha256']
source=pathlib.Path(meta['cwd'])
for p,d in inputs.items():assert hashlib.sha256((source/p).read_bytes()).hexdigest()==d,p
checks['focused_source_input_hashes_frozen_and_currently_equal']=True
selected=collections.Counter(x.strip() for x in (V/'focused-collection.log').read_text().splitlines() if x.startswith('tests/') and '::' in x);starts=collections.Counter();phases=collections.Counter();outcomes=collections.Counter();fin=[]
for line in (V/'focused.jsonl').read_text().splitlines():
 e=json.loads(line)
 if e['event']=='start':starts[e['nodeid']]+=1
 elif e['event']=='phase':phases[e['nodeid'],e['phase']]+=1;outcomes[e['outcome']]+=1
 elif e['event']=='finish':fin.append((e['status'],e['exitstatus']))
 else:raise AssertionError(e)
def junit_key(n):
 a=n.split('::');return (a[0][:-3].replace('/','.')+('.'+'.'.join(a[1:-1]) if len(a)>2 else ''),a[-1])
junit=collections.Counter();failed=[]
for n in ET.parse(V/'focused.xml').iter('testcase'):
 junit[n.attrib['classname'],n.attrib['name']]+=1
 if list(n):failed.append(ET.tostring(n,encoding='unicode')[:400])
assert len(selected)==sum(selected.values())==560;assert selected==starts;assert collections.Counter(junit_key(n) for n in selected)==junit;assert all(phases[n,p]==1 for n in selected for p in ['setup','call','teardown']);assert sum(phases.values())==1680;assert outcomes=={'passed':1680};assert not failed;assert fin==[('completed',0)]
checks['560_selected_junit_journal_exactly_once_and_successful_exit']=True
runtime=json.loads((V/'runtime.json').read_text());assert runtime['product_safety_and_capabilities']=='passed' and all(v is None for v in runtime['loader_environment'].values())
checks['runtime_real_safety_probe_success_no_loader_overrides']=True
build=json.loads(pathlib.Path('/workspace/task-b-builds/measurements.json').read_text());assert build['combined']['contract']['product_files']==158;assert build['sdist']['contract']['product_files']==155;assert build['combined']['wheel_equivalence']['status']=='passed';assert build['combined']['source_tree']==meta['source_tree']
checks['dynamic158_product_inventory_and_wheel_equivalence_receipt_bound']=True
out={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent non-author agent','runtime':{'python':sys.version,'executable':sys.executable,'sqlite':sqlite3.sqlite_version,'source_id':sqlite3.connect(':memory:').execute('select sqlite_source_id()').fetchone()[0]},'fixed_heads':heads,'fixed_trees':trees,'shared_files':shared,'checks':checks,'reconstructions':recon,'observed_test_count':560,'scope':'Independent audit of Git simulations and existing execution evidence; no product tests rerun; not full release acceptance.'}
(O/'verification.json').write_text(json.dumps(out,indent=2)+'\n');(O/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps({'checks':checks,'exit_code':0},indent=2))
