import pathlib,json,collections,xml.etree.ElementTree as ET,hashlib,zipfile
O=pathlib.Path('/workspace/task-b-independent');P=pathlib.Path('/workspace/task-b-installed-i6-final');meta=json.loads(pathlib.Path('/workspace/task-b-validation/installed-i6-final.execution.json').read_text());assert meta['exit_code']==0 and meta['source_tree']=='2c61c7d79bf9a95c4f04ccdbda8fae1fe15d5491';processes=json.loads((P/'processes.json').read_text());byname={p['name']:p for p in processes};results={}
with zipfile.ZipFile(next(pathlib.Path('/workspace/task-b-builds/combined').glob('*.whl'))) as z:expected={n.removeprefix('repo_catalog/'):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('repo_catalog/') and pathlib.Path(n).suffix in ['.py','.sql','.json','.graphql']}
assert len(expected)==158
for label in ['direct','sdist']:
 selected=collections.Counter(n for n in (P/(label+'-collect.log')).read_text().splitlines() if n.startswith('tests/') and '::' in n);assert len(selected)==sum(selected.values())==290;starts=collections.Counter();phases=collections.Counter();outcomes=collections.Counter();fin=[]
 for line in (P/(label+'.jsonl')).read_text().splitlines():
  e=json.loads(line)
  if e['event']=='start':starts[e['nodeid']]+=1
  elif e['event']=='phase':phases[e['nodeid'],e['phase']]+=1;outcomes[e['outcome']]+=1
  elif e['event']=='finish':fin.append((e['status'],e['exitstatus']))
  else:raise AssertionError(e)
 junit=collections.Counter();failed=[]
 for e in ET.parse(P/(label+'.xml')).iter('testcase'):
  junit[e.attrib['classname'],e.attrib['name']]+=1
  if list(e):failed.append(ET.tostring(e,encoding='unicode')[:400])
 def key(n):
  a=n.split('::');return(a[0][:-3].replace('/','.')+('.'+'.'.join(a[1:-1]) if len(a)>2 else ''),a[-1])
 assert selected==starts and junit==collections.Counter(key(n) for n in selected)
 assert all(phases[n,p]==1 for n in selected for p in ['setup','call','teardown']) and sum(phases.values())==870 and outcomes=={'passed':870} and fin==[('completed',0)] and not failed
 assert all(byname[label+n]['exit_code']==0 for n in ['-collect','-i6','-runtime'])
 imports=json.loads((P/(label+'-imports.json')).read_text());assert [m['phase'] for m in imports]==['sessionstart','sessionfinish','sessionstart','sessionfinish']
 for m in imports:
  assert pathlib.Path(m['origin']).is_relative_to(pathlib.Path(m['prefix'])) and all(pathlib.Path(x).is_relative_to(pathlib.Path(m['origin'])) for x in m['product_modules'].values());assert m['installed_files']==expected
 runtime=json.loads((P/(label+'-runtime.json')).read_text());assert runtime['product_safety_and_capabilities']=='passed' and 'site-packages' in runtime['product_module'] and all(v is None for v in runtime['loader_environment'].values())
 results[label]={'selected':290,'exact_junit_journal':True,'zero_collect_test_runtime_exits':True,'collect_and_test_origin_checks':True,'all158_product_file_hashes_match_wheel':True,'actual_sqlite':runtime['sqlite_version'],'actual_python':runtime['python'],'safety_and_capabilities':'passed'}
results['scope']='Audit of retained installed I6 focused evidence. This reviewer did not rerun product tests. No full ordinary or Release acceptance.'
(O/'i6-installed-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
