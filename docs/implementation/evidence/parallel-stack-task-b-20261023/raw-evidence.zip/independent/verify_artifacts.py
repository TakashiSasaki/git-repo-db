import pathlib,zipfile,hashlib,json,csv,io,base64,tarfile,datetime
O=pathlib.Path('/workspace/task-b-independent');B=pathlib.Path('/workspace/task-b-builds');S=pathlib.Path('/workspace/task-b-sim-i6a-sdist-c0');results={}
for label,folder in [('direct','combined'),('derived','derived')]:
 path=next((B/folder).glob('*.whl'))
 with zipfile.ZipFile(path) as z:
  names=z.namelist();assert len(names)==len(set(names)); files={n:z.read(n) for n in names if not n.endswith('/')};record=[n for n in files if n.endswith('.dist-info/RECORD')];assert len(record)==1;rows=list(csv.reader(io.StringIO(files[record[0]].decode())));assert len(rows)==len(files);assert len({r[0] for r in rows})==len(rows);assert {r[0] for r in rows}==files.keys()
  for n,d,size in rows:
   if n==record[0]:assert d==size==''
   else:assert d=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(files[n]).digest()).decode().rstrip('=') and int(size)==len(files[n])
  expected={str(p.relative_to(S/'src')):p.read_bytes() for p in (S/'src/repo_catalog').rglob('*') if p.is_file() and p.suffix in ['.py','.sql','.json','.graphql'] and '__pycache__' not in p.parts};actual={n:b for n,b in files.items() if n.startswith('repo_catalog/')};assert actual==expected and len(actual)==158
  results[label]={'wheel':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'product_files':len(actual),'suffixes':{s:sum(n.endswith(s) for n in actual) for s in ['.py','.sql','.json','.graphql']},'complete_record':True,'all_current_product_bytes_equal':True,'member_digests':{n:hashlib.sha256(b).hexdigest() for n,b in files.items()}}
assert results['direct']['member_digests']==results['derived']['member_digests']
sdist=next((B/'combined').glob('*.tar.gz'))
with tarfile.open(sdist) as z:
 members=z.getmembers(); names=[m.name for m in members];assert len(names)==len(set(names))==162;assert all(m.isfile() for m in members)
 actual={m.name.split('/',1)[1]:z.extractfile(m).read() for m in members if '/src/repo_catalog/' in m.name};expected={'src/'+p:b for p,b in expected.items()};assert actual==expected
results['sdist']={'sha256':hashlib.sha256(sdist.read_bytes()).hexdigest(),'compressed_bytes':sdist.stat().st_size,'all_current_product_bytes_equal':True,'member_count':len(members),'product_files':len(actual)}
results['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'artifact-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:{q:v for q,v in value.items() if q!='member_digests'} if isinstance(value,dict) else value for k,value in results.items()},indent=2))
