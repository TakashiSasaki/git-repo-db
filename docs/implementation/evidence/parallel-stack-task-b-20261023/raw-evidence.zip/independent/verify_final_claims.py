import pathlib,json,xml.etree.ElementTree as ET,collections,hashlib,re
O=pathlib.Path('/workspace/task-b-independent');V=pathlib.Path('/workspace/task-b-validation');checks={}
meta=json.loads((V/'shared-p1-packaging.execution.json').read_text());assert meta['exit_code']==0 and meta['source_tree']=='2c61c7d79bf9a95c4f04ccdbda8fae1fe15d5491'
selected=collections.Counter((V/'shared-p1.nodes.txt').read_text().splitlines());starts=collections.Counter();phases=collections.Counter();fin=[]
for line in (V/'shared-p1.jsonl').read_text().splitlines():
 e=json.loads(line)
 if e['event']=='start':starts[e['nodeid']]+=1
 elif e['event']=='phase':assert e['outcome']=='passed';phases[e['nodeid'],e['phase']]+=1
 elif e['event']=='finish':fin.append((e['status'],e['exitstatus']))
 else:raise AssertionError(e)
assert len(selected)==sum(selected.values())==2 and selected==starts and len(phases)==sum(phases.values())==6 and fin==[('completed',0)]
junit=collections.Counter()
for e in ET.parse(V/'shared-p1.xml').iter('testcase'):assert not list(e);junit[e.attrib['classname'],e.attrib['name']]+=1
assert junit==collections.Counter((x.split('::')[0][:-3].replace('/','.'),x.split('::')[1]) for x in selected)
checks['shared_p1_two_nodes_exact_junit_journal_pass_exit']=True
allnodes={s for s in (V/'complete-inventory.log').read_text().splitlines() if s.startswith('tests/') and '::' in s};focused=set((V/'focused.nodes.txt').read_text().splitlines())|set(selected);coverage=json.loads((V/'coverage.json').read_text());special=set(coverage['special_unexecuted']);assert len(allnodes)==6231 and len(allnodes-special)==6229 and len(focused)==562 and len(allnodes-special-focused)==5667;assert set((V/'source-unexecuted.nodes.txt').read_text().splitlines())==allnodes-special-focused
checks['complete_inventory_and562_passed_5667_unexecuted_disjoint_sets']=True
B=pathlib.Path('/workspace/task-b-backend-only');processes=json.loads((B/'processes.json').read_text());assert all(p['exit_code']==0 for p in processes);env=json.loads((B/'backend-isolated-build.log').read_text().splitlines()[0]);assert env['product_installed'] is False and len(env['packages'])==5;assert all(n in ['hatchling','packaging','pathspec','pluggy','trove-classifiers'] for n,v in env['packages']);assert not (B/'venv/bin/git').exists();assert env['sqlite']=='3.53.1'
wheel=next((B/'built').glob('*.whl'));assert hashlib.sha256(wheel.read_bytes()).hexdigest()=='b92078f0153c187dd5d06773b75d98e134970694a79a58534b59c4f8503da878';source=pathlib.Path(env['source']);assert all(not (source/n).exists() for n in ['.git','docs','tests','scripts']);assert all(n['name'] in ['venv','install','backend-isolated-build'] for n in processes)
checks['backend_only_no_product_no_git_scope_and_actual_rebuild_digest']=True
paths=['README.md','PLAN.md','DAG.md','CI-AUDIT.md','DESIGN-REVIEW.md'];root=pathlib.Path('/workspace/git-repo-db/docs/implementation/evidence/parallel-stack-task-b-20261023');bindings={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths};checks['final_main_prose_read_and_claims_reviewed']=True
(O/'final-claims-verification.json').write_text(json.dumps({'checks':checks,'prose_sha256':bindings,'backend_executed_processes':processes,'backend_scope':'Python isolation/audit hooks and PATH, not OS sandbox assurance','review_scope':'Read-only evidence/prose audit; no product tests rerun'},indent=2)+'\n');print(json.dumps(checks,indent=2))
