import pathlib,json,subprocess,itertools,hashlib
R=pathlib.Path('/workspace/git-repo-db');O=pathlib.Path('/workspace/task-b-independent');p=R/'docs/implementation/evidence/parallel-stack-task-b-20261023/raw/github-start.json';s=json.loads(p.read_text());nodes=s['all_open']+s['recent_closed_100_plus'];calls=[]
def git(*args):
 p=subprocess.run(['git',*args],cwd=R,text=True,capture_output=True);calls.append({'argv':['git',*args],'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});return p
for n in nodes:
 head=n['head']['sha'];tree=git('rev-parse',head+'^{tree}');assert tree.returncode==0 and tree.stdout.strip()==n['head']['tree'];mb=git('merge-base',n['base']['sha'],head);assert mb.returncode==0 and mb.stdout.strip()==n['actual_merge_base'];ancestor=git('merge-base','--is-ancestor',n['base']['sha'],head);assert (ancestor.returncode==0)==n['base_is_ancestor'];assert ancestor.returncode in [0,1]
relations={}
for a,b in itertools.permutations(nodes,2):
 v=git('merge-base','--is-ancestor',a['head']['sha'],b['head']['sha']);assert v.returncode in [0,1];relations[a['number'],b['number']]=v.returncode==0
edges=[]
for (a,b),yes in relations.items():
 if yes and not any(relations.get((a,c['number'])) and relations.get((c['number'],b)) for c in nodes if c['number'] not in [a,b]):edges.append([a,b])
assert sorted(edges)==sorted(s['actual_ancestry_reduced_edges'])
results={'source_snapshot_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'open_prs':len(s['all_open']),'recent_closed_100_plus':len(s['recent_closed_100_plus']),'recomputed_node_count':len(nodes),'recomputed_reduced_edges':edges,'all_heads_trees_merge_bases_and_ancestor_flags_match':True,'recorded_edges_equal_independent_recomputation':True,'base_not_ancestor_prs':[n['number'] for n in nodes if not n['base_is_ancestor']],'scope':'Read-only recomputation of actual Git DAG for saved current API inventory; no product test or release acceptance.'}
(O/'graph-verification.json').write_text(json.dumps(results,indent=2)+'\n');(O/'graph-commands.json').write_text(json.dumps(calls,indent=2)+'\n');print(json.dumps(results,indent=2))
