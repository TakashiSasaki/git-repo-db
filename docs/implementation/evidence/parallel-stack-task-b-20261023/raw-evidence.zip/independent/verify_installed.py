import pathlib,json,collections,xml.etree.ElementTree as ET,hashlib,subprocess,gzip,re
O=pathlib.Path('/workspace/task-b-independent');P=pathlib.Path('/workspace/task-b-installed-i5');results={}
processes=json.loads((P/'processes.json').read_text());byname={p['name']:p for p in processes};assert len(byname)==len(processes)
for label in ['direct','sdist']:
 for stage,count in [('i4',217),('i5',29)]:
  name=f'{label}-{stage}';selected=collections.Counter((P/(name+'-selected.txt')).read_text().splitlines());assert len(selected)==sum(selected.values())==count;starts=collections.Counter();phases=collections.Counter();outcomes=collections.Counter();fin=[]
  for line in (P/(name+'.jsonl')).read_text().splitlines():
   e=json.loads(line)
   if e['event']=='start':starts[e['nodeid']]+=1
   elif e['event']=='phase':phases[e['nodeid'],e['phase']]+=1;outcomes[e['outcome']]+=1
   elif e['event']=='finish':fin.append((e['status'],e['exitstatus']))
   else:raise AssertionError(e)
  junit=collections.Counter();failed=[]
  for e in ET.parse(P/(name+'.xml')).iter('testcase'):
   junit[e.attrib['classname'],e.attrib['name']]+=1
   if list(e):failed.append(ET.tostring(e,encoding='unicode')[:400])
  def key(n):
   a=n.split('::');return(a[0][:-3].replace('/','.')+('.'+'.'.join(a[1:-1]) if len(a)>2 else ''),a[-1])
  assert selected==starts and junit==collections.Counter(key(n) for n in selected)
  assert all(phases[n,p]==1 for n in selected for p in ['setup','call','teardown']) and sum(phases.values())==count*3 and outcomes=={'passed':count*3} and fin==[('completed',0)] and not failed
  assert byname[name]['exit_code']==byname[name+'-collect']['exit_code']==byname[name+'-reconciliation']['exit_code']==0
  imports=json.loads((P/(name+'-imports.json')).read_text());assert [m['phase'] for m in imports]==['sessionstart','sessionfinish','sessionstart','sessionfinish']
  for m in imports:assert pathlib.Path(m['origin']).is_relative_to(pathlib.Path(m['prefix'])) and all(pathlib.Path(x).is_relative_to(pathlib.Path(m['origin'])) for x in m['product_modules'].values())
  results[name]={'selected':count,'exact_junit_journal':True,'zero_exit':True,'collect_and_test_origin_checks':True}
 current=(P/(label+'-access.log')).read_text();assert byname[label+'-access']['exit_code']==1;assert 'line 397, in export_package' in current and 'AdmissionRefused: PERMISSION_DENIED' in current
 path=f'docs/implementation/evidence/adr0031-i6a/remediation-20261023/installed-harness/final/{label}-access.log.gz';p=subprocess.run(['git','show','ea43a21:'+path],cwd='/workspace/git-repo-db',capture_output=True);assert p.returncode==0;old=gzip.decompress(p.stdout).decode()
 def normalize(s):
  s=re.sub(r'/tmp/repo-catalog-installed-tests-[^/\s\"]+', '<TEST-HARNESS>', s)
  s=re.sub(r'/workspace/task-b-installed-i5/'+label+'-venv', '<INSTALLED-VENV>', s)
  # Historical venv path is extracted only from the actual site-packages frame.
  lines=s.splitlines()
  for line in lines:
   if '/lib/python3.12/site-packages/repo_catalog/application/exchange.py' in line:
    pre=line.split('File "',1)[1].split('/lib/python3.12/site-packages',1)[0];s=s.replace(pre,'<INSTALLED-VENV>')
  return s
 assert normalize(current)==normalize(old),(label,current,old)
 results[label+'-original-access']={'exit_code':1,'failure':'AdmissionRefused(PERMISSION_DENIED) at ExchangeService.export_package line397','matches_frozen_i6a_after_only_observed_harness_and_venv_path_normalization':True,'historical_raw_sha256':hashlib.sha256(old.encode()).hexdigest(),'current_raw_sha256':hashlib.sha256(current.encode()).hexdigest(),'downstream_assertions':'unexecuted'}
results['scope']='Audit of retained installed I4/I5 and unchanged refusal evidence; no new product execution. Standard verifier overall remains exit1.'
(O/'installed-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
