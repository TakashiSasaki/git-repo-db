import argparse,base64,hashlib,io,json,re,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('log',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
s=a.log.read_text(); begin=re.findall(r'Z CI_RECEIPTS_BEGIN_V1 ([0-9a-f]{64}) (\d+)\s*$',s,re.M);end=re.findall(r'Z CI_RECEIPTS_END_V1 ([0-9a-f]{64})\s*$',s,re.M)
assert len(begin)==len(end)==1,(begin,end)
body=base64.b64decode(''.join(re.findall(r'Z CI_RECEIPTS_DATA_V1 ([A-Za-z0-9+/=]+)\s*$',s,re.M)),validate=True)
assert hashlib.sha256(body).hexdigest()==begin[0][0]==end[0]
assert len(body)==int(begin[0][1])
a.output.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(io.BytesIO(body)) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 index=json.loads(z.read('receipt-index.json'))
 assert set(index)==set(z.namelist())-{'receipt-index.json'}
 for name in z.namelist():
  relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
  data=z.read(name)
  if name in index: assert index[name]=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  target=a.output/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
print(json.dumps({'zip_bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'members':len(index)+1,'binding':json.loads((a.output/'receipt-binding.json').read_text())},indent=2))
(a.output.parent/(a.output.name+'.zip')).write_bytes(body)
