"""Package exact receipts on the separate evidence branch, without a CI rerun."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path('/workspace/host-ci-evidence')
OUT = Path('/workspace/git-repo-db-host-evidence/docs/implementation/evidence/adr0032-host-runtime-20261022')
HOST = ROOT / 'hosted-f16e5b1'
RECEIPTS = HOST / 'access-receipts'

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

OUT.mkdir(parents=True, exist_ok=True)
source = read(ROOT / 'final-source-binding.json')
runtime = read(RECEIPTS / 'artifacts/runtime/selected.json')
comparison = read(RECEIPTS / 'artifacts/access-registry/failure-comparison.json')
coverage = read(ROOT / 'coverage-reconciliation.json')
summary = read(RECEIPTS / 'artifacts/access-registry/i5/summary.json')
workflow_runs = read(HOST / 'final-workflow-runs.json')
assert {x['id']: x['conclusion'] for x in workflow_runs['workflow_runs']} == {39799299296:'success',39799299209:'failure'}
assert summary['inputs_unchanged'] and comparison['same_nodes']
results = {
    'source': source,
    'workflow_runs': workflow_runs,
    'runtime': runtime,
    'product_safety_and_capabilities': 'passed; original Access and P1 factories, STRICT/JSON/FTS5/WAL',
    'sqlite_component_download_build_install_swap': False,
    'product_source_changed': False,
    'policy': {'violations':0,'detector_tests':31,'runtime_tests':4,'outcome':'passed','dependencies_required':False},
    'source_original_pytest': {'total':2775,'passed':2696,'failed':59,'setup_errors':20,'skipped':0,'exit_code':1},
    'source_broad_pytest': {'total':3137,'passed':3058,'failed':59,'setup_errors':20,'skipped':0,'exit_code':1,'inputs_unchanged':True},
    'bounded': {'I4':{'passed':217,'exit_code':0},'I5':{'passed':29,'exit_code':0}},
    'distributions': {'direct_wheel':{'runtime_binding':'passed','I2':'passed','I3':'passed','I4_passed':217,'I5_passed':29,'original_Access_smoke':'inherited I2_TRANSFER_UNSUPPORTED; exit 1'},'sdist_derived_wheel':{'runtime_binding':'passed','I2':'passed','I3':'passed','I4_passed':217,'I5_passed':29,'original_Access_smoke':'inherited I2_TRANSFER_UNSUPPORTED; exit 1'}},
    'inherited_non_success_comparison': {k:comparison[k] for k in ('baseline_non_successes','current_non_successes','same_nodes','additional','resolved')},
    'pr132_full_frame_comparison': {k:v for k,v in read(ROOT/'pr132-failure-comparison.json').items() if k!='comparison'},
    'new_failure_fixed': {'commit':'d0b1192b2c51adaa4158551becb8567acb85176c','run':39798601683,'failure':'source-ID negative unit fixture inherited bootstrap loader state','fix':'f16e5b1 isolates mocked loader fields; actual runtime rejection unchanged','final_hosted_runtime_unit_tests_passed':4},
    'local_final_tools': {'passed':289,'subtests_passed':57,'exit_code':0},
    'local_mutable_input_broad_trial': {'head_at_start':'c83a783c9b03ca7c229f4421096754cbce0ef844','inputs_unchanged':False,'used_as_final_acceptance':False},
    'coverage':coverage,
    'receipt_verification': {'Access':read(HOST/'access-receipt-verification.json'),'tests':read(HOST/'tests-receipt-verification.json')},
    'independent_review':read(ROOT/'review/independent-review.json'),
    'publication':'Separate evidence branch descended from final source HEAD; publication is not another test execution. PR #133 source HEAD remains f16e5b1. No merge.',
}
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(OUT/'independent-review.json').write_bytes((ROOT/'review/independent-review.json').read_bytes())
(OUT/'independent-review.md').write_bytes((ROOT/'review/independent-review.md').read_bytes())
files = {}
def include(path):
    files[str(path.relative_to(ROOT))] = path
for directory in [ROOT/'baseline', HOST]:
    for path in directory.iterdir():
        if path.is_file() and path.suffix in {'.json','.zip','.log'} and 'watch' not in path.name and path.name!='download.log':
            files[str(path.relative_to(ROOT))]=path
for directory in [ROOT/'local-i5', ROOT/'local-distribution', ROOT/'local-offline-inventory', ROOT/'review']:
    for path in directory.iterdir():
        if path.is_file() and path.suffix in {'.json','.jsonl','.xml','.txt','.log','.md'}:
            include(path)
for name in ['final-source-binding.json','existing-pr-heads.json','coverage-reconciliation.json','unexecuted-ordinary.txt','pr132-failure-comparison.json','local-failure-comparison.json','local-selected-final.json','local-selected-final.log','local-runtime.json','local-runtime.log','final-tools.xml','final-tools.jsonl','final-tools.log','final-focused-corrected.log','stdlib-runtime-tests.log','decode_receipts.py','publish_evidence.py']:
    include(ROOT/name)
include(ROOT/'hosted-d0b1192/policy-job.log')
include(ROOT/'hosted-d0b1192/tests-jobs.json')
include(ROOT/'hosted-d0b1192/tests-run.json')
index={}
with zipfile.ZipFile(OUT/'payload.zip','w') as archive:
    for name,path in sorted(files.items()):
        body=path.read_bytes(); info=zipfile.ZipInfo(name);info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,body)
        index[name]={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
(OUT/'artifact-index.json').write_text(json.dumps({'payload':{'bytes':(OUT/'payload.zip').stat().st_size,'sha256':sha(OUT/'payload.zip')},'members':index},indent=2)+'\n')
print(json.dumps({'members':len(index),'payload_bytes':(OUT/'payload.zip').stat().st_size,'payload_sha256':sha(OUT/'payload.zip')}))
