# Independent Reviewer C — untrusted recovery security

Reviewed executable commit: `178ddbaa8fa06f52aff4993730205c5a38da91f4`  
Git tree: `9740ad1a91f367192bb31ce9777d039c2bb4729b`  
Review worktree: `/workspace/p7-review-c`, clean at execution.  
Reviewer: independent C subagent; no P7 production changes authored.

## Decision

No unresolved implementation blocker found in this scope on the frozen executable tree. All 38 independently constructed probes passed; all 255 P7 integration nodes passed, with zero failure/error/skip. This is an attributed engineering review, not origin authentication or owner merge authorization.

The reviewer originally authored five WAL/process regression nodes in `test_process_isolation.py`. Their assertions are explicitly excluded from this independent test-quality opinion; Reviewer D owns that independent assessment. Running them as regression coverage does not constitute self-approval. No installed-distribution or full P1–P6 acceptance is claimed here; those are the root/D workstreams.

## Reproduced defects and independent corrected-tree checks

Before/after evidence remains under the parent evidence directory; historical failures have not been removed or relabelled as passes.

| Finding independently reproduced | Corrected-tree result |
| --- | --- |
| Oversized Context text bypassed its payload ceiling; integer text aborted later candidates | Oversized text rejected; malformed text rejected while a following independent valid text is admitted |
| A 121-byte completed file was permanently billed 131072 scan bytes | Successful scan settles to 121; hard-crash uncertain reservations remain charged |
| FIFO salvage input blocked indefinitely while holding its request lock | Nonregular input refused without waiting for a FIFO writer |
| Boolean version values were accepted in state, registry and initialized marker | All three fail closed; invalid request identities and larger retry contracts also refuse |
| Nominal Git metadata ignored the configured metadata ceiling | Nominal admission/replay reserves metadata work before lookup/admission; two candidates cannot bypass a one-unit ceiling |
| Digest-rejected Base64 bodies were decoded before their raw-input reservation | Insufficient raw-input allowance refuses before decoding/hashing; no authoritative mutation |
| One refused candidate was reported as two unprocessed units; exact record caps invented another unit | Current refused candidate is counted once; exact EOF does not create a phantom unit |
| Stopped-source extraction crossed an existing supported Context writer's held gate | Extraction waits for writer cleanup before reaching forensic copying |
| A corrupted existing Context row was treated as a candidate conflict without persistent stop | Confirmed retained-text corruption persists stop |
| A required missing Context body was silently reinserted | Stop persists and missing body remains absent; independent empty-tree native-copy proof likewise stops without reinsertion |
| SIGKILL between initial empty-registry publication and marker creation made all requests unavailable | Exactly pristine initialization resumes; used/lost/conflicting records remain fail closed |

Independent concurrent-process and hard-kill probes additionally established: same-ID attempts cannot spend the same one-record allowance twice; a SIGKILL after durable reservation or after actual Context COMMIT retains expenditure; three new-interpreter retries after Operational/Search deletion do not reset usage; deletion/truncation/conflicting request/checkpoint/registry/marker records refuse further authority changes. The final Context admission cut is after its actual COMMIT completion fence, rather than after an uncommitted INSERT helper. The earlier autocommit-only helper is preserved separately as `reviewer-c-process-proofs-v1-autocommit-context.py`.

Independent allocation probes used a 4,000,000-byte SQLite BLOB and a 10,000,000-byte unterminated JSONL input. The former reported incomplete enumeration without false corruption, left the source hash unchanged, and stayed below 1 MB Python allocation. The latter read only 65536 bytes and refused before invoking JSON decoding, without scanning the remaining suffix.

## Exact execution evidence

`receipt.json` records all 14 commands and exit codes, probe/test UTC execution boundaries, script SHA-256 identities, executable commit/tree, environment path and scope exclusions. All commands exited zero and all script probe flags were true. The 11 independent scripts account for 38 probes.

The complete integration command was:

```text
uv run --no-sync pytest tests/integration/p7 -q --junitxml=/workspace/recovery-evidence-20261016/reviewer-c-final-178ddbaa/p7.xml
```

Execution environment: `PYTHONPATH=/workspace/p7-review-c/src`, working directory `/workspace/p7-review-c`. `p7.log` records 255 passed in 62.68 seconds; this is execution evidence under concurrent work, not a comparative benchmark. `p7.xml` retains per-node outcomes. `p7-node-ids.txt` retains the exact `pytest tests/integration/p7 --collect-only -q` node inventory. The unmodified command runner is `../run-reviewer-c-final-178ddbaa.py`; each probe source is retained in the parent evidence directory, and its hash is in the receipt.

## Final audit correction review

The only difference from previously reviewed `a93d870` is two explicit entries in `scripts/audit_callsite_dependencies.py`: `adapters/sqlite/recovery_budget.py` and `adapters/sqlite/recovery_validation.py`. They belong to the same opt-in P7 implementation as the already registered `recovery.py`; source inspection found references only from that opt-in module. No wildcard or filename-prefix exclusion was added, no existing Schema 21 runtime path was newly excluded, and runtime/source/tests were unchanged. The named isolated-target set also feeds the baseline-to-isolated direct import detector, so the helpers now participate in that isolation guard. The dependency index was not regenerated or edited. `callsite-audit.log` records the final exact-revision `--check` success. Previous `a93d870` evidence remains intact in its original directory.

## Supported limits

- Tested Linux cooperative-process filesystem behavior, including real SIGKILL and separate interpreters; no actual host power interruption was simulated.
- Complete malicious deletion or consistent rewriting of all local accounting evidence is outside the documented local durability contract. Individual used-record/marker/checkpoint loss tested here fails closed.
- Python allocation observations use tracemalloc; they do not measure native SQLite RSS or establish a host-wide memory ceiling.
- This review authorizes no real-catalog recovery, activation, release, deployment, merge or public runtime change.
