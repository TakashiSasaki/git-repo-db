### ref-query-reviewed: 9.23s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `904eead6b4775171c03719ab39bc7d3afd5a4d65`, tree `3a3c95fc7e3b871ac0536ee1c888c70494d8ff69`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `ref-query-reviewed-1793369209-9752cefe`. Dirty tree: `False`.
Command wall time: 9.23s; Cumulative test duration: 12.84s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_pagination_snapshots.py | 4.98 | 3 | 0 |
| tests/integration/p6/test_ref_query_transition.py | 3.09 | 12 | 0 |
| tests/integration/p6/test_queries.py | 2.50 | 6 | 0 |
| tests/integration/p6/test_cli.py | 2.26 | 2 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_pagination_snapshots.py::test_deterministic_pagination_across_all_endpoints` | 0.0013 | 3.9696 | 0.0001 | 3.9711 | passed |
| `tests/integration/p6/test_cli.py::test_cli_all_subcommands_pagination_and_error_handling` | 0.0012 | 1.4587 | 0.0002 | 1.4601 | passed |
| `tests/integration/p6/test_cli.py::test_cli_module_execution_and_schema21_cli_isolation` | 0.0010 | 0.8020 | 0.0003 | 0.8033 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_open_snapshot_isolation_and_stale_cursor_fencing_after_write` | 0.0010 | 0.5134 | 0.0002 | 0.5147 | passed |
| `tests/integration/p6/test_queries.py::test_verification_aware_byte_reads_detect_corruption_and_fence_catalog` | 0.0009 | 0.4997 | 0.0002 | 0.5009 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_malformed_tampered_and_cross_endpoint_cursors_fail_closed` | 0.0009 | 0.4960 | 0.0002 | 0.4972 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha256]` | 0.0009 | 0.4610 | 0.0001 | 0.4621 | passed |
| `tests/integration/p6/test_queries.py::test_context_only_queries_resources_fields_relations_inventories_and_coverage` | 0.0009 | 0.4581 | 0.0002 | 0.4592 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha1]` | 0.0012 | 0.4082 | 0.0002 | 0.4096 | passed |
| `tests/integration/p6/test_queries.py::test_paired_cross_store_resolution_present_vs_absent_core_oids[sha256]` | 0.0011 | 0.3680 | 0.0002 | 0.3692 | passed |
