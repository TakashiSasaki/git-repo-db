### ref-query-fixed: 10.41s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `1e70d1ddfe5c9f4a43f52775bcc39598b8d656cc`, tree `18e0a00c9eb6445dbca13984931632fcb509bf1a`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `ref-query-fixed-1793369041-11751abc`. Dirty tree: `True`.
Command wall time: 10.41s; Cumulative test duration: 14.98s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_pagination_snapshots.py | 5.37 | 3 | 0 |
| tests/integration/p6/test_ref_query_transition.py | 3.99 | 12 | 0 |
| tests/integration/p6/test_queries.py | 3.15 | 6 | 0 |
| tests/integration/p6/test_cli.py | 2.47 | 2 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_pagination_snapshots.py::test_deterministic_pagination_across_all_endpoints` | 0.0014 | 4.2819 | 0.0001 | 4.2834 | passed |
| `tests/integration/p6/test_cli.py::test_cli_all_subcommands_pagination_and_error_handling` | 0.0014 | 1.7195 | 0.0002 | 1.7212 | passed |
| `tests/integration/p6/test_cli.py::test_cli_module_execution_and_schema21_cli_isolation` | 0.0013 | 0.7512 | 0.0002 | 0.7527 | passed |
| `tests/integration/p6/test_queries.py::test_context_only_queries_resources_fields_relations_inventories_and_coverage` | 0.0015 | 0.6603 | 0.0003 | 0.6620 | passed |
| `tests/integration/p6/test_queries.py::test_verification_aware_byte_reads_detect_corruption_and_fence_catalog` | 0.0016 | 0.6048 | 0.0002 | 0.6066 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_malformed_tampered_and_cross_endpoint_cursors_fail_closed` | 0.0013 | 0.5979 | 0.0002 | 0.5994 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha256]` | 0.0012 | 0.5155 | 0.0003 | 0.5169 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_open_snapshot_isolation_and_stale_cursor_fencing_after_write` | 0.0012 | 0.4861 | 0.0002 | 0.4876 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha1]` | 0.0015 | 0.4832 | 0.0002 | 0.4848 | passed |
| `tests/integration/p6/test_queries.py::test_paired_cross_store_resolution_present_vs_absent_core_oids[sha256]` | 0.0018 | 0.4407 | 0.0009 | 0.4434 | passed |
