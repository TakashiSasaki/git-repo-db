### ref-query-bounded: 9.85s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `b17aa88061d5a44dd89195676cb86890cc1a5de1`, tree `701f629e845a81ee91136bbb90dc5cac535a2c27`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `ref-query-bounded-1793369134-b3845934`. Dirty tree: `False`.
Command wall time: 9.85s; Cumulative test duration: 14.03s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_pagination_snapshots.py | 5.05 | 3 | 0 |
| tests/integration/p6/test_ref_query_transition.py | 3.69 | 12 | 0 |
| tests/integration/p6/test_queries.py | 2.85 | 6 | 0 |
| tests/integration/p6/test_cli.py | 2.44 | 2 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_pagination_snapshots.py::test_deterministic_pagination_across_all_endpoints` | 0.0013 | 4.0020 | 0.0001 | 4.0035 | passed |
| `tests/integration/p6/test_cli.py::test_cli_all_subcommands_pagination_and_error_handling` | 0.0014 | 1.6149 | 0.0002 | 1.6165 | passed |
| `tests/integration/p6/test_cli.py::test_cli_module_execution_and_schema21_cli_isolation` | 0.0013 | 0.8258 | 0.0004 | 0.8275 | passed |
| `tests/integration/p6/test_queries.py::test_context_only_queries_resources_fields_relations_inventories_and_coverage` | 0.0011 | 0.5608 | 0.0003 | 0.5621 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_malformed_tampered_and_cross_endpoint_cursors_fail_closed` | 0.0013 | 0.5393 | 0.0002 | 0.5408 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha1]` | 0.0014 | 0.5050 | 0.0002 | 0.5066 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_open_snapshot_isolation_and_stale_cursor_fencing_after_write` | 0.0013 | 0.5049 | 0.0002 | 0.5064 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha256]` | 0.0019 | 0.4986 | 0.0002 | 0.5007 | passed |
| `tests/integration/p6/test_queries.py::test_verification_aware_byte_reads_detect_corruption_and_fence_catalog` | 0.0013 | 0.4889 | 0.0002 | 0.4904 | passed |
| `tests/integration/p6/test_queries.py::test_paired_cross_store_resolution_present_vs_absent_core_oids[sha1]` | 0.0015 | 0.4266 | 0.0002 | 0.4284 | passed |
