### ref-query-final: 9.77s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `3735b4e1ddfd5cf30a97ece8cef57b1bdb42b186`, tree `008301ace26fe8682626a8601cba1a5cc1afc018`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `ref-query-final-1793369066-5b27985e`. Dirty tree: `False`.
Command wall time: 9.77s; Cumulative test duration: 13.72s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_pagination_snapshots.py | 5.05 | 3 | 0 |
| tests/integration/p6/test_ref_query_transition.py | 3.54 | 12 | 0 |
| tests/integration/p6/test_queries.py | 2.83 | 6 | 0 |
| tests/integration/p6/test_cli.py | 2.31 | 2 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_pagination_snapshots.py::test_deterministic_pagination_across_all_endpoints` | 0.0010 | 3.9371 | 0.0002 | 3.9383 | passed |
| `tests/integration/p6/test_cli.py::test_cli_all_subcommands_pagination_and_error_handling` | 0.0014 | 1.6113 | 0.0002 | 1.6129 | passed |
| `tests/integration/p6/test_cli.py::test_cli_module_execution_and_schema21_cli_isolation` | 0.0013 | 0.6916 | 0.0003 | 0.6931 | passed |
| `tests/integration/p6/test_queries.py::test_context_only_queries_resources_fields_relations_inventories_and_coverage` | 0.0013 | 0.6262 | 0.0001 | 0.6277 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_malformed_tampered_and_cross_endpoint_cursors_fail_closed` | 0.0018 | 0.5578 | 0.0002 | 0.5598 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_open_snapshot_isolation_and_stale_cursor_fencing_after_write` | 0.0012 | 0.5467 | 0.0002 | 0.5481 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha1]` | 0.0014 | 0.4916 | 0.0002 | 0.4932 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha256]` | 0.0012 | 0.4882 | 0.0003 | 0.4896 | passed |
| `tests/integration/p6/test_queries.py::test_verification_aware_byte_reads_detect_corruption_and_fence_catalog` | 0.0012 | 0.4667 | 0.0002 | 0.4681 | passed |
| `tests/integration/p6/test_ref_query_transition.py::test_reported_notes_visible_without_capture[acquisition1-True]` | 0.0627 | 0.3271 | 0.0018 | 0.3917 | passed |
