### ref-query: 10.40s command wall time (exit 1)

Mode `xdist`, workers 2, SHA `1e70d1ddfe5c9f4a43f52775bcc39598b8d656cc`, tree `18e0a00c9eb6445dbca13984931632fcb509bf1a`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `ref-query-1793368970-a9797563`. Dirty tree: `True`.
Command wall time: 10.40s; Cumulative test duration: 14.60s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_pagination_snapshots.py | 5.74 | 3 | 0 |
| tests/integration/p6/test_ref_query_transition.py | 3.24 | 12 | 4 |
| tests/integration/p6/test_queries.py | 2.85 | 6 | 0 |
| tests/integration/p6/test_cli.py | 2.77 | 2 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_pagination_snapshots.py::test_deterministic_pagination_across_all_endpoints` | 0.0013 | 4.4783 | 0.0002 | 4.4798 | passed |
| `tests/integration/p6/test_cli.py::test_cli_all_subcommands_pagination_and_error_handling` | 0.0016 | 1.7759 | 0.0002 | 1.7778 | passed |
| `tests/integration/p6/test_cli.py::test_cli_module_execution_and_schema21_cli_isolation` | 0.0013 | 0.9948 | 0.0002 | 0.9964 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_open_snapshot_isolation_and_stale_cursor_fencing_after_write` | 0.0013 | 0.6647 | 0.0002 | 0.6662 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_malformed_tampered_and_cross_endpoint_cursors_fail_closed` | 0.0013 | 0.5897 | 0.0003 | 0.5913 | passed |
| `tests/integration/p6/test_queries.py::test_context_only_queries_resources_fields_relations_inventories_and_coverage` | 0.0011 | 0.5853 | 0.0002 | 0.5865 | passed |
| `tests/integration/p6/test_queries.py::test_verification_aware_byte_reads_detect_corruption_and_fence_catalog` | 0.0012 | 0.5641 | 0.0002 | 0.5655 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha1]` | 0.0015 | 0.4706 | 0.0002 | 0.4723 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha256]` | 0.0015 | 0.4290 | 0.0002 | 0.4307 | passed |
| `tests/integration/p6/test_queries.py::test_paired_cross_store_resolution_present_vs_absent_core_oids[sha256]` | 0.0017 | 0.4279 | 0.0002 | 0.4299 | passed |
