### adr0036-inputs: 81.71s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `dde476ce454843a98320585a164272ad0a842711`, tree `1300625f7d5c05162ca6d88ee57fd3389c769e2e`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `adr0036-inputs-1793365359-a2ddaf8e`. Dirty tree: `False`.
Command wall time: 81.71s; Cumulative test duration: 158.39s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p5/test_ref_inventory_wiring.py | 123.36 | 144 | 0 |
| tests/integration/p5/test_ref_notes_inputs.py | 30.20 | 60 | 0 |
| tests/integration/p5/test_git_acquisition.py | 4.80 | 14 | 0 |
| tests/unit/test_native_acquisition_values.py | 0.04 | 23 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition0-paired-metadata]` | 0.0653 | 2.1395 | 0.0018 | 2.2066 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition2-core-metadata]` | 0.0428 | 1.8281 | 0.0013 | 1.8723 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition0-core-metadata]` | 0.0418 | 1.8278 | 0.0018 | 1.8714 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition1-core-metadata]` | 0.0640 | 1.7826 | 0.0016 | 1.8481 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition1-paired-metadata]` | 0.0474 | 1.7854 | 0.0017 | 1.8345 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition0-paired-native]` | 0.0551 | 1.7729 | 0.0016 | 1.8296 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition2-paired-native]` | 0.0536 | 1.7252 | 0.0015 | 1.7802 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition3-core-metadata]` | 0.0639 | 1.6887 | 0.0012 | 1.7538 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition2-paired-metadata]` | 0.0641 | 1.6830 | 0.0016 | 1.7487 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition1-paired-native]` | 0.0552 | 1.6687 | 0.0016 | 1.7254 | passed |
