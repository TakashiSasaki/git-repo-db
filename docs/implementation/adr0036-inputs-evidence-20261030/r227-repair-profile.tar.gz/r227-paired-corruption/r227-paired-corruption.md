### r227-paired-corruption: 3.09s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `d7dda1e96f431e99893fec45538189b5c8855d51`, tree `8ff54624b4b87e34dee25f868066d743f6f9c302`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `r227-paired-corruption-1793370550-c6fb55a3`. Dirty tree: `True`.
Command wall time: 3.09s; Cumulative test duration: 1.18s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_r227_fixes.py | 1.18 | 4 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_real_stored_corruption_still_stops[acquisition0-observation-True]` | 0.0698 | 0.2271 | 0.0014 | 0.2984 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_real_stored_corruption_still_stops[acquisition2-observation-True]` | 0.0700 | 0.2266 | 0.0014 | 0.2981 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_real_stored_corruption_still_stops[acquisition3-observation-True]` | 0.0690 | 0.2207 | 0.0014 | 0.2912 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_real_stored_corruption_still_stops[acquisition1-observation-True]` | 0.0687 | 0.2185 | 0.0015 | 0.2887 | passed |
