### r227-regression: 7.61s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `6ef25d6d8c7c8994d6698288ffae03a142fbe23b`, tree `a2d393e783aa05af19933cd3a679fbec5123996f`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `r227-regression-1793370650-83258b0b`. Dirty tree: `False`.
Command wall time: 7.61s; Cumulative test duration: 11.26s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_pagination_snapshots.py | 5.68 | 3 | 0 |
| tests/integration/p6/test_queries.py | 2.95 | 6 | 0 |
| tests/integration/p6/test_cli.py | 2.63 | 2 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_pagination_snapshots.py::test_deterministic_pagination_across_all_endpoints` | 0.0015 | 4.4518 | 0.0002 | 4.4535 | passed |
| `tests/integration/p6/test_cli.py::test_cli_all_subcommands_pagination_and_error_handling` | 0.0015 | 1.7005 | 0.0006 | 1.7025 | passed |
| `tests/integration/p6/test_cli.py::test_cli_module_execution_and_schema21_cli_isolation` | 0.0015 | 0.9257 | 0.0002 | 0.9274 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_open_snapshot_isolation_and_stale_cursor_fencing_after_write` | 0.0013 | 0.6240 | 0.0003 | 0.6256 | passed |
| `tests/integration/p6/test_pagination_snapshots.py::test_malformed_tampered_and_cross_endpoint_cursors_fail_closed` | 0.0011 | 0.6014 | 0.0002 | 0.6027 | passed |
| `tests/integration/p6/test_queries.py::test_context_only_queries_resources_fields_relations_inventories_and_coverage` | 0.0014 | 0.5844 | 0.0005 | 0.5862 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha256]` | 0.0014 | 0.5479 | 0.0002 | 0.5496 | passed |
| `tests/integration/p6/test_queries.py::test_verification_aware_byte_reads_detect_corruption_and_fence_catalog` | 0.0054 | 0.5217 | 0.0002 | 0.5273 | passed |
| `tests/integration/p6/test_queries.py::test_core_only_queries_objects_claims_relations_notes_and_coverage[sha1]` | 0.0059 | 0.4738 | 0.0002 | 0.4800 | passed |
| `tests/integration/p6/test_queries.py::test_paired_cross_store_resolution_present_vs_absent_core_oids[sha1]` | 0.0022 | 0.4109 | 0.0001 | 0.4132 | passed |
