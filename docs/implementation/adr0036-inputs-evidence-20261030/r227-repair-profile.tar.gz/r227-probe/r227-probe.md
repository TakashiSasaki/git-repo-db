### r227-probe: 7.81s command wall time (exit 1)

Mode `xdist`, workers 2, SHA `d7dda1e96f431e99893fec45538189b5c8855d51`, tree `8ff54624b4b87e34dee25f868066d743f6f9c302`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `r227-probe-1793370354-15a25c68`. Dirty tree: `True`.
Command wall time: 7.81s; Cumulative test duration: 10.95s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p6/test_r227_fixes.py | 10.95 | 42 | 8 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition3-require-True]` | 0.0700 | 0.3286 | 0.0017 | 0.4003 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition2-charge-True]` | 0.0717 | 0.3148 | 0.0018 | 0.3883 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_01_group_only_object_and_wrong_claim_target[acquisition0-True]` | 0.0804 | 0.3000 | 0.0017 | 0.3821 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_01_group_only_object_and_wrong_claim_target[acquisition1-True]` | 0.0652 | 0.3045 | 0.0015 | 0.3712 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition1-require-True]` | 0.0486 | 0.3203 | 0.0012 | 0.3701 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition0-require-True]` | 0.0637 | 0.2899 | 0.0018 | 0.3555 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_01_group_only_paired_resource[sha1]` | 0.0016 | 0.3522 | 0.0002 | 0.3540 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition2-require-True]` | 0.0647 | 0.2856 | 0.0017 | 0.3520 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition1-charge-True]` | 0.0579 | 0.2894 | 0.0016 | 0.3489 | passed |
| `tests/integration/p6/test_r227_fixes.py::test_r227_02_callback_identity_and_healthy_catalog[acquisition3-charge-True]` | 0.0580 | 0.2885 | 0.0014 | 0.3479 | passed |
