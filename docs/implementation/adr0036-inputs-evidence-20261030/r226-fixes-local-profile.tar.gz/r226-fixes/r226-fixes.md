### r226-fixes: 110.81s command wall time (exit 0)

Mode `xdist`, workers 2, SHA `ba5885e3f78ab83c98005e03d1de4c3ca9e1a408`, tree `20ef8328f42808a40bf2046da06a74e06c4a88fc`, Python 3.12.15, SQLite 3.53.1.
Invocation ID: `r226-fixes-1793367654-d58406ad`. Dirty tree: `False`.
Command wall time: 110.81s; Cumulative test duration: 216.75s.

| Test file | Aggregate seconds (setup/call/teardown) | Tests | Failures |
|---|---:|---:|---:|
| tests/integration/p5/test_ref_inventory_wiring.py | 134.80 | 144 | 0 |
| tests/integration/p5/test_ref_notes_inputs.py | 44.87 | 120 | 0 |
| tests/integration/access/test_git_acquisition.py | 31.74 | 88 | 0 |
| tests/integration/p5/test_git_acquisition.py | 5.31 | 14 | 0 |
| tests/unit/test_native_acquisition_values.py | 0.04 | 23 | 0 |

#### Slowest tests by phase

| Test node | Setup (s) | Call (s) | Teardown (s) | Total (s) | Status |
|---|---:|---:|---:|---:|:---:|
| `tests/integration/access/test_git_acquisition.py::test_nonseed_notes_reuse_original_capture_and_budget[sha256]` | 0.0815 | 3.3348 | 0.0007 | 3.4169 | passed |
| `tests/integration/access/test_git_acquisition.py::test_nonseed_notes_reuse_original_capture_and_budget[sha1]` | 0.0806 | 3.1613 | 0.0007 | 3.2425 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition0-paired-metadata]` | 0.0654 | 2.2717 | 0.0019 | 2.3390 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition2-paired-metadata]` | 0.0506 | 2.2156 | 0.0017 | 2.2679 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition3-paired-metadata]` | 0.0670 | 2.1594 | 0.0018 | 2.2282 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition3-core-metadata]` | 0.0686 | 2.1432 | 0.0019 | 2.2136 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition1-paired-metadata]` | 0.0645 | 2.0288 | 0.0021 | 2.0953 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition2-core-metadata]` | 0.0575 | 1.9771 | 0.0020 | 2.0365 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition0-core-metadata]` | 0.0652 | 1.9280 | 0.0021 | 1.9953 | passed |
| `tests/integration/p5/test_ref_inventory_wiring.py::test_inventory_wiring_keeps_original_claims_and_receiver_checks[acquisition3-core-native]` | 0.0542 | 1.8658 | 0.0019 | 1.9220 | passed |
