"""Execute the bounded F1-B correction checks with source-bound raw records."""

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def main():
    repo, output, temp_root = (Path(value).resolve() for value in sys.argv[1:])
    output.mkdir(parents=True, exist_ok=False)
    temp_root.mkdir(parents=True, exist_ok=False)
    for parent in (temp_root, *temp_root.parents):
        if (parent / ".git").exists():
            raise RuntimeError("temporary fixture root has ancestor Git metadata")
    os.chmod(temp_root, 0o700)
    env = dict(os.environ)
    env["TMPDIR"] = str(temp_root)
    env.pop("UV_PROJECT_ENVIRONMENT", None)
    env["UV_PYTHON_DOWNLOADS"] = "never"

    def git(*args):
        return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()

    source = {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}")}
    if git("status", "--porcelain"):
        raise RuntimeError("source worktree is not clean")
    summary = {
        "scope": "F1-B correction producer, CLI, hash regression methods and scoped static checks",
        "source": source,
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "temporary_fixture_root_has_ancestor_git_metadata": False,
        "commands": [],
        "product_pytest": "not rerun; unchanged-input historical evidence reused",
    }

    def run(name, command, *, stdout_name=None, extra_env=None):
        stdout_name = stdout_name or name + ".stdout"
        stderr_name = name + ".stderr"
        started = time.monotonic()
        with (output / stdout_name).open("wb") as stdout, (output / stderr_name).open("wb") as stderr:
            result = subprocess.run(command, cwd=repo, env=env | (extra_env or {}), stdout=stdout, stderr=stderr)
        entry = {"name": name, "argv": command, "exit_code": result.returncode, "stdout": stdout_name, "stderr": stderr_name, "elapsed_seconds": time.monotonic() - started}
        summary["commands"].append(entry)
        (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        return result.returncode

    fixture = output / "hashes.json"
    optional_python = str(repo / "tools/schema-model/.venv/bin/python")
    producer_ok = run("hash_producer", ["scripts/local-run.sh", "python", "tools/schema-model/instance_fixture.py", "--profile", "filesystem-hash-v1"], stdout_name="hashes.json") == 0
    if producer_ok:
        data = json.loads(fixture.read_text())
        if (data["source_commit"], data["source_tree"]) != (source["commit"], source["tree"]):
            raise RuntimeError("producer source identity mismatch")
        summary["producer_runtime"] = data["runtime"]
        summary["fixture_sha256"] = hashlib.sha256(fixture.read_bytes()).hexdigest()
        run("hash_cli", [optional_python, "tools/schema-model/instance_model.py", str(fixture), str(output / "hash-result")])
        run("hash_regressions", [optional_python, "-m", "unittest", "discover", "-s", "tools/schema-model", "-p", "test_hash_model.py", "-v"], extra_env={"HASH_FIXTURE": str(fixture)})
        tests = (output / "hash_regressions.stderr").read_text()
        match = re.search(r"Ran (\d+) tests? in", tests)
        summary["unittest_methods_executed"] = int(match.group(1)) if match else None
        summary["unittest_outcome"] = tests.strip().splitlines()[-1] if tests.strip() else None
    paths = ["tools/schema-model/hash_profile.py", "tools/schema-model/instance_model.py", "tools/schema-model/test_hash_model.py"]
    run("ruff_check", ["scripts/local-run.sh", "ruff", "check", *paths])
    run("ruff_format", ["scripts/local-run.sh", "ruff", "format", "--check", *paths])
    run("whitespace", ["git", "diff", "--check", "ac732094676f1c3ebc4330c25c2177538b72585d", "HEAD"])
    unchanged_paths = ["packages", "src", "tests", "scripts", "pyproject.toml", "uv.lock", "tools/schema-model/uv.lock", "tools/schema-model/pyproject.toml", "tools/schema-model/worker.py", "tools/schema-model/instance_shapes.ttl", "tools/schema-model/instance_fixture.py", "tools/schema-model/outcome_profile.py", "tools/schema-model/result.schema.json", "tools/schema-model/test_instance_model.py", "tools/schema-model/test_outcome_model.py"]
    run("unchanged_inputs", ["git", "diff", "--exit-code", "ac732094676f1c3ebc4330c25c2177538b72585d", "HEAD", "--", *unchanged_paths])
    summary["final_source"] = {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "tracked_status": git("status", "--porcelain")}
    summary["finished_utc"] = datetime.now(timezone.utc).isoformat()
    summary["success"] = producer_ok and all(command["exit_code"] == 0 for command in summary["commands"]) and summary["final_source"]["commit"] == source["commit"] and not summary["final_source"]["tracked_status"]
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"source": source, "success": summary["success"], "commands": [{"name": item["name"], "exit_code": item["exit_code"]} for item in summary["commands"]], "unittest_methods_executed": summary.get("unittest_methods_executed"), "summary": str(output / "summary.json")}, indent=2))
    return 0 if summary["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
