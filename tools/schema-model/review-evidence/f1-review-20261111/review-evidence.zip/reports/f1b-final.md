# Independent F1-B correction review

## Exact-source verdict

The two material F1 findings from the initial independent review are resolved at **`a710c5880dd6404efc698b5962bad6266eae1a96`**, tree **`8b90a043296147353470769ba20b23bdb694e146`**, sole parent `ac732094676f1c3ebc4330c25c2177538b72585d`.

**No remaining material finding was identified in the reviewed F1 scope.** This is an independent source-review verdict with bounded executable counterexamples. It is not a GitHub approval, merge authorization, product-wide acceptance, or a claim that the pre-existing product NUL-admission discrepancy has been fixed. Owner acceptance also relies on the correction author's separate exact-source verification and the identified historical evidence.

Reviewer: `/root/review_f1b`, with no authorship of the implementation or correction. The correction was inspected in a new detached worktree, `/workspace/scratch/644a7672b0d6/review-f1b-corrected`. Source remained clean. The worktree is an isolation convention, not an enforced filesystem sandbox.

## Actual correction inspection

All five modified files were inspected against the initial reviewed source:

- `tools/schema-model/hash_profile.py`
- `tools/schema-model/test_hash_model.py`
- `tools/schema-model/instance_constraints.json`
- `tools/schema-model/instance_model.py`
- `tools/schema-model/INSTANCE-PILOT.md`

The correction does not change product DDL/API/scanner code, the universal SHACL shape file, dependency locks, CI workflows, or the PR's parent relationship. Its fixed case requirements apply only to positive-profile admission. Synthetic valid domain tuples remain permitted by the unchanged `values` projection path and unchanged SHACL rules.

### R263-01 — resolved

`CASE_REQUIREMENTS` now declares each required positive case's kind, persisted hash state, size, digest and error-presence boundary. Admission binds the named case's qualified key to exactly one row, then checks that row's required tuple and error boundary. This covers both the swapped `changed`/`error` keys and the missing `complete_with_error` witness.

The regression additions cover four case swaps and the disappearance/change of the empty-error/non-file-size witnesses. They explicitly distinguish positive-fixture admission from universal domain validity by checking that otherwise legitimate mutations still pass the `values` profile. The exact empty digest/size/error requirements do not become new universal catalog restrictions.

### R263-02 — resolved within F1; product discrepancy remains

The documentation and constraint mapping now distinguish the SQLite kind/state tuple relationship from the stricter full-string digest lexical constraint. Normalized receipt limitations explicitly name embedded-NUL suffixes. The producer adds two separately labeled SQL-only differential controls, retaining exact stored text/bytes, SQLite's reported text length, actual public verification and the expected graph failure. Corresponding synthetic tests execute strict shape rejection.

The strict digest rule and the earlier newline correction remain unchanged. The producer comments/documentation explicitly say that current SQL acceptance is observed source behavior, not a requirement to keep accepting malformed hashes, and that future product repair must change the SQL-side expectation without weakening SHACL rejection.

The pre-existing product DDL/public verifier still accepts the NUL-suffixed values demonstrated in the initial review. No product fix is claimed or implied. This was not rerun here because all relevant product inputs are unchanged. The initial real SQLite/API counterexample remains the applicable product evidence; public-scanner generation of such values was neither observed nor claimed.

## Independently rerun controls

The original external five-case driver was reused without modification:

```sh
UV_PYTHON=/home/agent/.local/share/git-repo-db/python/6d7521138fd33afddc1ccd08abb007d9a2829e38117c2576f9efdc0ec73ce772/python/bin/python3 \
UV_PYTHON_DOWNLOADS=never \
uv run --project tools/schema-model --locked --offline python \
  /workspace/scratch/644a7672b0d6/f1b_review_graph_probe.py \
  /workspace/scratch/644a7672b0d6/f1-review-evidence/final-hashes.json \
  /workspace/scratch/644a7672b0d6/f1b-review-graph-after
```

The new worktree's own optional environment was synchronized offline from the committed lock. No product code ran in this re-review. The actual checker receipts report pySHACL 0.40.2 and RDFLib 7.6.0, inference `none`, JavaScript false, imports false.

| Control | Before correction | After correction | Completed checker invocations after |
| --- | --- | --- | --- |
| Original positive fixture | pass | pass | 1 |
| Digest followed by NUL | fail | fail | 1 |
| Digest followed by NUL and suffix | fail | fail | 1 |
| Swapped changed/error case identities | incorrect pass | undetermined at input admission | 0 |
| Missing complete-with-error witness | incorrect pass | undetermined at input admission | 0 |

The after-correction driver exited **0** after all five controls matched expectations. These are five controls and three supported checker invocations, not five product pytest nodes or five unittest methods. The correction author's full changed optional test suite and newly generated producer fixture are separate evidence; this reviewer did not rerun those cohorts.

Receipts accurately retain the historical producer source `ac732094676f1c3ebc4330c25c2177538b72585d` / tree `98a709e165fc732bd8a8b5fb3c86ec3fa324e8e2`, while their tool source identifies the corrected commit/tree. No historical fixture regeneration is claimed. `spec_satisfiability`, `operation_invariants`, and `implementation_conformance` remain `not_run`.

## Evidence preservation and bindings

- Unchanged driver SHA-256: `d1266c84b8833fe7479c87e8987259b6d1f923ea477c427f221eb18da8f91dce`.
- Unchanged historical fixture SHA-256: `69f9f1f13c4734a9a856d9a4eccfa0b3b14c5c8f377a2d1a673c7279e5bc56fc`.
- Before-correction summary remains unchanged: `fda4ce628f38f27ad2d72211af2c1b3c61d9cdbeddc9a88ae9ea19d29fb682f7`.
- After-correction summary: `f1b-review-graph-after/summary.json`, SHA-256 `d659c3831fb1a089cdb59ee1301f1cd786143777c4c4ce5d54885e817d51c442`.
- After-correction raw inputs, graphs, normalized receipts and returned engine diagnostics: `/workspace/scratch/644a7672b0d6/f1b-review-graph-after/`.
- Optional environment sync log: `/workspace/scratch/644a7672b0d6/f1b-review-corrected-tool-sync.log`.

Initial findings, product probe results and raw graph failures remain unchanged in the initial report and `f1b-review-graph-before/`. `git diff --check` passed for the correction; worktree status remained clean. Any later evidence-only commit must be tied to these executions with explicit unchanged-input comparison rather than described as a fresh execution of that later commit.

## Unverified and unauthorized scope

This re-review did not execute product regressions, Windows/release qualification, a comprehensive repository audit, F2/F3/M1/V1/T1, exhaustive race detection or real-file-byte proof. The product NUL-admission discrepancy remains explicitly open outside the F1 model correction scope. No AGY operation, source edit, PR publication, merge, release, tag, deployment, force-push or retained-data mutation was performed by this reviewer.
