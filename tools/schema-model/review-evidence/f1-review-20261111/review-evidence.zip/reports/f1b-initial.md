# Independent F1-B review — initial findings

## Review identity and disposition

- Reviewer: independent ChatGPT subagent `/root/review_f1b`, with no authorship of the submitted F1-B implementation or the proposed corrections.
- PR: #263, `feat/adr0040-f1-hash-states-20261111`, based on #262.
- Reviewed base: `f6a6a3ca2dd64e92a6fc4decd460a62e44e01a25`.
- Reviewed HEAD: `ac732094676f1c3ebc4330c25c2177538b72585d`.
- Reviewed tree: `98a709e165fc732bd8a8b5fb3c86ec3fa324e8e2`.
- Immediate HEAD parent: `d18ecbf9705e47bdeda04eec439131bf70b7b7f5`.
- Separate detached worktree: `/workspace/scratch/644a7672b0d6/review-f1b`. Tracked source remained clean before and after review. A separate worktree and read-only instructions are not an enforced filesystem sandbox.
- Disposition: **changes requested** for the two confirmed F1 findings below. This is source review plus bounded independently executed counterexamples, not release qualification or implementation-conformance proof.

## Actual inspection

Inspected all eight files in the child diff: `INSTANCE-PILOT.md`, `hash_profile.py`, `instance_constraints.json`, `instance_fixture.py`, `instance_model.py`, `instance_shapes.ttl`, `outcome_profile.py`, and `test_hash_model.py`, all under `tools/schema-model/`.

Direct authority inspection covered the Filesystem `store.py` DDL and `verify()` implementation, the scanner's kind/entry/hash/exception paths in `scanner.py`, ADR 0040, ADR 0039, `docs/architecture/local-catalog-contract.md`, the optional-tool README and local-runtime guide. Repository instructions and the investigation/final-tree procedures were applied. This was not a comprehensive product or architecture audit.

The reviewed rules correctly distinguish `unknown` kind from persisted hash states, exclude `pending`, preserve SQL NULL versus empty text, permit non-file sizes and complete entries with an error, and retain exact SHA length constraints. No claim of real-byte equality, atomic snapshot, exhaustive race detection or global verification was introduced by those rules. Producer helper modules are checked against HEAD and separately hashed. The receipt preserves four result families and raw engine diagnostics; the three unevaluated families remain `not_run`.

## R263-01 — required positive scenarios are not bound to their semantic content

**Classification: confirmed defect; material to the positive-profile coverage contract.**

Source: `tools/schema-model/hash_profile.py:203-239`, especially the loop over `cases.values()` at line 218. It checks the global hash-state/kind multisets, distinct qualified keys and occurrence existence, but never checks the meaning of an individual named case.

Two independent mutations of the exact-source historical fixture were submitted under `filesystem-hash-v1`:

1. Swap the qualified keys for `changed` and `error`, leaving all rows and aggregate counts unchanged.
2. Remove the non-NULL error from the `complete_with_error` entry, and adjust that scan's outcome `error_count` to zero. All remaining rows are valid, and global kind/state counts still match, but the required successful-file-with-error boundary witness is gone.

Both inputs returned **`data_conformance=pass`**, with one completed checker invocation. They should be refused during positive-profile admission as `undetermined`, because they no longer establish the declared required scenario coverage. The unmodified positive fixture returned `pass`.

This is not a claim that the current producer emitted these mutations. It demonstrates that the advertised positive-profile admission gate does not enforce its named boundary witnesses. F1-A already binds named terminal cases to expected statuses; F1-B needs the analogous check for its required case semantics, including `complete_with_error`'s non-NULL error. Generic valid data without all positive witnesses can continue through the explicitly synthetic `values` profile.

**Requested correction:** use a source-defined named-case contract, bind each key to its row and required kind/state/error semantics, and retain regression controls for both mutations. Do not weaken universal SHACL rules or force arbitrary instances to contain the full positive fixture.

## R263-02 — undocumented SQLite/API versus strict-digest divergence

**Classification: confirmed F1 mapping/documentation defect, exposing a pre-existing product admission discrepancy.**

Sources: `INSTANCE-PILOT.md:192-198` says the SHACL rules “mirror the current SQLite tuples”; `instance_shapes.ttl:13-14` requires exact full-string length and lowercase hexadecimal syntax. The actual product DDL at `packages/filesystem/src/repo_catalog/filesystem/store.py:37` uses SQLite `length()` and `GLOB` text semantics. The verifier at `store.py:202-274` does not independently reject this boundary.

With a real disposable catalog, enabled ordinary guards and the verified project runtime, both of these SHA TEXT values were accepted by SQL, round-tripped exactly, exposed by `iter_entries()`, and passed public `verify()` with `integrity=ok`:

- `"a" * 64 + U+0000` (Python string length 65).
- `"a" * 64 + U+0000 + "invalid"` (Python string length 72).

For both, SQLite reported `length(sha256)=64` and its hexadecimal GLOB check passed. The corresponding synthetic RDF inputs correctly returned **`data_conformance=fail`** under the strict digest rule. The original newline correction remains valid and must remain in place.

**Requested F1 correction:** retain the strict 64-character digest rule; explicitly describe this SQL-admitted/SHACL-rejected differential in the mapping, documentation and receipt limitations, and preserve paired executable controls. Do not silently claim equivalence, and do not weaken SHACL to accept NUL suffixes. Product DDL/verifier repair is a separate decision outside the bounded F1 correction scope. This probe does not show that the public scanner produces malformed digests or that retained user data is affected.

## Independently executed checks

The review worktree established its own editable product environment using `./scripts/setup-local-python.sh --offline`, then ran the disposable SQL/API probe through `scripts/local-run.sh`. Actual runtime was Python 3.12.15 with SQLite 3.53.1, Linux x86_64. The optional environment was independently synchronized from the committed lock, offline, on the same selected complete Python distribution. Actual engine receipts report pySHACL 0.40.2 and RDFLib 7.6.0, with inference `none`, JavaScript false and imports false.

| Check | Actual result |
| --- | --- |
| Reviewer worktree verified bootstrap | Passed |
| Optional-tool locked offline sync | Passed |
| Two SQL-only NUL insert/roundtrip/public-verify controls | Both admitted; mismatch exposed |
| Exact original positive fixture | Graph pass |
| Terminal NUL and NUL-plus-suffix graph controls | Both graph fail, as required by strict digest contract |
| Swapped changed/error case names | Incorrect graph pass; R263-01 reproduced |
| Missing complete-with-error boundary | Incorrect graph pass; R263-01 reproduced |

The five-case graph driver exited **1** after completing every case because two observed outcomes differed from its declared expectations. This is a retained finding, not an incomplete execution or bootstrap failure. These are five checker invocations, not five product pytest tests or five unittest methods. No broad historical test cohort was rerun.

Historical fixture reused: `_temp/adr0040-f1b-final-evidence/hashes.json` from artifact 13818878151, locally `f1-review-evidence/final-hashes.json`, 52,160 bytes, SHA-256 `69f9f1f13c4734a9a856d9a4eccfa0b3b14c5c8f377a2d1a673c7279e5bc56fc`. Its recorded source commit/tree equal the reviewed HEAD/tree. The review did not regenerate the full source fixture or authenticate the earlier runner.

## Retained raw review evidence

Paths are relative to `/workspace/scratch/644a7672b0d6/`:

- `f1b_review_product_probe.py` — SQL/API reproducer, SHA-256 `891f0b46c2e1706a6eabb7b40e3809047ce17e615e023dd4c449d325bea94145`.
- `f1b-review-nul-product.json` — actual product probe output, SHA-256 `89f33f416b97b918b163f7fa1fefb61054598fbc09dba21c2e92a7c54926f436`.
- `f1b_review_graph_probe.py` — five-case graph reproducer, SHA-256 `d1266c84b8833fe7479c87e8987259b6d1f923ea477c427f221eb18da8f91dce`.
- `f1b-review-graph-before/` — each input, graph, normalized receipt and raw engine stdout/stderr/report.
- `f1b-review-graph-before/summary.json` — complete counterexample summary, SHA-256 `fda4ce628f38f27ad2d72211af2c1b3c61d9cdbeddc9a88ae9ea19d29fb682f7`.
- `f1b-review-bootstrap.log`, `f1b-review-tool-sync.log`, and review worktree `artifacts/local-python/` — setup records.

Preserve these before-fix records unchanged. A later corrected run must use a new output directory and identify its actual tool source commit/tree separately from the reused fixture's original source binding.

## Remaining scope

No AGY jobs or service operations were attempted. No reviewed source, retained catalogs, credentials or live authenticated content were changed. No PR merge, release, tag, deployment or force-push was performed. Product-wide tests, Windows/release qualification, F2/F3/M1/V1/T1, exhaustive scanner races and real-file-byte proof remain unexecuted and outside this review. Acceptance requires focused correction and re-review of the two findings above.
