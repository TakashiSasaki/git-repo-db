# Independent review: ADR 0040 F1-A / PR #262

## Identity and disposition

- Reviewer: separate ChatGPT subagent `review_f1a`, with no participation in the implementation.
- Review date: 2026-11-11.
- Base: `3a5457af1e42c158641a73fe5172cad2dbe0718c`.
- Reviewed HEAD: `f6a6a3ca2dd64e92a6fc4decd460a62e44e01a25`.
- Reviewed tree: `007749b955d156ee6a7a24a7798ed6f9dffc4e5f`.
- Sole parent: the stated base; one implementation commit, seven changed files.
- Separate detached worktree: `/workspace/scratch/644a7672b0d6/review-f1a`.
- The worktree was clean at entry and after review, and the repository was not shallow.
- Disposition: **no confirmed material defect or blocking source-review finding in the reviewed F1-A scope**. No correction is requested. This is an independent source review, not an independently repeated runtime acceptance run or a formal proof.

The recommendation depends on the integration coordinator reconciling the existing exact-source execution evidence. It grants no merge authorization and makes no assessment of F1-B.

## Actual inspection

I read all seven changed files and their exact diff:

1. `tools/schema-model/INSTANCE-PILOT.md`
2. `tools/schema-model/instance_constraints.json`
3. `tools/schema-model/instance_fixture.py`
4. `tools/schema-model/instance_model.py`
5. `tools/schema-model/instance_shapes.ttl`
6. `tools/schema-model/outcome_profile.py`
7. `tools/schema-model/test_outcome_model.py`

I compared their meaning with the unchanged canonical `packages/filesystem/src/repo_catalog/filesystem/store.py` DDL, `verify()`, `scan()` and `get_scan()`; inspected the unchanged checker worker and common result schema plus the relevant instance regression helpers; and read the required tooling guides, ADR 0040, ADR 0039, local-catalog contract, local-Python guidance and applicable repository instructions/skills. Relevant constraints of ADRs 0032, 0035, 0037 and 0038 were preserved; no broader architecture audit was undertaken.

## Findings and reasoning

### Confirmed defects

None in the reviewed F1-A diff.

### Outcome semantics

- `instance_shapes.ttl:13-39` matches the selected canonical outcome DDL (`store.py:46-54`) and cross-row verifier (`store.py:256-269`): the three persisted terminal statuses, positive finish time, nonnegative counts, counts scoped to the same qualified scan, and rejection of complete outcomes with observed errors.
- The count queries use each outcome's actual `m:parent` scan rather than global totals. Entry/error zero cases retain zero through the optional match and aggregate.
- The change correctly avoids treating `incomplete` as a stored terminal enum. `store.py:405-434` derives it from the absent outcome. F1-A retains the two unfinished scans, and requires the four specific terminal witnesses separately.
- No rule invents `partial => error_count > 0`, clock monotonicity, or atomic filesystem-snapshot semantics. The SQL-only empty partial fixture demonstrates the legitimate zero case without labeling it a scanner trace.

### Projection and coverage

- `instance_model.py:105-156` checks scenario admission before target generation, requires actual integer/text source cells for the new projected fields, and computes error presence with `error is not None`. Empty error text therefore remains non-NULL; missing projected fields fail admission instead of becoming NULL.
- `outcome_profile.py:162-204` has producer-defined fixed construction counts and qualified, distinct scenario identities. Required outcomes cannot disappear while the positive profile is relabeled as an empty successful result. Valid-but-wrong statuses break positive-scenario coverage; deliberately invalid enums still reach SHACL as negative controls.
- Row occurrence identity, ordered qualified parent lookup, raw BLOB paths, exact native timestamp strings and unresolved optional references remain intact. No new cross-database validity precondition appears.
- `test_outcome_model.py` distinguishes producer/API/SQLite evidence from mutations of extracted JSON. Its controls exercise missing fields/outcomes/scenarios, wrong typed cells, invalid terminal/count/time values, count mismatches, complete-with-error, empty-text versus NULL, and the legitimate non-monotonic-clock boundary.

### Source and receipt boundaries

- `instance_fixture.py:208-235` checks imported Filesystem/Worktrees source bytes and the new outcome helper against HEAD, recording their hashes. `instance_model.py:275-328` retains producer claims separately from runner commit/tree/dirty status and includes the helper in tool digests.
- The new manifest shape SHA-256 is correct: `da8416ab358aaee6bfc46c7c5fddc34f14166c1882ca1fbee359f4f78e8fe9b3`.
- Raw checker diagnostics, finite timeout behavior, common schema validation and all four result families remain unchanged. Only `data_conformance` is evaluated; the other three families remain `not_run`. Engine-internal evaluation counts remain null.
- The source hashes are consistency/provenance information, not authentication. The supported producer supplies the helper binding; the general JSON admission layer is not a hostile-producer authentication boundary. No stronger claim is made here.

### Conditional risks and optional improvements

No additional material conditional risk was identified for the stated fixed disposable-fixture scope. Arbitrary retained-database loading, whole-SQL validity, every scanner interruption path and current file-byte authenticity are explicitly outside it.

A dedicated synthetic cross-scan redistribution control could make the same-scan aggregation intent even more obvious, but the present SPARQL joins are correctly scoped by inspection. This is optional test strengthening, not a blocker or a request to broaden F1.

## Verification actually performed

- Read-only Git identity, full-history, parent and seven-path diff checks.
- `git diff --check 3a5457af1e42c158641a73fe5172cad2dbe0718c HEAD`: exit 0.
- Independent SHA-256 calculation of `instance_shapes.ttl` and comparison with the committed manifest: match.
- Clean-worktree check before and after review.

**No product test, fixture generation or SHACL execution was newly run by this reviewer.** No system Python/SQLite was used for product validation. The historical 25/12 unittest and four-product-node claims are not relabeled as this reviewer's execution; the coordinator owns their artifact reconciliation. No historical failure record was modified.

## Limits and authorization

This review establishes an independent inspection of the exact F1-A diff, not F1-B acceptance, complete ADR 0040 implementation, specification satisfiability, operation invariants or whole-implementation conformance. Existing successful runtime evidence must retain its original source identity and execution attribution.

The reviewer made no source/ref/PR mutation, merge, release, tag, deployment, security-setting change, mandatory CI change or retained-data modification. AGY and its maintenance were not accessed or changed.
