# Independent retained-evidence review: ADR 0040 F1-A/F1-B

Reviewer: independent ChatGPT subagent `/root/review_evidence`, 2026-11-11.

## Scope and disposition

**No confirmed evidence-consistency defect found in the three retained archives.**
This review independently inspected the downloaded archive bytes, indexed members,
execution summaries, commands/exits, normalized/raw checker reports, source input
and graph hashes, producer/tool source bindings, bootstrap identities and selected
product JUnit cases. It did not execute the product, regenerate fixtures, rerun
SHACL, authenticate the producer, or independently establish the implementation's
semantics. The F1-A/F1-B source reviewers address the latter scope separately.

No repository file, Git ref, PR, AGY service, retained catalog or historical archive
was modified. One exact synthetic fixture was copied to a separate scratch file
for a source reviewer's targeted counterexamples.

## Exact archive and source identities

| Artifact | Run | Executed feature source | Tree | Indexed files |
| --- | --- | --- | --- | ---: |
| 13818407030 | 42936446586 | `f6a6a3ca2dd64e92a6fc4decd460a62e44e01a25` | `007749b955d156ee6a7a24a7798ed6f9dffc4e5f` | 69 |
| 13819945183 | 42937529485 | `d18ecbf9705e47bdeda04eec439131bf70b7b7f5` | `a213cd56de07e6cbe546e794aa4129d11be523a8` | 85 |
| 13818878151 | 42938046686 | `ac732094676f1c3ebc4330c25c2177538b72585d` | `98a709e165fc732bd8a8b5fb3c86ec3fa324e8e2` | 105 |

Archive byte lengths and independently computed SHA-256:

- 13818407030: 60,443 bytes;
  `c3a92a9e495d1296a298c0232d8199c9b8ec951d712c650f76ba58040ac94cec`.
- 13819945183: 86,992 bytes;
  `37ed93cb6486b25165a7d68682253073c61f9dabc0ae01f20ddb2a582a1bc266`.
- 13818878151: 124,328 bytes;
  `c09f328e19c6aa8adc7e2d7abc230393c5ad22535a6a7ed683c3913965a66208`.

All three match the supplied checkpoint. All **259 indexed files** match their
recorded lengths and SHA-256. Archive member names were duplicate-free and had no
absolute paths or parent traversal. Members were read in memory; no blind archive
extraction or execution was used.

The workflow/harness commits are respectively
`b41461026aba9e3b6863611ad6e5d8607b3cf2c4`,
`c058f9f6ad1584eee51b06b24502312b1c521386`, and
`7ee30bf372c7274a6cc2d20393cbef5a7025fd04`. They are distinct from the executed
feature commits. Run IDs and harness IDs in the archive summaries match the live
Actions metadata supplied by the coordinating agent. This reviewer did not
independently query that API metadata.

Local Git objects confirm the ancestry:

`3a5457af1e42c158641a73fe5172cad2dbe0718c`
→ `f6a6a3ca2dd64e92a6fc4decd460a62e44e01a25`
→ `d18ecbf9705e47bdeda04eec439131bf70b7b7f5`
→ `ac732094676f1c3ebc4330c25c2177538b72585d`.

## Receipts and source bindings inspected

Ten normalized `result.json` receipts were inspected: two F1-A profiles, three
initial F1-B profiles, and five final/differential profiles. Each was compared
with its `source-input.json`, `data.nt` and `engine.json`. A total of 236 digest
comparisons across receipt input/graph/tool code/lock/imported-product/helper
bindings matched the actual archive or exact Git objects. The main producer
hashes and each source/tool commit's Git tree were also checked independently.
There were no mismatches.

Bindings include the changed helper modules `outcome_profile.py` and, for F1-B,
`hash_profile.py`; they match the appropriate pre-fix or post-fix commit. No
final-source label was substituted for the initial F1-B source.

Every inspected receipt retains the four result families. Only
`data_conformance` is evaluated. `spec_satisfiability`, `operation_invariants`
and `implementation_conformance` are `not_run`. Each receipt records one
completed supported checker invocation, while engine evaluation counts remain
null. Raw engine verdicts agree with the normalized data verdicts. The recorded
engine is pySHACL 0.40.2 / RDFLib 7.6.0, with inference `none` and JS/imports
disabled.

The F1-A outcome receipt records Entry 8/8, Scan 6/6, Outcome 4/4 and Reference
1/1 expected/selected targets. The F1-B hash receipt records 15/15, 9/9, 7/7 and
1/1. The original values profile correctly retains Outcome 0/0 as
`not_applicable`, rather than claiming terminal outcome coverage.

## Historical executions and reuse

- F1-A: command/exit and unittest summaries record 25 instance methods and 12
  outcome methods passing. Product JUnit contains exactly the four selected
  named cases, with no failures, errors or skips.
- Initial F1-B: 25 instance, 12 outcome and 13 hash methods pass. Product JUnit
  contains exactly the two selected named cases, with no failures, errors or
  skips.
- Final F1-B: 25 instance, 12 outcome and 13 hash methods pass. There is no claim
  or evidence of a fresh product pytest execution in this archive.

The product cases correspond to the handoff's named cohort. There are five
distinct product test identities across the two historical selections because
`test_changed_during_hash_is_not_admitted` occurs in both. Methods, selected
pytest nodes, shape targets, SQL controls and checker invocations remain separate
measurements.

Final F1-B's `product_test_evidence_reuse` explicitly refers to initial source
`d18ecbf9...` and run 42937529485. The recorded unchanged-input command compares
`packages`, `src`, `tests`, `scripts`, root `pyproject.toml`/`uv.lock`, optional
`uv.lock` and `worker.py`. Its log is empty and exit is zero. Repeating that
read-only Git diff against the actual objects independently produced no changes.
This supports the stated bounded reuse; it is not a final-HEAD test rerun.

Bootstrap receipts were created before each feature edit, at main, F1-A and
initial F1-B respectively. They report setup success, all mandatory steps passed,
and Python 3.12.15 / SQLite 3.53.1 on Linux x86_64. The later checker receipts
bind the actual feature source. The earlier bootstrap commit is therefore not
misreported as a final-source product execution. The setup timing record's
`measurement_only=true` / `verified=false` fields are not global product
acceptance flags; the setup status and step results carry its scoped meaning.

## Digest-newline differential

The final archive retains both original raw cases:

- `before-boundary/result.json`: source and tool `d18ecbf9...`, data verdict
  `pass`, reproducing the unwanted acceptance of the deliberately malformed
  digest.
- `after-boundary/result.json`: source and tool `ac732094...`, data verdict
  `fail`, with the corrected shape source hash.

Both source-input scopes explicitly identify synthetic trailing-newline graph
counterexamples, not product admission. The recorded wrapper expected the old
pass to demonstrate the bug and expected the corrected fail to demonstrate its
resolution. That wrapper success does not convert the malformed graph's
conformance verdict into success. The pre-fix receipt was not overwritten.

## Limitations and remaining responsibility

No full tests, Windows/release checks, operation model, specification reasoning,
retained-data validation, or present-byte authentication were attempted. No
product or optional checker process was run by this evidence reviewer. Current
CI status/mergeability are the coordinating agent's separately refreshed API
observations. Artifact retention remains finite; the hashes establish consistency
of the bytes available now, not durable future availability or authenticity.

Evidence bookkeeping does not block owner acceptance on the inspected sources.
Independent source-review findings, any resulting corrections, and their actual
post-correction verification still determine integration readiness.

## Scratch audit record

The compact machine-readable audit is `evidence-review-results.json` alongside
this report. The copied exact final hash fixture is `final-hashes.json`, from
`_temp/adr0040-f1b-final-evidence/hashes.json`: 52,160 bytes,
SHA-256 `69f9f1f13c4734a9a856d9a4eccfa0b3b14c5c8f377a2d1a673c7279e5bc56fc`.
