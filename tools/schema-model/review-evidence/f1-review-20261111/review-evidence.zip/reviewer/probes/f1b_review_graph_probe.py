"""Independent bounded F1-B graph/coverage counterexamples with raw receipts."""

import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tools/schema-model"))
from instance_model import validate, value


def row(data, name):
    key = data["hash_cases"][name]
    return next(r for r in data["tables"]["filesystem"]["entries"] if [value(r["namespace_uuid"]), value(r["scan_uuid"]), value(r["relative_path"]).hex()] == key)


def main():
    source, output = Path(sys.argv[1]), Path(sys.argv[2])
    output.mkdir(parents=True, exist_ok=False)
    fixture = json.loads(source.read_text())
    cases = [("unmodified_positive", copy.deepcopy(fixture), "pass")]
    for label, digest in (("terminal_nul", "a" * 64 + "\0"), ("nul_suffix", "a" * 64 + "\0invalid")):
        data = copy.deepcopy(fixture)
        data["profile"] = "values"
        data["scope"] = "Independent synthetic digest NUL counterexample, not scanner evidence"
        row(data, "complete")["sha256"] = {"type": "text", "value": digest}
        cases.append((label, data, "fail"))
    data = copy.deepcopy(fixture)
    data["scope"] = "Independent synthetic positive-profile case-label counterexample, not producer output"
    data["hash_cases"]["changed"], data["hash_cases"]["error"] = data["hash_cases"]["error"], data["hash_cases"]["changed"]
    cases.append(("swapped_changed_error_case_names", data, "undetermined"))
    data = copy.deepcopy(fixture)
    data["scope"] = "Independent synthetic positive-profile missing boundary witness, not producer output"
    row(data, "complete_with_error")["error"] = {"type": "null", "value": None}
    key = data["hash_cases"]["complete_with_error"][:2]
    outcome = next(r for r in data["tables"]["filesystem"]["scan_outcomes"] if [value(r["namespace_uuid"]), value(r["scan_uuid"])] == key)
    outcome["error_count"] = {"type": "integer", "value": 0}
    cases.append(("missing_complete_with_error_boundary", data, "undetermined"))
    result = {
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip(),
        "fixture_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "cases": [],
    }
    for name, data, expected in cases:
        receipt = validate(data, output / name)
        actual = receipt["families"]["data_conformance"]["status"]
        result["cases"].append({"name": name, "expected": expected, "actual": actual, "matches": actual == expected, "checker_invocations_completed": receipt["checker_invocations_completed"], "reason": receipt["families"]["data_conformance"]["reason"]})
    (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if all(case["matches"] for case in result["cases"]) else 1


if __name__ == "__main__":
    raise SystemExit(main())
