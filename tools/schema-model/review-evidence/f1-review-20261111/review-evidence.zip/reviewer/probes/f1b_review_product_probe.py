"""Independent disposable F1-B SQL/API NUL boundary probe, not scanner evidence."""

import json
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

from repo_catalog.filesystem import FilesystemCatalog
from repo_catalog.filesystem.models import occurrence_uuid


def main():
    result = {
        "scope": "independent SQL-only digest NUL boundary; not scanner execution",
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip(),
        "python": sys.version,
        "sqlite": sqlite3.sqlite_version,
        "variants": {},
    }
    with tempfile.TemporaryDirectory(prefix="f1b-review-product-", dir="/tmp") as tmp:
        root = Path(tmp)
        with FilesystemCatalog.initialize(root / "probe.db") as catalog:
            scan = occurrence_uuid()
            with catalog._db:
                catalog._db.execute("INSERT INTO scans VALUES (?,?,?,?,?)", (catalog.namespace_uuid, scan, str(root).encode(), 1, "[]"))
            for label, digest in (("terminal_nul", "a" * 64 + "\0"), ("nul_suffix", "a" * 64 + "\0invalid")):
                record = {"python_length": len(digest), "utf8_hex": digest.encode().hex()}
                try:
                    with catalog._db:
                        catalog._db.execute("INSERT INTO entries VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (catalog.namespace_uuid, scan, label.encode(), "file", 0, None, None, None, None, None, digest, "complete", None, None, None))
                except sqlite3.IntegrityError as exc:
                    record["sqlite_insert"] = "rejected"
                    record["error"] = str(exc)
                else:
                    record["sqlite_insert"] = "accepted"
                    value = catalog._db.execute("SELECT sha256,length(sha256),hex(sha256),sha256 NOT GLOB '*[^0-9a-f]*' FROM entries WHERE relative_path=?", (label.encode(),)).fetchone()
                    record["roundtrip_exact"] = value[0] == digest
                    record["sqlite_length"] = value[1]
                    record["sqlite_hex"] = value[2]
                    record["sqlite_hex_pattern_pass"] = bool(value[3])
                result["variants"][label] = record
            result["public_verify"] = catalog.verify()
            result["public_iter_entries"] = [{"path_hex": entry.relative_path.hex(), "digest_length": len(entry.sha256), "digest_utf8_hex": entry.sha256.encode().hex()} for entry in catalog.iter_entries(scan)]
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
